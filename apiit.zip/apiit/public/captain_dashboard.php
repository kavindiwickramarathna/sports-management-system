<?php
include 'db.php';
session_start();

// Set Sri Lanka timezone
date_default_timezone_set('Asia/Colombo');

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get logged-in captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$result = $stmt->get_result();
$captain = $result->fetch_assoc();
$stmt->close();

$captainId = $captain['user_id'];
$sportId = $captain['sport_id'];

// Profile image
$profileImage = $captain['profile_image'] ?: 'assets/images/default_user.png';

// Fetch overview stats
$membersQuery = $conn->prepare("SELECT COUNT(*) as total_members FROM users WHERE sport_id = ?");
$membersQuery->bind_param("i", $sportId);
$membersQuery->execute();
$members = $membersQuery->get_result()->fetch_assoc();
$membersQuery->close();

$eventsQuery = $conn->prepare("SELECT COUNT(*) as total_events FROM events WHERE sport_id = ? AND status='approved' AND event_date >= CURDATE()");
$eventsQuery->bind_param("i", $sportId);
$eventsQuery->execute();
$events = $eventsQuery->get_result()->fetch_assoc();
$eventsQuery->close();

$jerseyQuery = $conn->prepare("SELECT COUNT(*) as pending_jerseys FROM Jersey_requests WHERE captain_id = ? AND status='pending'");
$jerseyQuery->bind_param("i", $captainId);
$jerseyQuery->execute();
$jerseys = $jerseyQuery->get_result()->fetch_assoc();
$jerseyQuery->close();

$budgetQuery = $conn->prepare("SELECT COUNT(*) as pending_budget FROM budget_requests WHERE captain_id = ? AND status='pending'");
$budgetQuery->bind_param("i", $captainId);
$budgetQuery->execute();
$budgets = $budgetQuery->get_result()->fetch_assoc();
$budgetQuery->close();

// Fetch latest budget deadline
$deadlineQuery = $conn->prepare("SELECT MAX(deadline_date) as budget_deadline FROM budget_deadline");
$deadlineQuery->execute();
$deadlineResult = $deadlineQuery->get_result()->fetch_assoc();
$deadlineQuery->close();

$budgetDeadline = $deadlineResult['budget_deadline'] ?? null;
$today = date('Y-m-d');

// Check if captain submitted budget before or on the deadline
$budgetSubmitted = 0;
if ($budgetDeadline) {
    $budgetSubmitQuery = $conn->prepare("SELECT COUNT(*) as submitted 
                                         FROM budget_requests 
                                         WHERE captain_id = ? 
                                         AND requested_at <= ?");
    $budgetSubmitQuery->bind_param("is", $captainId, $budgetDeadline);
    $budgetSubmitQuery->execute();
    $budgetSubmitted = $budgetSubmitQuery->get_result()->fetch_assoc()['submitted'];
    $budgetSubmitQuery->close();
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>Captain Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.hover-row:hover { background-color: #e0f2fe; transition: 0.3s; }
.overflow-x-auto::-webkit-scrollbar { height: 6px; }
.overflow-x-auto::-webkit-scrollbar-thumb { background-color: #06b6d4; border-radius: 3px; }
</style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="captain.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>
        <div class="relative">
            <button id="myTeamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
                <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
                <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
                <a href="captain_budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>
        <a href="captain_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
        <a href="captain_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
    </div>
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?= htmlspecialchars($profileImage); ?>" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400">
        <span class="text-black select-none">▼</span>
        <div id="userDropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-12 w-48 py-2 z-50">
            <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
            <a href="captain_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
            <a href="captain_account_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
            <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
        </div>
    </div>
</nav>

<script>
const myTeamBtn = document.getElementById('myTeamBtn');
const myTeamDropdown = document.getElementById('myTeamDropdown');
myTeamBtn.addEventListener('click', e => { e.stopPropagation(); myTeamDropdown.classList.toggle('hidden'); });

const userMenu = document.querySelector('.user-menu');
const userDropdown = document.getElementById('userDropdown');
userMenu.addEventListener('click', e => { e.stopPropagation(); userDropdown.classList.toggle('hidden'); });

window.addEventListener('click', () => { myTeamDropdown.classList.add('hidden'); userDropdown.classList.add('hidden'); });
</script>

<div class="mt-24 px-6 lg:px-12 w-full">

 



<!-- Overview Cards -->

<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
<?php 
$cards = [
['Total Members', $members['total_members'], 'M12 2l6 6v12H6V8l6-6z'],
['Upcoming Events', $events['total_events'], 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z'],
['Pending Jersey Requests', $jerseys['pending_jerseys'], 'M12 2l6 6v12H6V8l6-6z'],
['Pending Budget Requests', $budgets['pending_budget'], 'M12 8c1.657 0 3 1.567 3 3.5S13.657 15 12 15s-3-1.567-3-3.5S10.343 8 12 8z M21 12v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4m0-4V8a2 2 0 012-2h14a2 2 0 012 2v4']
];
foreach($cards as $card):
?>
<div class="p-6 rounded-lg shadow-md bg-gradient-to-r from-teal-400 to-teal-600 text-white flex items-center space-x-4">
<div class="p-4 bg-white bg-opacity-20 rounded-full">
<svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo $card[2]; ?>" />
</svg>
</div>
<div>
<h2 class="font-semibold mb-1"><?php echo $card[0]; ?></h2>
<p class="text-3xl font-bold"><?php echo $card[1]; ?></p>
</div>
</div>
<?php endforeach; ?>
</div>

<!-- Upcoming Events Table -->

<div class="mb-8">
<h2 class="text-xl font-semibold mb-4">Upcoming Events</h2>
<div class="overflow-x-auto bg-white rounded-lg shadow-md">
<table class="min-w-full divide-y divide-gray-200">
<thead class="bg-teal-100">
<tr>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Event Name</th>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Date</th>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Status</th>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Description</th>
</tr>
</thead>
<tbody class="bg-white divide-y divide-gray-200">
<?php
$eventsList = $conn->prepare("SELECT event_name, event_date, status, description FROM events WHERE sport_id = ? AND event_date >= CURDATE() ORDER BY event_date ASC LIMIT 5");
$eventsList->bind_param("i", $sportId);
$eventsList->execute();
$eventsResult = $eventsList->get_result();
while($event = $eventsResult->fetch_assoc()):
switch(strtolower($event['status'])) {
    case 'approved': $statusClass = 'bg-green-500 text-white'; break;
    case 'pending': $statusClass = 'bg-yellow-400 text-black'; break;
    case 'rejected': $statusClass = 'bg-red-500 text-white'; break;
    default: $statusClass = 'bg-gray-300 text-black'; break;
}
?>
<tr class="hover-row">
<td class="px-6 py-4 whitespace-nowrap"><?php echo $event['event_name']; ?></td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo date('d M Y', strtotime($event['event_date'])); ?></td>
<td class="px-6 py-4 whitespace-nowrap">
<span class="px-2 py-1 rounded-full text-xs font-semibold <?php echo $statusClass; ?>"><?php echo ucfirst($event['status']); ?></span>
</td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo $event['description']; ?></td>
</tr>
<?php endwhile; $eventsList->close(); ?>
</tbody>
</table>
</div>
</div>

<!-- Team Members Table -->

<div class="mb-8">
<h2 class="text-xl font-semibold mb-4">Team Members</h2>
<div class="overflow-x-auto bg-white rounded-lg shadow-md">
<table class="min-w-full divide-y divide-gray-200">
<thead class="bg-teal-100">
<tr>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Name</th>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Email</th>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Role</th>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Played Before</th>
<th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Phone</th>
</tr>
</thead>
<tbody class="bg-white divide-y divide-gray-200">
<?php
$membersList = $conn->prepare("
SELECT username, email, role, played_before, phone 
FROM users 
WHERE sport_id = ? 
ORDER BY 
    CASE WHEN role='captain' THEN 1 WHEN role='coach' THEN 2 ELSE 3 END, 
    username ASC
LIMIT 10
");
$membersList->bind_param("i", $sportId);
$membersList->execute();
$membersResult = $membersList->get_result();
while($member = $membersResult->fetch_assoc()):
$rowClass = ($member['role'] == 'captain' || $member['role'] == 'coach') ? 'bg-yellow-100 font-semibold' : '';
?>
<tr class="hover-row <?php echo $rowClass; ?>">
<td class="px-6 py-4 whitespace-nowrap"><?php echo $member['username']; ?></td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo $member['email']; ?></td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo ucfirst($member['role']); ?></td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo $member['played_before'] ? 'Yes' : 'No'; ?></td>
<td class="px-6 py-4 whitespace-nowrap"><?php echo $member['phone']; ?></td>
</tr>
<?php endwhile; $membersList->close(); ?>
</tbody>
</table>
</div>
</div>

</div>
</body>
</html>
