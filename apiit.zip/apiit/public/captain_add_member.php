<?php
include 'db.php';
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$captain = $stmt->get_result()->fetch_assoc();
$stmt->close();

$captainProfileImage = $captain['profile_image'] ?? 'assets/images/default_user.png';
$captainId = $captain['user_id'];
$sportId = $captain['sport_id'];

// Handle Add Member form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $cb_number = $_POST['cb_number'] ?? '';
    $role = $_POST['role'] ?? 'player';
    $played_before = $_POST['played_before'] ?? 'no';
    
    // Check for duplicates
    $dupStmt = $conn->prepare("SELECT username, email, phone, cb_number FROM users WHERE username=? OR email=? OR phone=? OR cb_number=?");
    $dupStmt->bind_param("ssss", $username, $email, $phone, $cb_number);
    $dupStmt->execute();
    $dupResult = $dupStmt->get_result()->fetch_assoc();
    $dupStmt->close();

    if ($dupResult) {
        $error = "The following already exist: ";
        $errorFields = [];
        if ($dupResult['username'] === $username) $errorFields[] = "Username";
        if ($dupResult['email'] === $email) $errorFields[] = "Email";
        if ($dupResult['phone'] === $phone) $errorFields[] = "Phone";
        if ($dupResult['cb_number'] === $cb_number) $errorFields[] = "CB Number";
        $error .= implode(", ", $errorFields);
    } else {
        // Handle profile image upload
        $profilePath = 'assets/images/default_user.png'; // default
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['profile_image']['tmp_name'];
            $fileName = basename($_FILES['profile_image']['name']);
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedExt = ['jpg','jpeg','png','gif'];

            if (in_array($fileExt, $allowedExt)) {
                $newFileName = uniqid('profile_', true) . '.' . $fileExt;
                $uploadDir = 'uploads/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $destPath = $uploadDir . $newFileName;
                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    $profilePath = $destPath;
                }
            }
        }

        // Auto-generate password
        $passwordPlain = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 8);
        $passwordHashed = password_hash($passwordPlain, PASSWORD_DEFAULT);

        // Insert new member
        $insertStmt = $conn->prepare("INSERT INTO users (username, email, phone, cb_number, role, played_before, sport_id, password, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insertStmt->bind_param("ssssssiss", $username, $email, $phone, $cb_number, $role, $played_before, $sportId, $passwordHashed, $profilePath);

        if ($insertStmt->execute()) {
            header("Location: team_overview.php");
            exit();
        } else {
            $error = "Error: " . $insertStmt->error;
        }
        $insertStmt->close();
    }
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add New Member</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="captain.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>

 
    <!-- My Team Dropdown -->
    <div class="relative">
        <button id="myTeamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center">
            My Team
            <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
            </svg>
        </button>
        <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
            <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
            <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
            <a href="captain_budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
            <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
        </div>
    </div>

    <a href="captain_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
    <a href="captain_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
</div>

<!-- User menu -->
<div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="<?php echo htmlspecialchars($captainProfileImage); ?>" 
         alt="User Profile" 
         class="h-10 w-10 rounded-full border border-gray-400">
    <span class="text-black select-none">▼</span>
    <div id="userDropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
        <a href="captain_profile.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Profile</a>
        <a href="calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
        <a href="messages.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Messages</a>
        <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
    </div>
</div>
 

</nav>

<!-- Dropdown JS -->

<script>
const myTeamBtn = document.getElementById('myTeamBtn');
const myTeamDropdown = document.getElementById('myTeamDropdown');
myTeamBtn.addEventListener('click', (e) => { e.stopPropagation(); myTeamDropdown.classList.toggle('hidden'); });

const userMenu = document.querySelector('.user-menu');
const userDropdown = document.getElementById('userDropdown');
userMenu.addEventListener('click', (e) => { e.stopPropagation(); userDropdown.classList.toggle('hidden'); });

window.addEventListener('click', () => { myTeamDropdown.classList.add('hidden'); userDropdown.classList.add('hidden'); });
</script>

<div class="pt-24 max-w-md mx-auto bg-white p-6 rounded shadow-md mt-6">
    <h2 class="text-2xl font-bold mb-4">Add New Member</h2>

 
<?php if(isset($error) && $error): ?><p class="text-red-500 mb-4"><?php echo $error; ?></p><?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="add_member" value="1">

    <div class="mb-4">
        <input type="text" name="username" id="username" placeholder="Username" class="w-full border p-2 rounded" required>
        <span id="usernameError" class="text-red-500 text-sm hidden"></span>
    </div>

    <div class="mb-4">
        <input type="email" name="email" id="email" placeholder="Email" class="w-full border p-2 rounded" required>
        <span id="emailError" class="text-red-500 text-sm hidden"></span>
    </div>

    <div class="mb-4">
        <input type="text" name="phone" id="phone" placeholder="Phone" class="w-full border p-2 rounded">
        <span id="phoneError" class="text-red-500 text-sm hidden"></span>
    </div>

    <div class="mb-4">
        <input type="text" name="cb_number" id="cb_number" placeholder="CB Number" class="w-full border p-2 rounded" required>
        <span id="cbError" class="text-red-500 text-sm hidden"></span>
    </div>

    <div class="mb-4">
        <select name="role" class="w-full border p-2 rounded">
            <option value="player">Player</option>
            <option value="coach">Coach</option>
        </select>
    </div>

    <div class="mb-4">
        <select name="played_before" class="w-full border p-2 rounded">
            <option value="yes">Yes</option>
            <option value="no">No</option>
        </select>
    </div>

    <div class="mb-4">
        <label class="block mb-2 font-semibold">Profile Image</label>
        <input type="file" name="profile_image" accept="image/*" class="w-full border p-2 rounded">
    </div>

    <button type="submit" class="bg-teal-700 text-white px-4 py-2 rounded hover:bg-teal-900 w-full">Add Member</button>
</form>
 

</div>

<script>
async function checkField(fieldId, errorId) {
    const field = document.getElementById(fieldId);
    const errorSpan = document.getElementById(errorId);
    field.addEventListener('input', async () => {
        const value = field.value.trim();
        if (!value) {
            errorSpan.classList.add('hidden');
            return;
        }
        const response = await fetch(`check_field.php?field=${fieldId}&value=${encodeURIComponent(value)}`);
        const data = await response.json();
        if (data.exists) {
            errorSpan.textContent = `${fieldId.charAt(0).toUpperCase() + fieldId.slice(1)} already taken`;
            errorSpan.classList.remove('hidden');
        } else {
            errorSpan.classList.add('hidden');
        }
    });
}

checkField('username', 'usernameError');
checkField('email', 'emailError');
checkField('phone', 'phoneError');
checkField('cb_number', 'cbError');
</script>

</body>
</html>
