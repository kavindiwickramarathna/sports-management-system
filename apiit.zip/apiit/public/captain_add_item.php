<?php
include "db.php";
session_start();
header('Content-Type: application/json');

// Only captains allowed
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    echo json_encode(["status"=>"error","message"=>"Unauthorized"]);
    exit();
}

// POST data
$type = $_POST['type'] ?? '';
$name = trim($_POST['name'] ?? '');
$date = $_POST['date'] ?? '';
$time = $_POST['time'] ?? '';
$location = $_POST['location'] ?? '';

// Get captain's sport_id
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT sport_id FROM users WHERE email=?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$sport_id = $user['sport_id'] ?? 0;

if (!$sport_id || !$type || !$name || !$date) {
    echo json_encode(["status"=>"error","message"=>"Missing required fields"]);
    exit();
}

if ($type === 'event') {
    $stmt = $conn->prepare("INSERT INTO events (sport_id, event_name, event_date) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $sport_id, $name, $date);
    if ($stmt->execute()) {
        $id = $stmt->insert_id;
        $item = ["type"=>"event","event_id"=>$id,"event_name"=>$name,"date"=>$date];
        echo json_encode(["status"=>"success","message"=>"Event added successfully","item"=>$item]);
    } else {
        echo json_encode(["status"=>"error","message"=>"Failed to add event"]);
    }
} elseif ($type === 'session') {
    $stmt = $conn->prepare("INSERT INTO sessions (sport_id, description, session_date, session_time, location) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $sport_id, $name, $date, $time, $location);
    if ($stmt->execute()) {
        $id = $stmt->insert_id;
        $item = ["type"=>"session","session_id"=>$id,"description"=>$name,"date"=>$date,"session_time"=>$time,"location"=>$location];
        echo json_encode(["status"=>"success","message"=>"Session added successfully","item"=>$item]);
    } else {
        echo json_encode(["status"=>"error","message"=>"Failed to add session"]);
    }
} else {
    echo json_encode(["status"=>"error","message"=>"Invalid type"]);
}
