<?php
include 'db.php';
session_start();

// Only allow players
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'player') {
    header("Location: login.php");
    exit();
}

// Get player info
$playerEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
$stmt->bind_param("s", $playerEmail);
$stmt->execute();
$player = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Profile image for navbar
$profileImage = $player['profile_image'] ?? 'assets/images/default_profile.png';

// Message to show success/failure
$message = "";

// Handle participation submission
if (isset($_POST['participate'])) {
    $event_id = $_POST['event_id'];
    $status = $_POST['status'] ?? null;

    if ($status) {
        $checkStmt = $conn->prepare("SELECT * FROM event_participation WHERE player_id=? AND event_id=?");
        $checkStmt->bind_param("ii", $player['user_id'], $event_id);
        $checkStmt->execute();
        $exists = $checkStmt->get_result()->num_rows;

        if ($exists) {
            $updateStmt = $conn->prepare("UPDATE event_participation SET status=? WHERE player_id=? AND event_id=?");
            $updateStmt->bind_param("sii", $status, $player['user_id'], $event_id);
            $updateStmt->execute();
            $message = "Your response has been updated!";
        } else {
            $insertStmt = $conn->prepare("INSERT INTO event_participation (player_id, event_id, status) VALUES (?,?,?)");
            $insertStmt->bind_param("iis", $player['user_id'], $event_id, $status);
            $insertStmt->execute();
            $message = "Your response has been recorded!";
        }
    } else {
        $message = "Please select a valid response.";
    }
}

// Handle remove response
if (isset($_POST['remove_response'])) {
    $event_id = $_POST['event_id'];
    $deleteStmt = $conn->prepare("DELETE FROM event_participation WHERE player_id=? AND event_id=?");
    $deleteStmt->bind_param("ii", $player['user_id'], $event_id);
    $deleteStmt->execute();
    $message = "Your response has been removed!";
}

// Fetch upcoming events **ONLY APPROVED**
$stmt = $conn->prepare("SELECT * FROM events WHERE sport_id=? AND status='approved' ORDER BY event_date ASC");
$stmt->bind_param("i", $player['sport_id']);
$stmt->execute();
$events = $stmt->get_result();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Player Events</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 pt-20 min-h-screen">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
        <a href="player.php" class="font-semibold text-black hover:text-yellow-400">Home</a>
        <a href="player_dashboard.php" class="font-semibold text-black hover:text-yellow-400">Dashboard</a>
        <a href="player_myteam.php" class="font-semibold text-black hover:text-yellow-400">My Team</a>
        <a href="player_events.php" class="font-semibold text-black hover:text-yellow-400">Events</a>
        <a href="player_calendar.php" class="font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>

<div class="user-menu relative">
    <img src="<?php echo htmlspecialchars($profileImage); ?>" 
         alt="User Profile" 
         class="h-10 w-10 rounded-full border border-gray-400 cursor-pointer"
         onclick="toggleDropdown()">
    <span class="text-black select-none cursor-pointer" onclick="toggleDropdown()">▼</span>

<div class="user-dropdown absolute right-0 top-full mt-1 bg-white shadow-md rounded-md w-48 py-2 z-50 hidden">
    <a href="player_view.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
    <a href="player_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
    <a href="attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
    <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
</div>
</div>
</nav>

<script>
function toggleDropdown() {
    const dropdown = document.querySelector('.user-dropdown');
    dropdown.classList.toggle('hidden');
}

window.addEventListener('click', e => {
    if (!e.target.closest('.user-menu')) {
        document.querySelector('.user-dropdown').classList.add('hidden');
    }
});
</script>

<div class="max-w-5xl mx-auto p-6">

<?php if($message): ?>
<div class="mb-4 p-3 bg-blue-100 text-blue-700 rounded"><?php echo $message; ?></div>
<?php endif; ?>

<h1 class="text-3xl font-bold mb-4">Upcoming Events</h1>

<table class="min-w-full bg-white shadow-md rounded overflow-hidden">
<thead class="bg-gray-200">
<tr>
<th class="px-4 py-2 text-left">Event Name</th>
<th class="px-4 py-2 text-left">Date</th>
<th class="px-4 py-2 text-left">Description</th>
<th class="px-4 py-2 text-left">Your Response</th>
</tr>
</thead>

<tbody>
<?php while($row = $events->fetch_assoc()):
    $checkStmt = $conn->prepare("SELECT status FROM event_participation WHERE player_id=? AND event_id=?");
    $checkStmt->bind_param("ii", $player['user_id'], $row['event_id']);
    $checkStmt->execute();
    $result = $checkStmt->get_result()->fetch_assoc();
    $player_status = $result['status'] ?? '';
?>
<tr class="border-b">
<td class="px-4 py-2"><?php echo htmlspecialchars($row['event_name']); ?></td>
<td class="px-4 py-2"><?php echo htmlspecialchars($row['event_date']); ?></td>
<td class="px-4 py-2"><?php echo htmlspecialchars($row['description']); ?></td>
<td class="px-4 py-2">
<form method="POST" class="flex flex-wrap items-center gap-2">
<input type="hidden" name="event_id" value="<?php echo $row['event_id']; ?>">
<input type="hidden" name="participate" value="1">

<button type="submit" name="status" value="Yes" class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-800">Yes</button>
<button type="submit" name="status" value="No" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-800">No</button>

<?php if($player_status): ?>
<span class="font-semibold ml-2"><?php echo htmlspecialchars($player_status); ?></span>
<button type="submit" name="remove_response" value="1" class="bg-gray-500 text-white px-3 py-1 rounded hover:bg-gray-700">Remove Response</button>
<?php endif; ?>

</form>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

</body>
</html>
