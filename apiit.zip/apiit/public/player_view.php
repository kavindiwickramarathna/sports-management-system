<?php
include 'db.php';
session_start();

// Only allow logged-in players
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'player') {
    header("Location: login.php");
    exit();
}

// Get logged-in player info
$playerEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND role='player' LIMIT 1");
$stmt->bind_param("s", $playerEmail);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $player = $result->fetch_assoc();
} else {
    echo "No player found.";
    exit();
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Player Profile</title>
<style>
    body, html {
        height: 100%;
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f0f0f0;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
    }
    .profile-container {
        width: 420px;
        background-color: #fff;
        padding: 30px 25px;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
        text-align: center;
        margin-bottom: 20px;
    }
    .profile-container h2 {
        margin-bottom: 25px;
        color: black;
        font-size: 24px;
    }
    .profile-image {
        width: 130px;
        height: 130px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid teal;
        margin-bottom: 20px;
    }
    .profile-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        border-bottom: 1px solid #f0f0f0;
    }
    .profile-row:last-child {
        border-bottom: none;
    }
    .profile-label {
        font-weight: bold;
        color: #333;
    }
    .profile-value {
        color: #555;
        text-align: right;
    }
    .back-button {
        background-color: teal;
        color: white;
        padding: 10px 25px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
    }
    .back-button:hover {
        background-color: #006666;
    }
</style>
</head>
<body>
<div class="profile-container">
    <h2>Player Profile</h2>
    <img class="profile-image" src="<?php echo htmlspecialchars($player['profile_image'] ?: 'assets/images/default_user.png'); ?>" alt="Profile Image">

 
<div class="profile-row">
    <div class="profile-label">User ID</div>
    <div class="profile-value"><?php echo $player['user_id']; ?></div>
</div>
<div class="profile-row">
    <div class="profile-label">CB Number</div>
    <div class="profile-value"><?php echo htmlspecialchars($player['cb_number']); ?></div>
</div>
<div class="profile-row">
    <div class="profile-label">Username</div>
    <div class="profile-value"><?php echo htmlspecialchars($player['username']); ?></div>
</div>
<div class="profile-row">
    <div class="profile-label">Email</div>
    <div class="profile-value"><?php echo htmlspecialchars($player['email']); ?></div>
</div>
<div class="profile-row">
    <div class="profile-label">Phone</div>
    <div class="profile-value"><?php echo htmlspecialchars($player['phone']); ?></div>
</div>
<div class="profile-row">
    <div class="profile-label">Role</div>
    <div class="profile-value"><?php echo htmlspecialchars($player['role']); ?></div>
</div>
<div class="profile-row">
    <div class="profile-label">Sport ID</div>
    <div class="profile-value"><?php echo htmlspecialchars($player['sport_id']); ?></div>
</div>
<div class="profile-row">
    <div class="profile-label">Played Before</div>
    <div class="profile-value"><?php echo htmlspecialchars($player['played_before']); ?></div>
</div>
 

</div>

<button class="back-button" onclick="history.back()">Go Back</button>

</body>
</html>
