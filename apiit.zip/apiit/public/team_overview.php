<?php
include 'db.php';
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$captain = $stmt->get_result()->fetch_assoc();
$stmt->close();

$captainId = $captain['user_id'];
$sportId = $captain['sport_id'];

$profileImage = !empty($captain['profile_image']) ? $captain['profile_image'] : 'assets/images/default_user.png';

// Handle search
$searchTerm = '';
$searchResults = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_member'])) {
    $searchTerm = trim($_POST['search_term']);
    $likeTerm = "%$searchTerm%";
    $stmt = $conn->prepare("SELECT * FROM users WHERE sport_id=? AND username LIKE ? ORDER BY FIELD(role,'coach') DESC, FIELD(user_id,?) DESC, username ASC");
    $stmt->bind_param("isi", $sportId, $likeTerm, $captainId);
    $stmt->execute();
    $searchResults = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// Fetch all team members
$teamStmt = $conn->prepare("
    SELECT * FROM users 
    WHERE sport_id = ? 
    ORDER BY FIELD(role, 'coach') DESC, FIELD(user_id, ?) DESC, username ASC
");
$teamStmt->bind_param("ii", $sportId, $captainId);
$teamStmt->execute();
$teamMembers = $teamStmt->get_result();
$teamStmt->close();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>Team Overview</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
        <a href="captain.php" class="font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>

 
    <!-- My Team Dropdown -->
    <div class="relative">
        <button id="myTeamBtn" class="font-semibold text-black hover:text-yellow-400 transition flex items-center">
            My Team
            <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
            </svg>
        </button>
        <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
            <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
            <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
            <a href="budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
            <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
        </div>
    </div>

    <a href="captain_events.php" class="font-semibold text-black hover:text-yellow-400 transition">Events</a>
    <a href="captain_calendar.php" class="font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
</div>

<!-- User menu -->
<div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400">
    <span class="text-black select-none">▼</span>
    
    <!-- Dropdown -->
    <div id="userDropdown" class="absolute right-0 top-full hidden bg-white shadow-md rounded-md mt-2 w-48 py-2 z-50">
        <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
        <a href="captain_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
        <a href="captain_account_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
        <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
    </div>
</div>


</div>
 

</nav>

<script>
const myTeamBtn = document.getElementById('myTeamBtn');
const myTeamDropdown = document.getElementById('myTeamDropdown');
myTeamBtn.addEventListener('click', e=>{ e.stopPropagation(); myTeamDropdown.classList.toggle('hidden'); });

const userMenu = document.querySelector('.user-menu');
const userDropdown = document.getElementById('userDropdown');
userMenu.addEventListener('click', e=>{ e.stopPropagation(); userDropdown.classList.toggle('hidden'); });

window.addEventListener('click', ()=>{ myTeamDropdown.classList.add('hidden'); userDropdown.classList.add('hidden'); });
</script>

<div class="pt-24 px-6 lg:px-12 w-full max-w-7xl mx-auto">
 
 
<div class="flex justify-between items-center mb-6">
    <h1 class="text-3xl font-bold">Team Overview</h1>
    <a href="captain_add_member.php" class="bg-teal-700 text-white px-4 py-2 rounded hover:bg-teal-900">Add New Member</a>
</div>

<!-- Search Bar -->
<form method="POST" class="mb-6 flex space-x-2">
    <input type="text" name="search_term" placeholder="Search member..." 
           class="border p-2 rounded w-64" value="<?php echo htmlspecialchars($searchTerm); ?>">
    <button type="submit" name="search_member" class="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-900">Search</button>
</form>

<!-- Search Results -->
<?php if(!empty($searchTerm) && !empty($searchResults)): ?>
<div class="relative bg-white p-6 rounded shadow-md mb-6">
    <button onclick="window.location.href='team_overview.php';" 
            class="absolute top-2 right-2 text-gray-600 hover:text-red-600 text-xl font-bold">&times;</button>
    <h2 class="text-2xl font-bold mb-4">Search Results for "<?php echo htmlspecialchars($searchTerm); ?>"</h2>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <?php foreach($searchResults as $member): ?>
        <a href="member_profile.php?id=<?php echo $member['user_id']; ?>" class="block p-0">
            <div class="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-xl transition cursor-pointer">
                <img src="<?php echo htmlspecialchars($member['profile_image'] ?? 'assets/images/default_user.png'); ?>" 
                     alt="<?php echo $member['username']; ?>" class="h-24 w-24 rounded-full mb-4 mx-auto">
                <h3 class="text-lg font-semibold"><?php echo $member['username']; ?></h3>
                <p class="text-gray-700 font-semibold"><?php echo ucfirst($member['role']); ?></p>
                <p class="text-gray-500">Email: <?php echo $member['email']; ?></p>
                <p class="text-gray-500">Phone: <?php echo $member['phone']; ?></p>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
</div>
<?php elseif(!empty($searchTerm)): ?>
<div class="relative bg-white p-6 rounded shadow-md mb-6">
    <button onclick="window.location.href='team_overview.php';" 
            class="absolute top-2 right-2 text-gray-600 hover:text-red-600 text-xl font-bold">&times;</button>
    <p class="text-gray-500 text-center">No member found for "<?php echo htmlspecialchars($searchTerm); ?>"</p>
</div>
<?php endif; ?>

<!-- Team Members Grid -->
<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
    <?php if($teamMembers->num_rows > 0): ?>
        <?php while($member = $teamMembers->fetch_assoc()): ?>
            <?php
            $isCaptain = $member['user_id'] == $captainId;
            $isCoach = $member['role'] == 'coach';
            $cardColor = $isCaptain ? 'bg-yellow-200' : ($isCoach ? 'bg-red-200' : 'bg-white');
            $roleLabel = $isCaptain ? 'Captain' : ucfirst($member['role']);
            ?>
            <a href="member_profile.php?id=<?php echo $member['user_id']; ?>" class="block p-0">
                <div class="<?php echo $cardColor; ?> p-6 rounded-lg shadow-md text-center hover:shadow-xl transition cursor-pointer">
                    <img src="<?php echo htmlspecialchars($member['profile_image'] ?? 'assets/images/default_user.png'); ?>" 
                         alt="<?php echo $member['username']; ?>" class="h-24 w-24 rounded-full mb-4 mx-auto">
                    <h3 class="text-lg font-semibold"><?php echo $member['username']; ?></h3>
                    <p class="text-gray-700 font-semibold"><?php echo $roleLabel; ?></p>
                    <p class="text-gray-500">Email: <?php echo $member['email']; ?></p>
                    <p class="text-gray-500">Phone: <?php echo $member['phone']; ?></p>
                    <p class="text-gray-500">Played Before: <?php echo ucfirst($member['played_before']); ?></p>
                    <p class="text-gray-500">CB Number: <?php echo htmlspecialchars($member['cb_number']); ?></p>
                </div>
            </a>
        <?php endwhile; ?>
    <?php else: ?>
        <p class="text-gray-500 col-span-full text-center">No members found.</p>
    <?php endif; ?>
</div>
 

</div>
</body>
</html>
