<?php
include 'db.php';

if (!isset($_GET['user_id'])) {
    header("Location: players.php");
    exit();
}

$user_id = intval($_GET['user_id']);
$errors = [];

// Handle edit submission
if (isset($_POST['edit_player'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $phone = $_POST['phone'];
    $role = $_POST['role'];
    $sport_id = $_POST['sport_id'];
    $played_before = $_POST['played_before'];
    $profile_image = $_POST['old_image'];

    // Handle new image upload
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $uploadDir = "assets/images/";
        $profile_image = $uploadDir . basename($_FILES['profile_image']['name']);
        move_uploaded_file($_FILES['profile_image']['tmp_name'], $profile_image);
    }

    if ($username != "" && $email != "") {
        $stmt = $conn->prepare("UPDATE users SET username=?, email=?, phone=?, role=?, sport_id=?, played_before=?, profile_image=? WHERE user_id=?");
        $stmt->bind_param("ssssissi", $username, $email, $phone, $role, $sport_id, $played_before, $profile_image, $user_id);
        if ($stmt->execute()) {
            header("Location: players.php");
            exit();
        } else {
            $errors[] = "Failed to update player details.";
        }
    } else {
        $errors[] = "Name and Email cannot be empty.";
    }
}

// Handle delete
if (isset($_POST['delete_player'])) {
    $stmt = $conn->prepare("DELETE FROM users WHERE user_id=?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    header("Location: players.php");
    exit();
}

// Fetch player details
$stmt = $conn->prepare("SELECT u.*, s.sport_name FROM users u LEFT JOIN sports s ON u.sport_id = s.sport_id WHERE user_id=? AND (role='player' OR role='captain')");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: players.php");
    exit();
}
$player = $result->fetch_assoc();

// Fetch all sports
$sports = $conn->query("SELECT * FROM sports");

function getImageFile($imagePath) {
    if (!empty($imagePath) && file_exists($imagePath)) return $imagePath;
    return "assets/images/default.jpg";
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Player Details - Admin Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.nav-item:hover { color: #facc15; }
.active { color: #facc15; }

.dropdown-content, .user-dropdown {
display: none;
position: absolute;
background-color: white;
min-width: 160px;
box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
z-index: 10;
}

.dropdown-content a, .user-dropdown a {
color: black;
padding: 10px 16px;
text-decoration: none;
display: block;
}

.dropdown-content a:hover, .user-dropdown a:hover {
background-color: #facc15;
color: white;
}

.dropdown:hover .dropdown-content,
.user-menu:hover .user-dropdown {
display: block;
} </style>

</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
        <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>
        <div class="dropdown relative">
            <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
            <div class="dropdown-content rounded-md">
                <a href="all.php">All Teams</a>
                <a href="coaches.php">Coaches</a>
                <a href="players.php">Player Search</a>
            </div>
        </div>
        <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
        <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>

 
<div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
    <span class="text-black">▼</span>
    <div class="user-dropdown absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
        <a href="admin_profile.php">Profile</a>
        <a href="calendar.php">Calendar</a>
        <a href="messages.php">Messages</a>
        <a href="reports.php">Reports</a>
        <a href="logout.php">Logout</a>
    </div>
</div>
 

</nav>

<!-- Main Content -->

<main class="flex-grow mt-28 px-6 md:px-10 pb-20">
<div class="max-w-3xl mx-auto bg-white shadow-md rounded-md p-6">
<h1 class="text-2xl font-bold mb-6">Player Profile</h1>

<?php if (!empty($errors)) {
    foreach ($errors as $error) echo "<p class='text-red-500 mb-2'>$error</p>";
} ?>

<div class="flex flex-col md:flex-row gap-6">
    <div class="flex-shrink-0">
        <img src="<?php echo getImageFile($player['profile_image']); ?>" class="w-48 h-48 object-contain rounded-md border">
    </div>
    <div class="flex-grow">
        <form method="POST" enctype="multipart/form-data" class="flex flex-col gap-4">
            <label>Name:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($player['username']); ?>" class="border px-3 py-2 rounded-md" required>

 
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($player['email']); ?>" class="border px-3 py-2 rounded-md" required>

        <label>Phone:</label>
        <input type="text" name="phone" value="<?php echo htmlspecialchars($player['phone']); ?>" class="border px-3 py-2 rounded-md">

        <label>Role:</label>
        <select name="role" class="border px-3 py-2 rounded-md" required>
            <option value="player" <?php if($player['role']=='player') echo 'selected'; ?>>Player</option>
            <option value="captain" <?php if($player['role']=='captain') echo 'selected'; ?>>Captain</option>
        </select>

        <label>Sport:</label>
        <select name="sport_id" class="border px-3 py-2 rounded-md" required>
            <option value="">Select Sport</option>
            <?php
            $sports->data_seek(0);
            while($sport = $sports->fetch_assoc()) { ?>
                <option value="<?php echo $sport['sport_id']; ?>" <?php if($sport['sport_id']==$player['sport_id']) echo "selected"; ?>>
                    <?php echo $sport['sport_name']; ?>
                </option>
            <?php } ?>
        </select>

        <label>Played Before:</label>
        <select name="played_before" class="border px-3 py-2 rounded-md">
            <option value="yes" <?php if($player['played_before']=='yes') echo 'selected'; ?>>Yes</option>
            <option value="no" <?php if($player['played_before']=='no') echo 'selected'; ?>>No</option>
        </select>

        <label>Profile Image:</label>
        <input type="file" name="profile_image">
        <input type="hidden" name="old_image" value="<?php echo htmlspecialchars($player['profile_image']); ?>">

        <div class="flex gap-4 mt-4">
            <button type="submit" name="edit_player" class="bg-teal-800 text-white px-4 py-2 rounded-md hover:bg-teal-700">Save Changes</button>
            <button type="submit" name="delete_player" class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-500" onclick="return confirm('Are you sure you want to remove this player?')">Remove Player</button>
            <a href="players.php" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-400">Back</a>
        </div>
    </form>
</div>
 

</div>
</div>
</main>

</body>
</html>
