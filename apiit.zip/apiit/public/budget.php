<?php
include "db.php";
session_start();

// Only admins allowed
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Handle deadline creation
if (isset($_POST['set_deadline'])) {
    $new_deadline = $_POST['deadline_date'];
    if ($new_deadline >= date("Y-m-d")) {
        $stmt = $conn->prepare("INSERT INTO budget_deadline (deadline_date) VALUES (?)");
        $stmt->bind_param("s", $new_deadline);
        $stmt->execute();
        $stmt->close();
        echo "<script>alert('Deadline set successfully!'); window.location='budget.php';</script>";
    } else {
        echo "<script>alert('Deadline cannot be in the past');</script>";
    }
}

// Handle status update
if (isset($_POST['update_status'])) {
    $request_id = $_POST['request_id'];
    $new_status = strtolower($_POST['status']);

    $check = $conn->prepare("SELECT status, due_date FROM budget_requests WHERE request_id=?");
    $check->bind_param("i", $request_id);
    $check->execute();
    $result = $check->get_result()->fetch_assoc();
    $check->close();

    if (!$result) { echo "<script>alert('Request not found'); window.location='budget.php';</script>"; exit(); }

    $current_status = strtolower($result['status']);
    $due_date = $result['due_date'];
    $today = date("Y-m-d");

    if ($due_date < $today) { echo "<script>alert('Budget request has expired!'); window.location='budget.php';</script>"; exit(); }
    if ($current_status !== 'pending') { echo "<script>alert('Status cannot be changed again!'); window.location='budget.php';</script>"; exit(); }

    $update = $conn->prepare("UPDATE budget_requests SET status=?, approved_at=NOW() WHERE request_id=?");
    $update->bind_param("si", $new_status, $request_id);
    $update->execute();
    $update->close();

    echo "<script>alert('Status updated successfully!'); window.location='budget.php';</script>";
    exit();
}

// Filter Logic
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$query = "SELECT * FROM budget_requests";

if ($filter === "overdue") {
    $query .= " WHERE due_date < CURDATE() AND status='pending'";
} elseif ($filter === "7days") {
    $query .= " WHERE due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)";
} elseif ($filter === "30days") {
    $query .= " WHERE due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
}

$query .= " ORDER BY requested_at DESC";
$budgetRequests = $conn->query($query);

// Fetch current deadline
$deadlineRow = $conn->query("SELECT * FROM budget_deadline ORDER BY id DESC LIMIT 1")->fetch_assoc();
$current_deadline = $deadlineRow ? $deadlineRow['deadline_date'] : null;
$today = date("Y-m-d");
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Budget Requests</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
/* Dropdown and hover effects */
.nav-item:hover { color: #facc15; }
.active { color: #facc15; }

.dropdown-content, .user-dropdown {
display: none;
position: absolute;
background-color: white;
min-width: 160px;
box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
z-index: 10;
}

.dropdown-content a, .user-dropdown a {
color: black;
padding: 10px 16px;
text-decoration: none;
display: block;
}

.dropdown-content a:hover, .user-dropdown a:hover {
background-color: #facc15;
color: white;
}

.dropdown:hover .dropdown-content,
.user-menu:hover .user-dropdown {
display: block;
} </style>

</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">

 
<a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
<a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

<div class="dropdown relative">
  <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
  <div class="dropdown-content rounded-md">
    <a href="all.php">All Teams</a>
    <a href="coaches.php">Coaches</a>
    <a href="players.php">Player Search</a>
  </div>
</div>

<a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
  <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
<a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
 

  </div>

  <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
    <span class="text-black">▼</span>
    <div class="user-dropdown rounded-md right-0">
      <a href="admin_profile.php">Profile</a>
      <a href="calendar.php">Calendar</a>
      <a href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<!-- Main Content -->

<div class="container mx-auto mt-32 p-6 bg-white rounded shadow-md">

<h1 class="text-3xl font-bold mb-4">Budget Requests</h1>

<!-- Set Deadline -->

<form method="POST" class="mb-6 flex items-center gap-3">
    <label class="font-semibold">Set Budget Submission Deadline:</label>
    <input type="date" name="deadline_date" required class="p-2 border rounded">
    <button type="submit" name="set_deadline" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-800">Set Deadline</button>
    <?php if($current_deadline): ?>
        <span class="ml-4 font-semibold text-red-600">Current Deadline: <?php echo $current_deadline; ?></span>
    <?php endif; ?>
</form>

<!-- Filter Buttons -->

<div class="mb-4 flex gap-2">
    <a href="budget.php?filter=all" class="px-3 py-1 rounded <?php echo $filter=='all'?'bg-yellow-400 text-white':'bg-gray-200'; ?>">All</a>
    <a href="budget.php?filter=overdue" class="px-3 py-1 rounded <?php echo $filter=='overdue'?'bg-yellow-400 text-white':'bg-gray-200'; ?>">Overdue</a>
    <a href="budget.php?filter=7days" class="px-3 py-1 rounded <?php echo $filter=='7days'?'bg-yellow-400 text-white':'bg-gray-200'; ?>">Next 7 Days</a>
    <a href="budget.php?filter=30days" class="px-3 py-1 rounded <?php echo $filter=='30days'?'bg-yellow-400 text-white':'bg-gray-200'; ?>">Next 30 Days</a>
</div>

<!-- Budget Table -->

<table class="w-full border border-gray-300 rounded">
<thead class="bg-gray-200">
<tr>
<th class="p-2 border">ID</th>
<th class="p-2 border">Captain ID</th>
<th class="p-2 border">Sport ID</th>
<th class="p-2 border">Amount</th>
<th class="p-2 border">File</th>
<th class="p-2 border">Status</th>
<th class="p-2 border">Requested At</th>
<th class="p-2 border">Due Date</th>
<th class="p-2 border">Approved At</th>
<th class="p-2 border">Action</th>
</tr>
</thead>
<tbody>
<?php while($row = $budgetRequests->fetch_assoc()): ?>
<?php 
    $can_edit = (strtolower($row['status']) === 'pending' && $row['due_date'] >= $today); 
?>
<tr class="text-center border hover:bg-gray-50">
<td class="p-2 border"><?php echo $row['request_id']; ?></td>
<td class="p-2 border"><?php echo $row['captain_id']; ?></td>
<td class="p-2 border"><?php echo $row['sport_id']; ?></td>
<td class="p-2 border text-green-600 font-semibold"><?php echo number_format($row['amount'],2); ?></td>
<td class="p-2 border"><?php echo $row['description']; ?></td>
<td class="p-2 border"><?php echo ucfirst($row['status']); ?></td>
<td class="p-2 border"><?php echo $row['requested_at']; ?></td>
<td class="p-2 border"><?php echo $row['due_date']; ?></td>
<td class="p-2 border"><?php echo $row['approved_at'] ?: '-'; ?></td>
<td class="p-2 border">
<?php if($can_edit): ?>
<form method="POST" class="flex gap-2 justify-center">
<input type="hidden" name="request_id" value="<?php echo $row['request_id']; ?>">
<button name="status" value="approved" class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded">Approve</button>
<button name="status" value="rejected" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded">Reject</button>
<input type="hidden" name="update_status" value="1">
</form>
<?php else: ?>
<span class="text-gray-400 text-sm">No actions</span>
<?php endif; ?>
</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>

</div>
</body>
</html>
