<?php
// coach_attendance_download.php
include 'db.php';
session_start();

// Only allow logged-in coaches
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach') {
    header("Location: login.php");
    exit();
}

$coachEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT user_id, username FROM users WHERE email=? AND role='coach'");
$stmt->bind_param("s", $coachEmail);
$stmt->execute();
$result = $stmt->get_result();
$coach = $result->fetch_assoc();

if (!$coach) {
    die("Coach not found!");
}

$coach_id = $coach['user_id'];
$coach_name = $coach['username'];

// Get month and year from GET
$month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Fetch attendance records
$attendance_stmt = $conn->prepare("
    SELECT a.date, s.sport_name, a.status, a.remarks
    FROM attendance a
    LEFT JOIN sports s ON a.sport_id = s.sport_id
    WHERE a.user_id=? AND MONTH(a.date)=? AND YEAR(a.date)=?
    ORDER BY a.date ASC
");
$attendance_stmt->bind_param("iii", $coach_id, $month, $year);
$attendance_stmt->execute();
$attendance_result = $attendance_stmt->get_result();

// Output CSV headers
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="attendance_'.$coach_name.'_'.$month.'_'.$year.'.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Date', 'Sport', 'Status', 'Remarks']);

// Loop through data
while ($row = $attendance_result->fetch_assoc()) {
    fputcsv($output, [
        $row['date'],
        $row['sport_name'],
        $row['status'],
        $row['remarks']
    ]);
}

fclose($output);
exit();
