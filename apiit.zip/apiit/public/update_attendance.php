<?php
include 'db.php';
$data = json_decode(file_get_contents('php://input'), true);
$user_id = $data['user_id'];
$date = $data['date'];
$status = $data['status'];
$remarks = $data['remarks'];

// Check if record exists
$stmt = $conn->prepare("SELECT attendance_id FROM attendance WHERE user_id=? AND date=?");
$stmt->bind_param("is", $user_id, $date);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    $row = $result->fetch_assoc();
    $update = $conn->prepare("UPDATE attendance SET status=?, remarks=? WHERE attendance_id=?");
    $update->bind_param("ssi",$status,$remarks,$row['attendance_id']);
    $update->execute();
}else{
    $insert = $conn->prepare("INSERT INTO attendance (user_id, sport_id, date, status, remarks) VALUES (?, 8, ?, ?, ?)");
    $insert->bind_param("isss",$user_id,$date,$status,$remarks);
    $insert->execute();
}
echo json_encode(['success'=>true]);
?>
