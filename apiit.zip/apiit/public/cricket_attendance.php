<?php
include 'db.php';

// Define sport_id for Cricket team
$sport_id = 1;

// Handle update if edit/save is clicked
if(isset($_POST['update_attendance'])){
    $attendance_id = $_POST['attendance_id'];
    $status = $_POST['status'];
    $remarks = $_POST['remarks'];

    $updateStmt = $conn->prepare("UPDATE attendance SET status=?, remarks=? WHERE attendance_id=?");
    $updateStmt->bind_param("ssi", $status, $remarks, $attendance_id);
    $updateStmt->execute();
    echo json_encode(['success'=>true]);
    exit;
}

// Fetch selected date or default today
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// Fetch attendance for the given date and sport_id
$attendanceStmt = $conn->prepare("SELECT a.attendance_id, a.user_id, a.status, a.remarks, u.username, u.profile_image, u.role
                                  FROM attendance a
                                  JOIN users u ON a.user_id = u.user_id
                                  WHERE a.sport_id=? AND a.date=? AND (u.role='player' OR u.role='captain')
                                  ORDER BY u.user_id ASC");
$attendanceStmt->bind_param("is", $sport_id, $date);
$attendanceStmt->execute();
$attendanceResult = $attendanceStmt->get_result();
$attendanceData = [];
while($row = $attendanceResult->fetch_assoc()){
    $attendanceData[$row['user_id']] = $row;
}

// Fetch all cricket users (role = player or captain)
$usersStmt = $conn->prepare("SELECT user_id, username, profile_image, role FROM users WHERE sport_id=? AND (role='player' OR role='captain') ORDER BY user_id ASC");
$usersStmt->bind_param("i", $sport_id);
$usersStmt->execute();
$usersResult = $usersStmt->get_result();
$allUsers = [];
while($row = $usersResult->fetch_assoc()){
    $allUsers[$row['user_id']] = $row;
}

// Prepare final attendance
$finalAttendance = [];
foreach($allUsers as $uid => $user){
    if(isset($attendanceData[$uid])){
        $finalAttendance[] = $attendanceData[$uid];
    }
}

// Fetch all distinct attendance dates for cricket (sport_id = 1)
$dateStmt = $conn->prepare("SELECT DISTINCT `date` FROM attendance WHERE sport_id=? ORDER BY `date` ASC");
$dateStmt->bind_param("i", $sport_id);
$dateStmt->execute();
$dateResult = $dateStmt->get_result();

$attendanceDates = [];
while($row = $dateResult->fetch_assoc()){
    $attendanceDates[] = $row['date']; // format: YYYY-MM-DD
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attendance - Cricket</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<style>
.nav-item:hover { color: #facc15; }
.active { color: #facc15; }
.dropdown-content, .user-dropdown { display: none; position: absolute; background-color: white; min-width: 160px; box-shadow: 0px 4px 8px rgba(0,0,0,0.2); z-index: 10; }
.dropdown-content a, .user-dropdown a { color: black; padding: 10px 16px; text-decoration: none; display: block; }
.dropdown-content a:hover, .user-dropdown a:hover { background-color: #facc15; color: white; }
.dropdown:hover .dropdown-content, .user-menu:hover .user-dropdown { display: block; }
.session-dot { position: absolute; bottom: 4px; left: 50%; transform: translateX(-50%); width: 6px; height: 6px; border-radius: 50%; background-color: red; }
.flatpickr-disabled { color: #ccc; pointer-events: none; opacity: 0.5; }
.captain-row td { font-weight: bold; }
</style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- NAVIGATION BAR -->
<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
    <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
    <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

    <div class="dropdown relative">
      <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
      <div class="dropdown-content rounded-md">
        <a href="all.php">All Teams</a>
        <a href="coaches.php">Coaches</a>
        <a href="players.php">Player Search</a>
      </div>
    </div>

    <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
    <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
  </div>

  <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
    <span class="text-black">▼</span>
    <div class="user-dropdown rounded-md right-0">
      <a href="admin_profile.php">Profile</a>
      <a href="calendar.php">Calendar</a>
      <a href="messages.php">Messages</a>
      <a href="reports.php">Reports</a>
      <a href="logout.php">Logout</a>
    </div>
  </div>
</nav>
<main class="flex-grow pt-24 px-8 flex space-x-6">

  <!-- Attendance Section -->
  <div class="flex-grow">
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-2xl font-bold text-black">Attendance - Cricket</h1>
      <div class="flex space-x-2">
        <button id="edit-btn" class="bg-teal-500 hover:bg-teal-600 text-white font-semibold px-4 py-2 rounded-md">Edit</button>
        <button id="download-btn" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold px-4 py-2 rounded-md">Download PDF</button>
      </div>
    </div>

    <div class="flex items-center space-x-4 mb-6">
      <label for="attendance-date" class="font-semibold text-black">Select Date:</label>
      <input type="text" id="attendance-date" class="bg-white rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-700" value="<?php echo $date; ?>">
    </div>

    <div class="overflow-x-auto" id="attendance-table-wrapper">
      <table id="attendance-table" class="min-w-full bg-white shadow-md rounded-lg overflow-hidden">
        <thead class="bg-teal-500 text-white">
          <tr>
            <th class="py-3 px-4 text-left">Student Number</th>
            <th class="py-3 px-4 text-left">Profile</th>
            <th class="py-3 px-4 text-left">Name</th>
            <th class="py-3 px-4 text-left">Status</th>
            <th class="py-3 px-4 text-left">Remarks</th>
          </tr>
        </thead>
        <tbody>
          <?php if(empty($finalAttendance)): ?>
            <tr><td colspan="5" class="text-center py-4 font-semibold text-gray-700">No attendance on this day</td></tr>
          <?php else: ?>
            <?php foreach($finalAttendance as $player): ?>
            <tr class="border-b hover:bg-gray-50 transition <?php echo ($player['role']=='captain'?'bg-yellow-100 captain-row':''); ?>" data-student="<?php echo $player['user_id']; ?>">
              <td class="py-3 px-4"><?php echo $player['user_id']; ?></td>
              <td class="py-3 px-4"><img src="<?php echo $player['profile_image'] ?: 'assets/images/default.png'; ?>" alt="<?php echo $player['username'] ?? ''; ?>" class="h-10 w-10 rounded-full border border-gray-300"></td>
              <td class="py-3 px-4 font-medium">
                <?php echo $player['username'] ?? ''; ?>
                <?php if($player['role']=='captain'): ?>
                  <span class="ml-2 px-2 py-1 text-xs font-semibold bg-yellow-300 text-black rounded">Captain</span>
                <?php endif; ?>
              </td>
              <td class="py-3 px-4">
                <span class="status-text px-2 py-1 rounded-full text-sm font-semibold <?php 
                    echo ($player['status']=='present'?'bg-green-100 text-green-800':($player['status']=='absent'?'bg-red-100 text-red-800':'bg-gray-100 text-gray-800')); 
                ?>">
                  <?php echo $player['status'] ?? '-'; ?>
                </span>
                <select class="status-select border rounded px-2 py-1 hidden">
                  <option value="present" <?php echo ($player['status']=='present'?'selected':''); ?>>Present</option>
                  <option value="absent" <?php echo ($player['status']=='absent'?'selected':''); ?>>Absent</option>
                </select>
              </td>
              <td class="py-3 px-4">
                <span class="remarks-text"><?php echo $player['remarks'] ?? '-'; ?></span>
                <input type="text" class="remarks-input border rounded px-2 py-1 w-full hidden" value="<?php echo $player['remarks'] ?? ''; ?>">
              </td>
              <input type="hidden" class="attendance-id" value="<?php echo $player['attendance_id'] ?? 0; ?>">
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Search Section -->
  <div class="w-80">
    <h2 class="text-lg font-semibold mb-2">Search Student Number</h2>
    <input type="text" id="search-student" class="border rounded w-full px-3 py-2" placeholder="Enter Student Number">
  </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
// Edit/Save
let editing = false;
const editBtn = document.getElementById('edit-btn');
const tableBody = document.querySelector("#attendance-table tbody");

editBtn.addEventListener('click', ()=>{
  editing = !editing;
  editBtn.textContent = editing ? "Save" : "Edit";

  const rows = tableBody.querySelectorAll("tr");
  rows.forEach(row=>{
    const statusText = row.querySelector(".status-text");
    const statusSelect = row.querySelector(".status-select");
    const remarksText = row.querySelector(".remarks-text");
    const remarksInput = row.querySelector(".remarks-input");

    if(editing){
      statusText.classList.add('hidden');
      statusSelect.classList.remove('hidden');
      remarksText.classList.add('hidden');
      remarksInput.classList.remove('hidden');
    }else{
      statusText.classList.remove('hidden');
      statusSelect.classList.add('hidden');
      remarksText.classList.remove('hidden');
      remarksInput.classList.add('hidden');

      // Save updated data to DB
      const attendance_id = row.querySelector(".attendance-id").value;
      const status = statusSelect.value;
      const remarks = remarksInput.value;

      fetch('', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: `update_attendance=1&attendance_id=${attendance_id}&status=${encodeURIComponent(status)}&remarks=${encodeURIComponent(remarks)}`
      }).then(res=>res.json()).then(data=>{
        if(data.success){
          statusText.textContent = status;
          statusText.className = 'status-text px-2 py-1 rounded-full text-sm font-semibold ' + (status==='present'?'bg-green-100 text-green-800':'bg-red-100 text-red-800');
          remarksText.textContent = remarks || '-';
        }
      });
    }
  });
});

// Download PDF
const downloadBtn = document.getElementById("download-btn");
downloadBtn.addEventListener("click", async ()=>{
  const wrapper = document.getElementById("attendance-table-wrapper");
  const clone = wrapper.cloneNode(true);
  clone.style.width="100%";
  document.body.appendChild(clone);

  const canvas = await html2canvas(clone,{scale:2});
  const imgData = canvas.toDataURL("image/png");
  document.body.removeChild(clone);

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF('p','pt','a4');
  const imgProps = pdf.getImageProperties(imgData);
  const pdfWidth = pdf.internal.pageSize.getWidth() - 40;
  const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

  const dateStr = document.getElementById("attendance-date").value;
  pdf.setFontSize(18);
  pdf.text(`Attendance - Cricket (${dateStr})`, 20, 30);
  pdf.addImage(imgData,'PNG',20,50,pdfWidth,pdfHeight);
  pdf.save(`Attendance_${dateStr}.pdf`);
});

// Flatpickr - only actual attendance dates
flatpickr("#attendance-date", {
  dateFormat: "Y-m-d",
  defaultDate: "<?php echo $date; ?>",
  onChange: function(selectedDates, dateStr){
    window.location.href = "?date=" + dateStr;
  },
  onDayCreate: function(dObj, dStr, fp, dayElem){
    const date = dayElem.dateObj.getFullYear() + "-" 
               + String(dayElem.dateObj.getMonth() + 1).padStart(2,'0') + "-" 
               + String(dayElem.dateObj.getDate()).padStart(2,'0');

    const attendanceDates = <?php echo json_encode($attendanceDates); ?>;

    if(attendanceDates.includes(date)){
      const dot = document.createElement("div");
      dot.classList.add("session-dot");
      dayElem.appendChild(dot);
      if(date === "<?php echo $date; ?>") dayElem.style.backgroundColor = "lightblue";
    } else {
      dayElem.classList.add("flatpickr-disabled");
    }
  }
});

// Search by student number
const searchInput = document.getElementById('search-student');
searchInput.addEventListener('input', ()=>{
  const studentNum = searchInput.value.toLowerCase();
  const rows = tableBody.querySelectorAll('tr');
  rows.forEach(row=>{
    const rowStudent = row.getAttribute('data-student').toLowerCase();
    row.style.display = rowStudent.includes(studentNum) ? '' : 'none';
  });
});
</script>
</body>
</html>
