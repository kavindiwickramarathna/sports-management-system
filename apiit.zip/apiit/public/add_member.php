<?php
include 'db.php';
$team_id = isset($_GET['team_id']) ? $_GET['team_id'] : 1;

// Fetch team sport_id
$teamStmt = $conn->prepare("SELECT * FROM teams WHERE team_id = ?");
$teamStmt->bind_param("i", $team_id);
$teamStmt->execute();
$teamResult = $teamStmt->get_result();
$team = $teamResult->fetch_assoc();

if(isset($_POST['add_member'])){

    $username = $_POST['username'];
    $cb_number = $_POST['cb_number'];
    $role = $_POST['role'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $played_before = $_POST['played_before'];

    // Check if CB number already exists
    $checkStmt = $conn->prepare("SELECT user_id FROM users WHERE cb_number = ?");
    $checkStmt->bind_param("s", $cb_number);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if($checkResult->num_rows > 0){
        $error = "CB Number already in use!";
    } else {

        // ✅ Profile image upload with file type check
        $profile_image = "";
        if(isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0){

            $fileTmp = $_FILES['profile_image']['tmp_name'];
            $fileName = $_FILES['profile_image']['name'];
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $allowedExt = ['jpg','jpeg','png'];

            if(in_array($fileExt, $allowedExt)){
                $newFileName = time() . "_" . $fileName;
                $uploadDir = "assets/images/"; // Make sure this folder exists and is writable

                if(move_uploaded_file($fileTmp, $uploadDir . $newFileName)){
                    $profile_image = $uploadDir . $newFileName;
                } else {
                    $error = "Failed to upload image.";
                }
            } else {
                $error = "Only JPG, JPEG, PNG files are allowed!";
            }
        }

        if(!isset($error)) {
            // Default password
            $default_password = password_hash('Password@123', PASSWORD_DEFAULT);

            // Insert user
            $stmt = $conn->prepare("INSERT INTO users (username, cb_number, password, role, email, phone, sport_id, profile_image, played_before) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssiss", $username, $cb_number, $default_password, $role, $email, $phone, $team['sport_id'], $profile_image, $played_before);
            $stmt->execute();

            header("Location: cricket.php?team_id=".$team_id);
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Team Member</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

  <form action="" method="post" enctype="multipart/form-data" class="bg-white p-8 rounded shadow-md w-full max-w-md" onsubmit="return validateCB();">
    <h2 class="text-2xl font-bold mb-6">Add New Member</h2>

    <label class="block mb-2">Full Name</label>
    <input type="text" name="username" required class="w-full mb-4 p-2 border rounded">

    <label class="block mb-2">CB Number</label>
    <input type="text" name="cb_number" id="cb_number" required class="w-full mb-1 p-2 border rounded">
    <span id="cb_error" class="text-red-500 text-sm hidden">This CB Number is already in use!</span>

    <label class="block mb-2">Role</label>
    <select name="role" class="w-full mb-4 p-2 border rounded">
      <option value="player">Player</option>
    </select>

    <label class="block mb-2">Email</label>
    <input type="email" name="email" required class="w-full mb-4 p-2 border rounded">

    <label class="block mb-2">Phone</label>
    <input type="text" name="phone" required class="w-full mb-4 p-2 border rounded">

    <label class="block mb-2">Played Before?</label>
    <select name="played_before" class="w-full mb-4 p-2 border rounded">
      <option value="Yes">Yes</option>
      <option value="No">No</option>
    </select>

    <label class="block mb-2">Profile Image</label>
    <input type="file" name="profile_image" accept="image/*" class="mb-4">

    <input type="hidden" name="sport_id" value="<?php echo $team['sport_id']; ?>">

    <?php if(isset($error)){ ?>
      <p class="text-red-500 mb-4"><?php echo $error; ?></p>
    <?php } ?>

    <button type="submit" name="add_member" class="bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600 w-full">Add Member</button>
  </form>

  <script>
    const cbInput = document.getElementById('cb_number');
    const cbError = document.getElementById('cb_error');

    cbInput.addEventListener('input', () => {
        const cbNumber = cbInput.value.trim();
        if(cbNumber.length > 0){
            fetch(`check_cb.php?cb_number=${encodeURIComponent(cbNumber)}`)
            .then(response => response.json())
            .then(data => {
                if(data.exists === 1){
                    cbError.classList.remove('hidden');
                    cbInput.classList.add('border-red-500');
                } else {
                    cbError.classList.add('hidden');
                    cbInput.classList.remove('border-red-500');
                }
            });
        } else {
            cbError.classList.add('hidden');
            cbInput.classList.remove('border-red-500');
        }
    });

    function validateCB(){
        if(!cbError.classList.contains('hidden')){
            alert('Please enter a unique CB Number.');
            cbInput.focus();
            return false;
        }
        return true;
    }
  </script>
</body>
</html>
