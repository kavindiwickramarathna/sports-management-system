<?php
include 'db.php';

// Get team ID from URL
$team_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch team info
$stmt = $conn->prepare("SELECT * FROM sports WHERE sport_id = ?");
$stmt->bind_param("i", $team_id);
$stmt->execute();
$teamResult = $stmt->get_result();
$team = $teamResult->fetch_assoc();

if (!$team) {
    echo "<p class='text-center text-red-500 text-xl mt-20'>Team not found.</p>";
    exit();
}

// Fetch players for this team
$stmtPlayers = $conn->prepare("SELECT * FROM users WHERE role='player' AND sport_id=?");
$stmtPlayers->bind_param("i", $team_id);
$stmtPlayers->execute();
$playersResult = $stmtPlayers->get_result();

// Fetch coaches for this team
$stmtCoaches = $conn->prepare("SELECT * FROM users WHERE role='coach' AND sport_id=?");
$stmtCoaches->bind_param("i", $team_id);
$stmtCoaches->execute();
$coachesResult = $stmtCoaches->get_result();

function getImageFile($imagePath) {
    if (!empty($imagePath) && file_exists($imagePath)) return $imagePath;
    return "assets/images/default.jpg";
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title><?php echo htmlspecialchars($team['sport_name']); ?> Team Details</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
    <a href="all.php" class="nav-item font-semibold text-black hover:text-yellow-400">Back to Teams</a>
  </div>
</nav>

<main class="mt-24 px-10 pb-20">
  <div class="bg-white rounded-lg shadow-md p-6 mb-8">
    <h1 class="text-3xl font-bold mb-4"><?php echo htmlspecialchars($team['sport_name']); ?> Team</h1>
    <img src="<?php echo getImageFile($team['image']); ?>" class="rounded-md w-64 h-64 object-contain mb-4">
    <p class="text-gray-700">This is the official <?php echo htmlspecialchars($team['sport_name']); ?> team of the system.</p>
  </div>

  <!-- Coaches Section -->

  <div class="mb-8">
    <h2 class="text-2xl font-semibold mb-4">Coaches</h2>
    <?php if ($coachesResult->num_rows > 0): ?>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <?php while ($coach = $coachesResult->fetch_assoc()): ?>
          <div class="bg-white rounded-lg shadow-md p-4 text-center">
            <img src="<?php echo getImageFile($coach['profile_image']); ?>" class="rounded-full w-24 h-24 mx-auto mb-2 object-cover">
            <h3 class="font-bold"><?php echo htmlspecialchars($coach['name']); ?></h3>
            <p class="text-gray-600">Coach</p>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p class="text-gray-500">No coaches assigned to this team yet.</p>
    <?php endif; ?>
  </div>

  <!-- Players Section -->

  <div>
    <h2 class="text-2xl font-semibold mb-4">Players</h2>
    <?php if ($playersResult->num_rows > 0): ?>
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        <?php while ($player = $playersResult->fetch_assoc()): ?>
          <div class="bg-white rounded-lg shadow-md p-4 text-center">
            <img src="<?php echo getImageFile($player['profile_image']); ?>" class="rounded-full w-24 h-24 mx-auto mb-2 object-cover">
            <h3 class="font-bold"><?php echo htmlspecialchars($player['name']); ?></h3>
            <p class="text-gray-600">Player</p>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p class="text-gray-500">No players assigned to this team yet.</p>
    <?php endif; ?>
  </div>
</main>

</body>
</html>
