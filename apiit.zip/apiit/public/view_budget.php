<?php
include 'db.php';
session_start();
date_default_timezone_set('Asia/Colombo');

// Only admin can access
if (!isset($_SESSION['entered_email']) || ($_SESSION['user_role'] ?? '') !== 'admin') {
    header("Location: login.php");
    exit();
}

// Fetch the latest budget request
$result = $conn->query("
    SELECT br.request_id, br.description, br.amount, br.status, br.due_date, br.requested_at, u.email AS captain_email
    FROM budget_requests br
    JOIN users u ON br.captain_id = u.user_id
    ORDER BY br.requested_at DESC
    LIMIT 1
");
$budgetRequest = $result ? $result->fetch_assoc() : null;

// Handle Approve/Reject action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $request_id = intval($_POST['request_id']);
    $action = $_POST['action'];

    if ($action === 'approve') {
        $stmt = $conn->prepare("UPDATE budget_requests SET status='Approved', approved_at=NOW() WHERE request_id=?");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $stmt->close();
        echo "<script>alert('Budget has been approved successfully!'); window.location='dashboard.php';</script>";
        exit;
    }

    if ($action === 'reject') {
        $notes = trim($_POST['reject_notes'] ?? '');

        // Handle PDF upload
        if (!empty($_FILES['reject_file']['tmp_name'])) {
            if ($_FILES['reject_file']['type'] === 'application/pdf') {
                $uploadDir = __DIR__ . '/assets/uploads/';
                if (!is_dir($uploadDir)) @mkdir($uploadDir, 0755, true);
                $target = $uploadDir . 'rejected_' . $request_id . '_' . time() . '.pdf';
                move_uploaded_file($_FILES['reject_file']['tmp_name'], $target);
                $notes .= ($notes ? "\n\n" : '') . "[Uploaded file: " . basename($target) . "]";
            }
        }

        $stmt = $conn->prepare("UPDATE budget_requests SET status='Rejected', description=IFNULL(?, description) WHERE request_id=?");
        $stmt->bind_param("si", $notes, $request_id);
        $stmt->execute();
        $stmt->close();
        echo "<script>alert('Budget has been rejected successfully!'); window.location='dashboard.php';</script>";
        exit;
    }
}

// Helper function to format datetime
function format_dt($dtString, $format = "l, F d, Y \\a\\t h:i A") {
    if (empty($dtString)) return "N/A";
    try {
        $dt = new DateTime($dtString);
        $dt->setTimezone(new DateTimeZone(date_default_timezone_get()));
        return $dt->format($format);
    } catch (Exception $e) {
        return htmlspecialchars($dtString);
    }
}

// Fixed PDF path (replace with your actual file)
$budgetPDF = 'assets/files/APIIT_Cricket_Team_Budget.pdf';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Budget - Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .nav-item:hover { color: #facc15; }
</style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<main class="flex-grow mt-24 px-6 md:px-16 lg:px-24">
  <h1 class="text-2xl md:text-3xl font-bold text-gray-800 mb-6">Budget for APIIT Cricket Team</h1>

  <div class="bg-gray-200 text-black rounded-xl p-6 shadow-md w-full">
    <?php if (!$budgetRequest): ?>
        <p class="text-lg font-semibold">No budget requests found.</p>
    <?php else: ?>
        <p class="text-lg font-semibold">Requested On: <span class="font-normal"><?php echo format_dt($budgetRequest['requested_at']); ?></span></p>
        <p class="text-lg font-semibold mt-2">Due Date: <span class="font-normal"><?php echo format_dt($budgetRequest['due_date']); ?></span></p>
        <p class="text-lg font-semibold mt-2">Requested By: <span class="font-normal"><?php echo htmlspecialchars($budgetRequest['captain_email']); ?></span></p>

        <div class="w-full h-[2px] bg-gray-400 my-4"></div>

        <p class="font-semibold text-left text-lg"><?php echo nl2br(htmlspecialchars($budgetRequest['description'] ?? 'No description')); ?></p>

        <!-- Download Budget Button -->
        <div class="mt-4">
            <a href="<?php echo $budgetPDF; ?>" download
               class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-lg transition duration-300">
               Download Budget
            </a>
        </div>

        <div class="flex space-x-4 mt-6">
            <!-- Approve Button -->
            <?php if ($budgetRequest['status'] !== 'Approved'): ?>
            <form method="POST" style="display:inline-block;">
                <input type="hidden" name="request_id" value="<?php echo intval($budgetRequest['request_id']); ?>">
                <input type="hidden" name="action" value="approve">
                <button type="submit" class="bg-teal-600 hover:bg-teal-700 text-white font-semibold px-6 py-2 rounded-lg transition duration-300">Approve</button>
            </form>
            <?php endif; ?>

            <!-- Reject Button -->
            <?php if ($budgetRequest['status'] !== 'Rejected'): ?>
            <button id="rejectBtn" class="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-2 rounded-lg transition duration-300">Reject</button>
            <?php endif; ?>
        </div>

        <!-- Reject Form -->
        <div id="rejectForm" class="hidden mt-6 bg-white p-6 rounded-lg shadow-inner">
          <h2 class="text-xl font-bold text-gray-800 mb-3">Reject Budget Request</h2>
          <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="request_id" value="<?php echo intval($budgetRequest['request_id']); ?>">
            <input type="hidden" name="action" value="reject">

            <label class="font-semibold text-gray-800 mb-1">Reason/Notes:</label>
            <textarea name="reject_notes" class="w-full border rounded p-2 mb-4" rows="4" placeholder="Add reason for rejection"></textarea>

            <label class="font-semibold text-gray-800 mb-1">Attach PDF (Optional):</label>
            <input type="file" name="reject_file" accept="application/pdf" class="block w-full border border-gray-400 rounded-lg p-2 mb-4">

            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg">Submit Reject</button>
          </form>
        </div>
    <?php endif; ?>
  </div>
</main>

<script>
document.getElementById('rejectBtn')?.addEventListener('click', () => {
    document.getElementById('rejectForm').classList.toggle('hidden');
});
</script>

</body>
</html>
