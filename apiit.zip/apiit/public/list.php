<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>All Teams - List View</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    .nav-item:hover { color: #facc15; }
    .active { color: #facc15; }

    /* Dropdowns */
    .dropdown-content, .user-dropdown {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
      z-index: 50; /* Ensures dropdowns appear above cards */
    }

    .dropdown-content a, .user-dropdown a {
      color: black;
      padding: 10px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover, .user-dropdown a:hover {
      background-color: #facc15;
      color: white;
    }

    .dropdown:hover .dropdown-content,
    .user-menu:hover .user-dropdown {
      display: block;
    }

    /* Modal overlay */
    .modal-overlay {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background-color: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
      z-index: 100;
    }

    /* Cards */
    .team-card {
      position: relative;
      z-index: 10; /* Lower than dropdown */
    }

    /* Ensure dropdowns are not clipped */
    main, body {
      overflow: visible !important;
    }
  </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

  <!-- Navbar -->
  <nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
      <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
      <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
      <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

      <div class="dropdown relative">
        <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
        <div class="dropdown-content rounded-md">
          <a href="all.php">All Teams</a>
          <a href="coaches.php">Coaches</a>
          <a href="players.php">Player Search</a>
        </div>
      </div>

      <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
      <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>

    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
      <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
      <span class="text-black">▼</span>
      <div class="user-dropdown rounded-md right-0">
        <a href="admin_profile.php">Profile</a>
        <a href="calendar.php">Calendar</a>
        <a href="messages.php">Messages</a>
        <a href="reports.php">Reports</a>
        <a href="logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <!-- Main Content -->
  <main class="flex-grow mt-24 px-10 pb-20">
    <h1 class="text-3xl font-bold text-gray-800 mb-4">All Teams</h1>
    <h2 class="text-xl font-semibold text-gray-700 mb-2">Teams Overview</h2>
    <hr class="border-gray-400 mb-6">

    <!-- Search & View Controls -->
    <div class="flex flex-wrap items-center gap-4 mb-8">
      <input 
        type="text" 
        list="sports-list" 
        placeholder="Search for a team..." 
        class="bg-white border border-black rounded-md px-4 py-2 w-64 focus:outline-none focus:ring-2 focus:ring-gray-300"
      />
      <datalist id="sports-list">
        <option value="Cricket">
        <option value="Football">
        <option value="Rugby">
        <option value="Futsal">
        <option value="Swimming">
        <option value="Netball">
        <option value="Athletics">
        <option value="Basketball">
      </datalist>

      <div class="relative inline-block z-50">
        <button id="viewBtn" class="bg-gray-800 text-white px-4 py-2 rounded-md hover:bg-gray-700">List ▼</button>
        <div id="viewDropdown" class="hidden absolute bg-white border border-gray-300 rounded-md shadow-md mt-2 w-40 z-50">
          <a href="all.php" class="block px-4 py-2 hover:bg-gray-100">Card</a>
          <a href="list.php" class="block px-4 py-2 hover:bg-gray-100">List</a>
        </div>
      </div>
    </div>
    <!-- List of Teams -->
<div id="listContainer" class="space-y-4">
  <!-- Cricket Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="cricket.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/hero.png" alt="Cricket" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Cricket Team</h2>
        <p class="text-gray-600 text-sm">Representing national level sports spirit.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>

  <!-- Football Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="football.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/football.jpg" alt="Football" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Football Team</h2>
        <p class="text-gray-600 text-sm">Focusing on teamwork and strategy.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>

  <!-- Rugby Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="rugby.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/rugby.jpg" alt="Rugby" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Rugby Team</h2>
        <p class="text-gray-600 text-sm">Known for strength and endurance.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>

  <!-- Futsal Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="futsal.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/futsal.jpg" alt="Futsal" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Futsal Team</h2>
        <p class="text-gray-600 text-sm">Promoting fast-paced indoor football.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>

  <!-- Swimming Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="swimming.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/swimming.jpg" alt="Swimming" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Swimming Team</h2>
        <p class="text-gray-600 text-sm">Skilled in various water competitions.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>

  <!-- Netball Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="netball.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/netball.jpg" alt="Netball" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Netball Team</h2>
        <p class="text-gray-600 text-sm">Empowering women through sportsmanship.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>

  <!-- Athletics Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="athletics.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/athletic.JPG" alt="Athletics" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Athletics Team</h2>
        <p class="text-gray-600 text-sm">Excelling in track and field events.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>

  <!-- Basketball Team -->
  <div class="team-card relative flex items-center justify-between bg-white rounded-md shadow-md p-4 hover:shadow-lg transition">
    <a href="basketball.php" class="flex items-center gap-4 flex-grow">
      <img src="assets/images/basketball.jpg" alt="Basketball" class="h-20 w-28 rounded-md object-cover bg-gray-100">
      <div>
        <h2 class="text-lg font-bold text-gray-900">Basketball Team</h2>
        <p class="text-gray-600 text-sm">Mastering speed and precision.</p>
      </div>
    </a>
    <div class="relative">
      <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>
      <div class="menu hidden absolute right-0 mt-2 bg-white border border-gray-300 rounded-md shadow-md w-36">
        <button class="block w-full text-left px-4 py-2 hover:bg-gray-100 remove-btn">Remove Team</button>
      </div>
    </div>
  </div>
</div>

  </main>

  <!-- Floating Add Button -->
  <div class="fixed bottom-6 right-6">
    <div class="relative inline-block z-50">
      <button id="addBtn" class="bg-teal-800 text-white text-3xl rounded-full w-14 h-14 hover:bg-teal-700">+</button>
      <div id="addDropdown" class="hidden absolute bottom-16 right-0 bg-teal border border-teal-300 rounded-md shadow-md w-40 z-50">
        <a href="add_team.php" class="block px-4 py-2 hover:bg-teal-100">Add a Team</a>
      </div>
    </div>
  </div>

  <!-- Modal -->
  <div id="modal" class="modal-overlay flex">
    <div class="bg-white p-6 rounded-md text-center shadow-lg w-80">
      <p class="text-lg font-semibold mb-4">Wants to delete the team?</p>
      <div class="flex justify-center space-x-6">
        <button id="yesBtn" class="bg-red-500 text-white rounded-full w-10 h-10">✔</button>
        <button id="noBtn" class="bg-gray-500 text-white rounded-full w-10 h-10">✖</button>
      </div>
    </div>
  </div>

  <!-- Scripts -->
  <script>
    const viewBtn = document.getElementById('viewBtn');
    const viewDropdown = document.getElementById('viewDropdown');
    const addBtn = document.getElementById('addBtn');
    const addDropdown = document.getElementById('addDropdown');
    const modal = document.getElementById('modal');
    let selectedCard = null;

    viewBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      viewDropdown.classList.toggle('hidden');
    });

    addBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      addDropdown.classList.toggle('hidden');
    });

    window.addEventListener('click', (e) => {
      if (!viewBtn.contains(e.target) && !viewDropdown.contains(e.target)) viewDropdown.classList.add('hidden');
      if (!addBtn.contains(e.target) && !addDropdown.contains(e.target)) addDropdown.classList.add('hidden');
      document.querySelectorAll('.menu').forEach(m => {
        if (!m.contains(e.target) && !m.previousElementSibling?.contains(e.target)) {
          m.classList.add('hidden');
        }
      });
    });

    document.querySelectorAll('.menu-toggle').forEach(btn => {
      btn.addEventListener('click', (ev) => {
        ev.stopPropagation();
        document.querySelectorAll('.menu').forEach(m => m.classList.add('hidden'));
        const menu = btn.parentElement.querySelector('.menu');
        if (menu) menu.classList.toggle('hidden');
      });
    });

    document.querySelectorAll('.remove-btn').forEach(rbtn => {
      rbtn.addEventListener('click', (ev) => {
        ev.stopPropagation();
        const card = rbtn.closest('.team-card');
        if (!card) return;
        selectedCard = card;
        modal.style.display = 'flex';
      });
    });

    document.getElementById('yesBtn').addEventListener('click', () => {
      if (selectedCard) {
        selectedCard.remove();
        selectedCard = null;
      }
      modal.style.display = 'none';
    });

    document.getElementById('noBtn').addEventListener('click', () => {
      selectedCard = null;
      modal.style.display = 'none';
    });

    window.addEventListener('DOMContentLoaded', () => {
      modal.style.display = 'none';
    });
  </script>
</body>
</html>
