<?php
include 'db.php';
session_start();

$error = "";

// Fetch all sports from the database for the dropdown
$sports = [];
$sport_result = $conn->query("SELECT sport_id, sport_name FROM sports");
if ($sport_result) {
    while ($row = $sport_result->fetch_assoc()) {
        $sports[] = $row;
    }
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['email']);
    $cb_number = trim($_POST['cb_number']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $phone = trim($_POST['phone']);
    $sport_id = trim($_POST['sport_id']);
    $played_before = trim($_POST['played_before']);
    $profile_image = "assets/images/default_player.png";

    // Handle profile image upload
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === 0) {
        $uploadDir = "assets/images/";
        $fileName = basename($_FILES['profile_image']['name']);
        $targetFile = $uploadDir . time() . "_" . $fileName;
        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFile)) {
            $profile_image = $targetFile;
        }
    }

    // Basic validation
    if (!$email || !$cb_number || !$username || !$password || !$phone || !$sport_id || !$played_before) {
        $error = "Please fill all required fields.";
    } else {
        // Check duplicates
        $duplicate_error = "";
        $stmt_cb = $conn->prepare("SELECT user_id FROM users WHERE cb_number = ?");
        $stmt_cb->bind_param("s", $cb_number);
        $stmt_cb->execute();
        $stmt_cb->store_result();
        if ($stmt_cb->num_rows > 0) $duplicate_error = "CB Number already in use.";
        $stmt_cb->close();

        $stmt_user = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
        $stmt_user->bind_param("s", $username);
        $stmt_user->execute();
        $stmt_user->store_result();
        if ($stmt_user->num_rows > 0) $duplicate_error = "Username already in use.";
        $stmt_user->close();

        $stmt_email = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt_email->bind_param("s", $email);
        $stmt_email->execute();
        $stmt_email->store_result();
        if ($stmt_email->num_rows > 0) $duplicate_error = "Email already in use.";
        $stmt_email->close();

        if (!$duplicate_error) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (cb_number, username, password, role, email, phone, sport_id, profile_image, played_before) VALUES (?, ?, ?, 'player', ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssis", $cb_number, $username, $hashed_password, $email, $phone, $sport_id, $profile_image, $played_before);
            if ($stmt->execute()) {
                $_SESSION['entered_email'] = $email;
                $_SESSION['user_role'] = 'player';
                header("Location: player.php");
                exit();
            } else {
                $error = "Failed to register new player. Please try again.";
            }
            $stmt->close();
        } else {
            $error = $duplicate_error;
        }
    }
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New Player Registration - APIIT Sports Management System</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<style>
.status { font-size: 0.85rem; margin-bottom: 0.5rem; }
.status.valid { color: green; }
.status.invalid { color: red; }
</style>
</head>
<body class="min-h-screen flex items-center justify-center bg-gray-100">

<div class="bg-white rounded-2xl p-8 w-80 sm:w-96 shadow-xl">
    <h2 class="text-2xl font-semibold mb-6 text-center">New Player Registration</h2>

 
<?php if($error): ?>
    <p class="text-red-600 text-sm mb-4"><?php echo htmlspecialchars($error); ?></p>
<?php endif; ?>

<form method="POST" action="" enctype="multipart/form-data">
    <label class="block text-gray-700 text-sm mb-1">Email</label>
    <input type="email" id="email" name="email" class="w-full border rounded-lg px-3 py-2 mb-1" required>
    <div id="email_status" class="status"></div>

    <label class="block text-gray-700 text-sm mb-1">CB Number</label>
    <input type="text" id="cb_number" name="cb_number" class="w-full border rounded-lg px-3 py-2 mb-1" required>
    <div id="cb_status" class="status"></div>

    <label class="block text-gray-700 text-sm mb-1">Username</label>
    <input type="text" id="username" name="username" class="w-full border rounded-lg px-3 py-2 mb-1" required>
    <div id="username_status" class="status"></div>

    <label class="block text-gray-700 text-sm mb-1">Password</label>
    <input type="password" name="password" class="w-full border rounded-lg px-3 py-2 mb-3" required>

    <label class="block text-gray-700 text-sm mb-1">Phone</label>
    <input type="text" name="phone" class="w-full border rounded-lg px-3 py-2 mb-3" required>

    <label class="block text-gray-700 text-sm mb-1">Sport</label>
    <select name="sport_id" class="w-full border rounded-lg px-3 py-2 mb-3" required>
        <option value="">-- Select your sport --</option>
        <?php foreach($sports as $sport): ?>
            <option value="<?php echo $sport['sport_id']; ?>">
                <?php echo htmlspecialchars($sport['sport_name']); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label class="block text-gray-700 text-sm mb-1">Played Before (Yes/No)</label>
    <input type="text" name="played_before" class="w-full border rounded-lg px-3 py-2 mb-3" required>

    <label class="block text-gray-700 text-sm mb-1">Profile Image (optional)</label>
    <input type="file" name="profile_image" class="w-full border rounded-lg px-3 py-2 mb-3" accept="image/*">

    <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-300">
        Submit
    </button>
</form>
 

</div>

<script>
function checkAvailability(field, statusDiv, column) {
    let value = $('#' + field).val();
    if (value.length > 0) {
        $.post('check_availability.php', {field: column, value: value}, function(data) {
            if(data.available) {
                $('#' + statusDiv).text('Available').removeClass('invalid').addClass('valid');
            } else {
                $('#' + statusDiv).text('Already in use').removeClass('valid').addClass('invalid');
            }
        }, 'json');
    } else {
        $('#' + statusDiv).text('');
    }
}

$('#cb_number').on('keyup', function(){ checkAvailability('cb_number','cb_status','cb_number'); });
$('#username').on('keyup', function(){ checkAvailability('username','username_status','username'); });
$('#email').on('keyup', function(){ checkAvailability('email','email_status','email'); });
</script>

</body>
</html>
