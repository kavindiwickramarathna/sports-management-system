<?php
include 'db.php';

$addCoachError = "";
$addCoachSuccess = "";

// Handle form submission for adding a new coach
if (isset($_POST['add_coach'])) {
    $coachName = trim($_POST['coach_name']);
    $coachEmail = trim($_POST['coach_email']);
    $coachPhone = trim($_POST['coach_phone']) ?: "";
    $sportId = $_POST['sport_id'] ?: null;
    $imageFile = "";

    // Generate unique cb_number automatically
    $cbNumber = "coach_" . time() . rand(100,999);

    // Set default password for new coach
    $defaultPassword = password_hash("Coach@123", PASSWORD_DEFAULT);

    // Set default played_before
    $playedBefore = "no";

    // Handle image upload
    if (isset($_FILES['coach_image']) && $_FILES['coach_image']['error'] == 0) {
        $uploadDir = "assets/images/";
        $imageFile = $uploadDir . basename($_FILES['coach_image']['name']);
        move_uploaded_file($_FILES['coach_image']['tmp_name'], $imageFile);
    }

    if ($coachName !== "" && $coachEmail !== "" && $sportId !== null) {
        $stmt = $conn->prepare("INSERT INTO users (cb_number, username, password, role, email, phone, sport_id, profile_image, played_before) VALUES (?, ?, ?, 'coach', ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssssssss", $cbNumber, $coachName, $defaultPassword, $coachEmail, $coachPhone, $sportId, $imageFile, $playedBefore);
            if ($stmt->execute()) {
                $addCoachSuccess = "Coach added successfully!";
            } else {
                $addCoachError = "Database error: " . $stmt->error;
            }
        } else {
            $addCoachError = "Prepare statement error: " . $conn->error;
        }
    } else {
        $addCoachError = "Please fill in all required fields.";
    }
}

// Handle search
$search = isset($_GET['search']) ? trim($_GET['search']) : "";

if ($search !== "") {
    $stmt = $conn->prepare("SELECT u.*, s.sport_name FROM users u LEFT JOIN sports s ON u.sport_id = s.sport_id WHERE u.role='coach' AND u.username LIKE ?");
    $like = "%".$search."%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT u.*, s.sport_name FROM users u LEFT JOIN sports s ON u.sport_id = s.sport_id WHERE u.role='coach'");
}

function getImageFile($imagePath) {
    if (!empty($imagePath) && file_exists($imagePath)) return $imagePath;
    return "assets/images/default.jpg";
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Admin Dashboard - Coaches Management</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.nav-item:hover { color: #facc15; }
.active { color: #facc15; }
.dropdown-content, .user-dropdown { display: none; position: absolute; background-color: white; min-width: 160px; box-shadow: 0px 4px 8px rgba(0,0,0,0.2); z-index: 10; }
.dropdown-content a, .user-dropdown a { color: black; padding: 10px 16px; text-decoration: none; display: block; }
.dropdown-content a:hover, .user-dropdown a:hover { background-color: #facc15; color: white; }
.dropdown:hover .dropdown-content, .user-menu:hover .user-dropdown { display: block; }
.modal-overlay { position: fixed; inset: 0; display: flex; justify-content: center; align-items: center; background-color: rgba(0,0,0,0.5); z-index: 50; }
</style>
</head>

<body class="flex flex-col min-h-screen bg-gray-100">

<!-- NAVIGATION BAR -->

<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
    <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
    <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>
    <div class="dropdown relative">
      <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
      <div class="dropdown-content rounded-md">
        <a href="all.php">All Teams</a>
        <a href="coaches.php">Coaches</a>
        <a href="players.php">Player Search</a>
      </div>
    </div>
    <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
      <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
    <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
  </div>
  <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
    <span class="text-black">▼</span>
    <div class="user-dropdown rounded-md right-0">
      <a href="admin_profile.php">Profile</a>
      <a href="calendar.php">Calendar</a>
     
      <a href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<main class="flex-grow mt-24 px-10 pb-20">
<h1 class="text-3xl font-bold text-gray-800 mb-4">Coaches</h1>
<h2 class="text-xl font-semibold text-gray-700 mb-2">Coaches Overview</h2>
<hr class="border-gray-400 mb-6">

<?php if($addCoachSuccess) echo "<p class='text-green-600 font-semibold mb-4'>$addCoachSuccess</p>"; ?>

<?php if($addCoachError) echo "<p class='text-red-600 font-semibold mb-4'>$addCoachError</p>"; ?>

<!-- SEARCH FORM -->

<form method="GET" class="flex flex-wrap items-center gap-4 mb-8">
    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search for a coach..." class="bg-white border border-black rounded-md px-4 py-2 w-64 focus:outline-none" />
    <button class="bg-gray-800 text-white px-4 py-2 rounded-md">Search</button>
</form>

<!-- CARD GRID -->

<div id="cardContainer" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 justify-items-center">
<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $coachName = $row['username'];
        $imgFile = getImageFile($row['profile_image']);
        $sportName = $row['sport_name'] ?? "N/A";
        $user_id = $row['user_id'];
?>
<a href="coach_details.php?user_id=<?php echo $user_id; ?>" class="coach-card relative bg-white rounded-lg shadow-md p-3 w-60 hover:shadow-lg transition text-center">
    <img src="<?php echo $imgFile; ?>" class="rounded-md mb-2 w-full h-40 object-contain bg-gray-100 mx-auto">
    <h2 class="text-lg font-bold text-gray-900"><?php echo $coachName; ?></h2>
    <p class="text-gray-600 text-sm"><?php echo $sportName; ?> Coach</p>
    <p class="text-gray-600 text-sm"><?php echo $row['email']; ?></p>
    <p class="text-gray-600 text-sm"><?php echo $row['phone']; ?></p>
</a>
<?php
    }
} else {
    echo "<p class='text-center text-red-500 text-xl font-semibold col-span-4'>No coaches found</p>";
}
?>
</div>
</main>

<!-- FLOATING ADD COACH BUTTON -->

<div class="fixed bottom-6 right-6">
  <button id="addCoachBtn" class="bg-teal-800 text-white text-3xl rounded-full w-14 h-14 hover:bg-teal-700">+</button>
</div>

<!-- ADD COACH MODAL -->

<div id="addCoachModal" class="modal-overlay hidden">
  <div class="bg-white p-6 rounded-md shadow-lg w-96">
    <h2 class="text-xl font-semibold mb-4">Add Coach</h2>
    <form method="POST" enctype="multipart/form-data" class="flex flex-col gap-4">
      <input type="text" name="coach_name" placeholder="Coach Name" class="border px-3 py-2 rounded-md" required>
      <input type="text" name="coach_email" placeholder="Coach Email" class="border px-3 py-2 rounded-md" required>
      <input type="text" name="coach_phone" placeholder="Phone Number" class="border px-3 py-2 rounded-md">
      <select name="sport_id" class="border px-3 py-2 rounded-md" required>
        <option value="">Select Sport</option>
        <?php
        $sports = $conn->query("SELECT * FROM sports");
        while ($sport = $sports->fetch_assoc()) {
            echo "<option value='".$sport['sport_id']."'>".$sport['sport_name']."</option>";
        }
        ?>
      </select>
      <input type="file" name="coach_image" accept="image/*" class="border px-3 py-2 rounded-md">
      <div class="flex justify-end gap-4">
        <button type="submit" name="add_coach" class="bg-teal-800 text-white px-4 py-2 rounded-md hover:bg-teal-700">Add</button>
        <button type="button" id="cancelAddCoach" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-400">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
// Add Coach Modal
const addBtn = document.getElementById("addCoachBtn");
const addModal = document.getElementById("addCoachModal");
const cancelBtn = document.getElementById("cancelAddCoach");

addBtn.addEventListener("click", () => addModal.classList.remove("hidden"));
cancelBtn.addEventListener("click", () => addModal.classList.add("hidden"));
addModal.addEventListener("click", (e) => { if(e.target===addModal) addModal.classList.add("hidden"); });
</script>

</body>
</html>
