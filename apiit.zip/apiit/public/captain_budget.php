<?php
include 'db.php';
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT user_id, username, profile_image, sport_id FROM users WHERE email=?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$stmt->bind_result($captain_id, $captain_name, $profileImage, $captainSportID);
$stmt->fetch();
$stmt->close();

$profileImage = $profileImage ?: 'assets/images/default.png';

// Fetch captain’s sport name
$stmtSport = $conn->prepare("SELECT sport_name FROM sports WHERE sport_id = ?");
$stmtSport->bind_param("i", $captainSportID);
$stmtSport->execute();
$stmtSport->bind_result($captainSportName);
$stmtSport->fetch();
$stmtSport->close();

// Get current submission deadline
$deadlineRow = $conn->query("SELECT * FROM budget_deadline ORDER BY id DESC LIMIT 1")->fetch_assoc();
$dueDate = $deadlineRow ? $deadlineRow['deadline_date'] : null;

$today = date('Y-m-d');
$alert = '';

// Handle PDF Submission
if (isset($_POST['submit_budget'])) {
    $sport_id = $captainSportID; // Force captain's sport ID
    $amount = $_POST['amount'];

    if ($dueDate && $today <= $dueDate && isset($_FILES['budget_file']) && $_FILES['budget_file']['type'] === 'application/pdf') {
        $file = $_FILES['budget_file'];
        $filename = time() . '_' . basename($file['name']);
        $targetDir = 'uploads/budget/';
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $targetFile = $targetDir . $filename;

        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            $stmt = $conn->prepare("INSERT INTO budget_requests 
                (captain_id, sport_id, amount, description, status, requested_at, due_date, approved_at)
                VALUES (?, ?, ?, ?, 'Pending', NOW(), ?, NULL)");
            $stmt->bind_param("iiiss", $captain_id, $sport_id, $amount, $filename, $dueDate);
            $stmt->execute();
            $stmt->close();

            $alert = "<script>alert('Budget submitted successfully!'); window.location='captain_budget.php';</script>";
        } else {
            $alert = "<script>alert('Error uploading file');</script>";
        }
    } else {
        $alert = "<script>alert('Please upload a valid PDF or submission deadline passed');</script>";
    }
}

// Handle deletion
if (isset($_POST['delete_budget'])) {
    $delete_id = $_POST['delete_budget'];
    $stmt = $conn->prepare("SELECT description, due_date FROM budget_requests WHERE request_id=? AND captain_id=?");
    $stmt->bind_param("ii", $delete_id, $captain_id);
    $stmt->execute();
    $stmt->bind_result($fileToDelete, $budget_due_date);

    if ($stmt->fetch() && $budget_due_date >= $today) {
        $stmt->close();
        if (file_exists('uploads/budget/' . $fileToDelete)) unlink('uploads/budget/' . $fileToDelete);

        $stmtDel = $conn->prepare("DELETE FROM budget_requests WHERE request_id=? AND captain_id=?");
        $stmtDel->bind_param("ii", $delete_id, $captain_id);
        $stmtDel->execute();
        $stmtDel->close();

        $alert = "<script>alert('Budget deleted successfully'); window.location='captain_budget.php';</script>";
    } else {
        $alert = "<script>alert('Cannot delete budget after deadline');</script>";
        $stmt->close();
    }
}

// Fetch captain budget requests
$budgetRequests = [];
$stmt = $conn->prepare("SELECT request_id, description, amount, status, requested_at, due_date, approved_at 
                        FROM budget_requests WHERE captain_id=? ORDER BY requested_at DESC");
$stmt->bind_param("i", $captain_id);
$stmt->execute();
$stmt->bind_result($request_id, $description, $amount_db, $status, $requested_at, $budget_due_date, $approved_at);

while ($stmt->fetch()) {
    $budgetRequests[] = [
        'request_id' => $request_id,
        'description' => $description,
        'amount' => $amount_db,
        'status' => $status,
        'requested_at' => $requested_at,
        'due_date' => $budget_due_date,
        'approved_at' => $approved_at
    ];
}
$stmt->close();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Captain Budget Requests</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<body class="bg-gray-100 pt-28">

    <!-- Navigation Bar -->
<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="captain.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>

        <!-- My Team Dropdown -->
        <div class="relative">
            <button id="myTeamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
                <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
                <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
                <a href="captain_budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>

        <a href="captain_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
        <a href="captain_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
    </div>

    <!-- Right side: User menu -->
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?php echo htmlspecialchars($profileImage); ?>" 
             alt="User Profile" 
             class="h-10 w-10 rounded-full border border-gray-400">
        <span class="text-black select-none">▼</span>
        <div id="userDropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-12 w-48 py-2 z-50">
    <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
    <a href="captain_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
    <a href="captain_account_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
    <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
</div>

    </div>
</nav>

<!-- Dropdown JS -->
<script>
    // My Team Dropdown
    const myTeamBtn = document.getElementById('myTeamBtn');
    const myTeamDropdown = document.getElementById('myTeamDropdown');

    myTeamBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        myTeamDropdown.classList.toggle('hidden');
    });

    // User Menu Dropdown
    const userMenu = document.querySelector('.user-menu');
    const userDropdown = document.getElementById('userDropdown');

    userMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdown.classList.toggle('hidden');
    });

    // Close dropdowns if clicking outside
    window.addEventListener('click', () => {
        myTeamDropdown.classList.add('hidden');
        userDropdown.classList.add('hidden');
    });
</script>

<div class="container mx-auto p-6 bg-white rounded shadow-md">

<h1 class="text-3xl font-bold mb-2">Request Your Budget</h1>

<?php if ($dueDate): ?>

<p class="mb-4 text-gray-700">Deadline: <span class="font-semibold text-red-600"><?php echo $dueDate; ?></span></p>
<?php else: ?>
<p class="mb-4 text-gray-700">No submission deadline set by admin.</p>
<?php endif; ?>

<a href="assets/files/budget_template.docx" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-800 mb-6 inline-block">Download Budget Template</a>

<?php if ($dueDate && $today <= $dueDate): ?>

<form action="" method="POST" enctype="multipart/form-data" class="mb-6">
    <label class="block mb-2 font-semibold">Sport / Team:</label>
    <input type="text" value="<?php echo htmlspecialchars($captainSportName); ?>" 
           class="mb-4 p-2 border rounded w-full bg-gray-100" readonly>
    <input type="hidden" name="sport_id" value="<?php echo $captainSportID; ?>">

 
<label class="block mb-2 font-semibold">Budget Amount (RS):</label>
<input type="number" name="amount" min="1" step="0.01" placeholder="Enter amount" required class="mb-4 p-2 border rounded w-full">

<label class="block mb-2 font-semibold">Upload Budget (PDF Only):</label>
<input type="file" name="budget_file" accept="application/pdf" class="mb-4 p-2 border rounded w-full" required>

<button type="submit" name="submit_budget" class="bg-green-700 text-white px-4 py-2 rounded hover:bg-green-900">Submit Budget</button>
 

</form>
<?php else: ?>
    <p class="text-red-600 font-semibold mb-4">Submission deadline has passed.</p>
<?php endif; ?>

<h2 class="text-xl font-bold mb-2">Submitted Budget Requests</h2>
<table class="w-full border border-gray-300 rounded">
    <thead class="bg-gray-200">
        <tr>
            <th class="p-2 border">ID</th>
            <th class="p-2 border">File</th>
            <th class="p-2 border">Amount (RS)</th>
            <th class="p-2 border">Status</th>
            <th class="p-2 border">Requested Date</th>
            <th class="p-2 border">Approved Date</th>
            <th class="p-2 border">View</th>
            <th class="p-2 border">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($budgetRequests as $row): ?>
        <tr>
            <td class="p-2 border"><?php echo $row['request_id']; ?></td>
            <td class="p-2 border"><?php echo htmlspecialchars($row['description']); ?></td>
            <td class="p-2 border"><?php echo $row['amount']; ?></td>
            <td class="p-2 border"><?php echo ucfirst($row['status']); ?></td>
            <td class="p-2 border"><?php echo date('d M Y', strtotime($row['requested_at'])); ?></td>
            <td class="p-2 border"><?php echo $row['approved_at'] ? date('d M Y', strtotime($row['approved_at'])) : '-'; ?></td>
            <td class="p-2 border">
                <?php if (file_exists('uploads/budget/' . $row['description'])): ?>
                    <a href="<?php echo 'uploads/budget/' . urlencode($row['description']); ?>" class="text-blue-600 hover:underline" target="_blank">View</a>
                <?php else: ?>
                    <span class="text-red-600">File Missing</span>
                <?php endif; ?>
            </td>
            <td class="p-2 border">
                <?php if ($row['due_date'] >= $today): ?>
                <form action="" method="POST" onsubmit="return confirm('Delete this budget?');">
                    <input type="hidden" name="delete_budget" value="<?php echo $row['request_id']; ?>">
                    <button type="submit" class="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-800">Delete</button>
                </form>
                <?php else: ?>
                    <span class="text-gray-500">Deadline passed</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</div>
</body>
</html>
