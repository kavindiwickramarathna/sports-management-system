<?php
include 'db.php';
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get logged-in captain email
$captainEmail = $_SESSION['entered_email'];

// Fetch captain info from database
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$result = $stmt->get_result();
$captain = $result->fetch_assoc();
$stmt->close();

// Map sport_id to theme image
$sportThemes = [
    1 => 'assets/images/hero.png',       // Cricket
    2 => 'assets/images/football.jpg',   // Football
    3 => 'assets/images/rugby.jpg',      // Rugby
    4 => 'assets/images/futsal.jpg',     // Futsal
    5 => 'assets/images/swimming.jpg',   // Swimming
    6 => 'assets/images/netball.JPG',    // Netball
    7 => 'assets/images/athletic.JPG',   // Athletics
    8 => 'assets/images/basketball.jpg'  // Basketball
];

// Get sport_id from captain record
$sportId = intval($captain['sport_id'] ?? 0);

// Get theme image
$themeImage = $sportThemes[$sportId] ?? null;

// Get profile image (use default if not set)
$profileImage = $captain['profile_image'] ?? 'assets/images/default_user.png';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Captain Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-100">
    <!-- Navigation Bar -->
<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="captain.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>

        <!-- My Team Dropdown -->
        <div class="relative">
            <button id="myTeamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
                <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
                <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
                <a href="captain_budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>

        <a href="captain_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
        <a href="captain_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
    </div>

    <!-- Right side: User menu -->
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?php echo htmlspecialchars($profileImage); ?>" 
             alt="User Profile" 
             class="h-10 w-10 rounded-full border border-gray-400">
        <span class="text-black select-none">▼</span>
        <div id="userDropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-12 w-48 py-2 z-50">
    <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
    <a href="captain_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
    <a href="captain_account_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
    <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
</div>

    </div>
</nav>

<!-- Dropdown JS -->
<script>
    // My Team Dropdown
    const myTeamBtn = document.getElementById('myTeamBtn');
    const myTeamDropdown = document.getElementById('myTeamDropdown');

    myTeamBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        myTeamDropdown.classList.toggle('hidden');
    });

    // User Menu Dropdown
    const userMenu = document.querySelector('.user-menu');
    const userDropdown = document.getElementById('userDropdown');

    userMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdown.classList.toggle('hidden');
    });

    // Close dropdowns if clicking outside
    window.addEventListener('click', () => {
        myTeamDropdown.classList.add('hidden');
        userDropdown.classList.add('hidden');
    });
</script>


    <!-- Hero Section with Dynamic Background -->
    <div class="w-full min-h-screen bg-cover bg-center pt-20"
         <?php if($themeImage) echo "style=\"background-image: url('$themeImage');\""; ?>>
        <!-- No welcome box or text here -->
    </div>

    <!-- ✅ JS for Dropdown -->
    <script>
        const userMenu = document.querySelector('.user-menu');
        const userDropdown = userMenu.querySelector('.user-dropdown');

        userMenu.addEventListener('click', () => {
            userDropdown.classList.toggle('hidden');
        });

        window.addEventListener('click', function(e) {
            if (!userMenu.contains(e.target)) userDropdown.classList.add('hidden');
        });
    </script>
</body>
</html>
