<?php
include "db.php";
session_start();

// Only allow captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    echo json_encode(["status"=>"error","message"=>"Unauthorized"]);
    exit();
}

$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s",$captainEmail);
$stmt->execute();
$captain = $stmt->get_result()->fetch_assoc();
$sport_id = $captain['sport_id'] ?? 0;
$captain_id = $captain['user_id'];

$action = $_POST['action'] ?? '';

if($action === "add"){
    $type = $_POST['type'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $location = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');

    if(!$type || !$name || !$date){
        echo json_encode(["status"=>"error","message"=>"Missing required fields"]);
        exit();
    }

    if($type==="event"){
        $ins = $conn->prepare("INSERT INTO events (sport_id, captain_id, event_name, event_date, status, description) VALUES (?,?,?,?, 'Pending', ?)");
        $ins->bind_param("iisss",$sport_id,$captain_id,$name,$date,$description);
        $ins->execute();
        $id = $conn->insert_id;
        $item = ["type"=>"event","event_id"=>$id,"event_name"=>$name,"date"=>$date,"status"=>"Pending","description"=>$description];
    } else if($type==="session"){
        $coach_id = 1; // default coach_id
        $ins = $conn->prepare("INSERT INTO sessions (coach_id, sport_id, session_date, session_time, location, description) VALUES (?, ?, ?, ?, ?, ?)");
        $ins->bind_param("iissss",$coach_id,$sport_id,$date,$time,$location,$name);
        $ins->execute();
        $id = $conn->insert_id;
        $item = ["type"=>"session","session_id"=>$id,"description"=>$name,"date"=>$date,"session_time"=>$time,"location"=>$location];
    } else {
        echo json_encode(["status"=>"error","message"=>"Invalid type"]);
        exit();
    }

    echo json_encode(["status"=>"success","message"=>"$type added successfully","item"=>$item]);
    exit();
}

if($action==="delete"){
    $type = $_POST['type'] ?? '';
    $id = $_POST['id'] ?? '';
    if(!$type || !$id){
        echo json_encode(["status"=>"error","message"=>"Missing parameters"]);
        exit();
    }

    if($type==="event"){
        $del = $conn->prepare("DELETE FROM events WHERE event_id=? AND captain_id=?");
        $del->bind_param("ii",$id,$captain_id);
    } else if($type==="session"){
        $del = $conn->prepare("DELETE FROM sessions WHERE session_id=? AND sport_id=?");
        $del->bind_param("ii",$id,$sport_id);
    } else {
        echo json_encode(["status"=>"error","message"=>"Invalid type"]);
        exit();
    }

    if($del->execute()){
        echo json_encode(["status"=>"success","message"=>"$type deleted successfully"]);
    } else {
        echo json_encode(["status"=>"error","message"=>"Failed to delete"]);
    }
    exit();
}

echo json_encode(["status"=>"error","message"=>"Invalid action"]);
?>
