<?php
include 'db.php';
session_start();

// Only allow logged-in coaches
if(!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach'){
    header("Location: login.php");
    exit();
}

// Get logged-in coach info
$coachEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND role='coach' LIMIT 1");
$stmt->bind_param("s", $coachEmail);
$stmt->execute();
$coachResult = $stmt->get_result();
$coach = $coachResult->fetch_assoc();
$stmt->close();

if(!$coach){
    echo "Coach not found.";
    exit();
}

$coachUserId = (int)$coach['user_id'];
$coachSportId = (int)$coach['sport_id'];
$profileImage = !empty($coach['profile_image']) ? $coach['profile_image'] : 'assets/images/default_user.png';

// Get the team of this coach
$teamStmt = $conn->prepare("SELECT * FROM teams WHERE coach_id=? LIMIT 1");
$teamStmt->bind_param("i", $coachUserId);
$teamStmt->execute();
$teamResult = $teamStmt->get_result();
$team = $teamResult->fetch_assoc();
$teamStmt->close();

$teamId = $team ? (int)$team['team_id'] : 0;

// Collect all team members including coach
$members = [];
if($teamId){
    $membersStmt = $conn->prepare("
        SELECT user_id, username, role, cb_number, profile_image
        FROM users
        WHERE role IN ('player', 'captain') AND sport_id=?
        ORDER BY FIELD(role,'captain') DESC, username ASC
    ");
    $membersStmt->bind_param("i", $coachSportId);
    $membersStmt->execute();
    $membersResult = $membersStmt->get_result();
    if($membersResult){
        $members = $membersResult->fetch_all(MYSQLI_ASSOC);
    }
    $membersStmt->close();
    // Add coach manually to members array
    $members[] = [
        'user_id' => $coachUserId,
        'username' => $coach['username'],
        'role' => 'coach',
        'cb_number' => $coach['cb_number'],
        'profile_image' => $coach['profile_image']
    ];
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Team — <?php echo htmlspecialchars($coach['username']); ?></title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md fixed w-full top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex items-center space-x-6">
                <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14">
                <a href="coach.php" class="font-semibold text-black hover:text-yellow-400 transition">Home</a>
                <a href="coach_dashboard.php" class="font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>
                <div class="relative">
                    <button id="teamBtn" class="font-semibold text-black hover:text-yellow-400 flex items-center gap-1">
                        Team ▼
                    </button>
                    <div id="teamDropdown" class="absolute left-0 mt-2 w-44 bg-white rounded-md shadow-lg hidden">
                        <a href="coach_team.php" class="block px-4 py-2 text-black hover:bg-yellow-100">My Team</a>
                    </div>
                </div>
                <a href="coach_events.php" class="font-semibold text-black hover:text-yellow-400 transition">Events</a>
                <a href="coach_calendar.php" class="font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
            </div>

 
        <div class="relative">
            <button id="userBtn" class="flex items-center gap-2 focus:outline-none">
                <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="Profile" class="h-10 w-10 rounded-full border border-gray-400">
                <span class="text-black select-none">▼</span>
            </button>
            <div id="userDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg hidden">
                <a href="coach_profile.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Profile</a>
                <a href="coach_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
                <a href="messages.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Messages</a>
                <a href="reports.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Reports</a>
                <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
            </div>
        </div>
    </div>
</div>
 

</nav>

<div class="pt-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-2xl font-bold mb-6">My Team</h1>

 
<?php if(!$team): ?>
    <p class="text-gray-600">No team assigned yet.</p>
<?php else: ?>
    <!-- Search bar -->
    <div class="mb-4">
        <input type="text" id="memberSearch" placeholder="Search members by name or CB number..." class="w-full p-2 border rounded">
        <p id="noMemberFound" class="text-red-500 mt-2 hidden">Member not found.</p>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" id="membersGrid">
        <?php foreach($members as $member): 
            $cardClass = "bg-white";
            if($member['role'] === 'captain') $cardClass = "bg-yellow-200";
            elseif($member['role'] === 'coach') $cardClass = "bg-red-200";
        ?>
        <div class="<?php echo $cardClass; ?> shadow-md rounded-lg p-4 flex flex-col items-center cursor-pointer member-card" data-userid="<?php echo $member['user_id']; ?>">
            <img src="<?php echo !empty($member['profile_image']) ? htmlspecialchars($member['profile_image']) : 'assets/images/default_user.png'; ?>" alt="<?php echo htmlspecialchars($member['username']); ?>" class="h-24 w-24 rounded-full mb-2 object-cover">
            <h2 class="font-semibold text-lg"><?php echo htmlspecialchars($member['username']); ?></h2>
            <p class="text-sm text-gray-600"><?php echo ucfirst($member['role']); ?></p>
            <p class="text-sm text-gray-600">CB: <?php echo htmlspecialchars($member['cb_number']); ?></p>
            <div class="flex gap-2 mt-2">
                <button class="px-3 py-1 bg-blue-500 text-white rounded view-profile" data-userid="<?php echo $member['user_id']; ?>">Profile</button>
                <button class="px-3 py-1 bg-teal-500 text-white rounded view-attendance" data-userid="<?php echo $member['user_id']; ?>">Attendance</button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
 

</div>

<!-- Modal -->

<div id="memberModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
    <div id="modalBox" class="bg-white rounded-lg p-6 relative max-w-md w-full">
        <button id="closeModal" class="absolute top-2 right-2 text-gray-600 hover:text-black">&times;</button>
        <div class="flex border-b mb-4">
            <button id="tabProfile" class="flex-1 py-2 px-4 font-semibold border-b-2 border-blue-500">Profile</button>
            <button id="tabAttendance" class="flex-1 py-2 px-4 font-semibold border-b-2 border-transparent">Attendance</button>
        </div>
        <div id="modalContent"></div>
    </div>
</div>

<script>
const modal = document.getElementById('memberModal');
const modalBox = document.getElementById('modalBox');
const modalContent = document.getElementById('modalContent');
const closeModal = document.getElementById('closeModal');
const tabProfile = document.getElementById('tabProfile');
const tabAttendance = document.getElementById('tabAttendance');

let currentUserId = null;

// Load profile or attendance
function loadTabContent(userId, type){
    fetch(`coach_member_details.php?user_id=${userId}&type=${type}`)
    .then(res => res.text())
    .then(data => {
        modalContent.innerHTML = data;
        if(type==='profile'){
            modalBox.classList.remove('max-w-sm');
            modalBox.classList.add('max-w-md');
            tabProfile.classList.add('border-blue-500');
            tabAttendance.classList.remove('border-blue-500');
        } else {
            modalBox.classList.remove('max-w-md');
            modalBox.classList.add('max-w-sm');
            tabProfile.classList.remove('border-blue-500');
            tabAttendance.classList.add('border-blue-500');
        }
        modal.classList.remove('hidden');
    });
}

// Profile / Attendance button click
document.querySelectorAll('.view-profile').forEach(btn => {
    btn.addEventListener('click', e => { e.stopPropagation(); currentUserId = btn.dataset.userid; loadTabContent(currentUserId, 'profile'); });
});
document.querySelectorAll('.view-attendance').forEach(btn => {
    btn.addEventListener('click', e => { e.stopPropagation(); currentUserId = btn.dataset.userid; loadTabContent(currentUserId, 'attendance'); });
});

// Tab click
tabProfile.addEventListener('click', () => { if(currentUserId) loadTabContent(currentUserId, 'profile'); });
tabAttendance.addEventListener('click', () => { if(currentUserId) loadTabContent(currentUserId, 'attendance'); });

// Close modal
closeModal.addEventListener('click', () => modal.classList.add('hidden'));
modal.addEventListener('click', e => { if(e.target===modal) modal.classList.add('hidden'); });

// Dropdown toggles
const teamBtn = document.getElementById('teamBtn');
const teamDropdown = document.getElementById('teamDropdown');
teamBtn.addEventListener('click', e => { e.stopPropagation(); teamDropdown.classList.toggle('hidden'); });

const userBtn = document.getElementById('userBtn');
const userDropdown = document.getElementById('userDropdown');
userBtn.addEventListener('click', e => { e.stopPropagation(); userDropdown.classList.toggle('hidden'); });

window.addEventListener('click', () => { teamDropdown.classList.add('hidden'); userDropdown.classList.add('hidden'); });
teamDropdown.addEventListener('click', e => e.stopPropagation());
userDropdown.addEventListener('click', e => e.stopPropagation());

// Member search by name or CB number
const searchInput = document.getElementById('memberSearch');
const memberCards = document.querySelectorAll('.member-card');
const noMemberFound = document.getElementById('noMemberFound');

searchInput.addEventListener('input', () => {
    const term = searchInput.value.toLowerCase();
    let found = false;

    memberCards.forEach(card => {
        const name = card.querySelector('h2').textContent.toLowerCase();
        const cb = card.querySelector('p:nth-of-type(2)').textContent.toLowerCase(); // CB line
        if(name.includes(term) || cb.includes(term)){
            card.style.display = 'flex';
            found = true;
        } else {
            card.style.display = 'none';
        }
    });

    noMemberFound.style.display = found ? 'none' : 'block';
});
</script>

</body>
</html>
