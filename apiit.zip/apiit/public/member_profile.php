<?php
include 'db.php';
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Check if member ID is provided
if (!isset($_GET['id'])) {
    echo "No member selected.";
    exit();
}

$memberId = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $memberId);
$stmt->execute();
$member = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$member) {
    echo "Member not found.";
    exit();
}

$profileImage = $member['profile_image'] ?? 'assets/images/default_user.png';
$captainEmail = $_SESSION['entered_email'];
$captainProfileStmt = $conn->prepare("SELECT profile_image FROM users WHERE email = ?");
$captainProfileStmt->bind_param("s", $captainEmail);
$captainProfileStmt->execute();
$captainProfile = $captainProfileStmt->get_result()->fetch_assoc();
$captainProfileStmt->close();
$captainProfileImage = $captainProfile['profile_image'] ?? 'assets/images/default_user.png';
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($member['username']); ?>'s Profile</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="captain.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>
        <div class="relative">
            <button id="myTeamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
                <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
                 <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
                <a href="budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>
        <a href="captain_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
        <a href="captain_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
    </div>
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?php echo htmlspecialchars($captainProfileImage); ?>" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400">
        <span class="text-black select-none">▼</span>
        <div id="userDropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
            <a href="captain_profile.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Profile</a>
            <a href="calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
            <a href="messages.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Messages</a>
            <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
        </div>
    </div>
</nav>

<script>
const myTeamBtn = document.getElementById('myTeamBtn');
const myTeamDropdown = document.getElementById('myTeamDropdown');
myTeamBtn.addEventListener('click', (e) => { e.stopPropagation(); myTeamDropdown.classList.toggle('hidden'); });

const userMenu = document.querySelector('.user-menu');
const userDropdown = document.getElementById('userDropdown');
userMenu.addEventListener('click', (e) => { e.stopPropagation(); userDropdown.classList.toggle('hidden'); });

window.addEventListener('click', () => { myTeamDropdown.classList.add('hidden'); userDropdown.classList.add('hidden'); });
</script>

<div class="pt-24 px-6 lg:px-12 w-full">
    <div class="max-w-xl mx-auto bg-white shadow-md rounded-lg p-6">
        <h1 class="text-3xl font-bold mb-4 text-center"><?php echo htmlspecialchars($member['username']); ?>'s Profile</h1>
        <img src="<?php echo htmlspecialchars($profileImage); ?>" 
             alt="Profile Image" 
             class="h-32 w-32 rounded-full mb-6 mx-auto border border-gray-300">

 
    <div class="space-y-3 text-gray-700">
        <p><strong>Role:</strong> <?php echo ucfirst($member['role']); ?></p>
        <p><strong>Email:</strong> <?php echo $member['email']; ?></p>
        <p><strong>Phone:</strong> <?php echo $member['phone']; ?></p>
        <p><strong>Played Before:</strong> <?php echo ucfirst($member['played_before']); ?></p>
        <p><strong>CB Number:</strong> <?php echo htmlspecialchars($member['cb_number']); ?></p>
    </div>

    <div class="mt-6 text-center">
        <a href="team_overview.php" class="inline-block bg-teal-700 text-white px-4 py-2 rounded hover:bg-teal-900">← Back to Team Overview</a>
    </div>
</div>
 

</div>

</body>
</html>
