<?php
include 'db.php';
session_start();

// If user reaches this page without submitting email first, redirect to login
if (!isset($_SESSION['entered_email'])) {
    header("Location: login.php");
    exit();
}

$enteredEmail = $_SESSION['entered_email'];
$emailFound = $_SESSION['email_found'] ?? false;
$userRole = $_SESSION['user_role'] ?? null;

$password = "";
$errorMsg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = trim($_POST['password'] ?? '');

    if (!$emailFound) {
        $errorMsg = "Please enter a valid APIIT email.";
    } else {
        
        // Fetch user record from database
        $stmt = $conn->prepare("SELECT password, role FROM users WHERE email = ?");
        $stmt->bind_param("s", $enteredEmail);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $stmt->bind_result($dbPassword, $dbRole);
            $stmt->fetch();

            // Compare password directly with DB value
            if ($password === $dbPassword) {

                // ✅ Do NOT destroy session here
                // Redirect based on role
                if ($dbRole === 'admin') {
                    header("Location: admin.php");
                } elseif ($dbRole === 'coach') {
                    header("Location: coach.php");
                } elseif ($dbRole === 'captain') {
                    header("Location: captain.php");
                } elseif ($dbRole === 'player') {
                    header("Location: player.php");
                } else {
                    $errorMsg = "Invalid role assigned.";
                }

                exit();

            } else {
                $errorMsg = "Wrong password.";
            }
        } else {
            $errorMsg = "User not found.";
        }

        $stmt->close();
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Enter Password - APIIT</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex items-center justify-center bg-cover bg-center relative" style="background-image: url('assets/images/login.jpg');">
  <div class="absolute inset-0 bg-black bg-opacity-60"></div>

  <div class="relative bg-white rounded-2xl p-8 w-80 sm:w-96 shadow-xl z-10">
    <div class="flex items-center mb-4">
      <img src="assets/images/logo.png" alt="APIIT Logo" class="w-20">
      <a href="login.php" class="ml-auto text-blue-600 font-bold text-xl hover:underline">&larr;</a>
    </div>

    <h2 class="text-2xl font-bold mb-4">Enter Password</h2>

    <?php if (!$emailFound): ?>
      <p class="text-red-600 mb-3"><?php echo htmlspecialchars("please enterd the valid apiit email"); ?></p>
    <?php endif; ?>

    <?php if ($errorMsg && $emailFound): ?>
      <p class="text-red-600 mb-3"><?php echo htmlspecialchars($errorMsg); ?></p>
    <?php endif; ?>

    <form method="POST" action="">
      <input
        type="password"
        id="password"
        name="password"
        placeholder="Enter your password"
        value="<?php echo htmlspecialchars($password); ?>"
        class="w-full bg-gray-100 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
        required
      >

      <button type="submit" class="w-full mt-2 bg-blue-600 text-white font-medium py-2 rounded-lg hover:bg-blue-700 transition duration-300">
        Sign In
      </button>
    </form>
  </div>
</body>
</html>
