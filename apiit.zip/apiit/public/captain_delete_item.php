<?php
include "db.php";
session_start();
header('Content-Type: application/json');

// Only captains allowed
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    echo json_encode(["status"=>"error","message"=>"Unauthorized"]);
    exit();
}

// Read JSON body
$input = json_decode(file_get_contents("php://input"), true);
$type = $input['type'] ?? '';
$id = $input['id'] ?? 0;

if (!$type || !$id) {
    echo json_encode(["status"=>"error","message"=>"Missing required fields"]);
    exit();
}

if ($type === 'event') {
    $stmt = $conn->prepare("DELETE FROM events WHERE event_id=?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) echo json_encode(["status"=>"success","message"=>"Event deleted successfully"]);
    else echo json_encode(["status"=>"error","message"=>"Failed to delete event"]);
} elseif ($type === 'session') {
    $stmt = $conn->prepare("DELETE FROM sessions WHERE session_id=?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) echo json_encode(["status"=>"success","message"=>"Session deleted successfully"]);
    else echo json_encode(["status"=>"error","message"=>"Failed to delete session"]);
} else {
    echo json_encode(["status"=>"error","message"=>"Invalid type"]);
}
