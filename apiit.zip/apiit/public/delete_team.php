<?php
include 'db.php';

if (isset($_POST['sport_id'])) {

    $sport_id = intval($_POST['sport_id']);

    // Get image to delete file
    $stmt = $conn->prepare("SELECT image FROM sports WHERE sport_id=?");
    $stmt->bind_param("i", $sport_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $imagePath = $row['image'];

        if (!empty($imagePath) && file_exists($imagePath)) {
            unlink($imagePath);
        }

        // Delete team
        $deleteStmt = $conn->prepare("DELETE FROM sports WHERE sport_id=?");
        $deleteStmt->bind_param("i", $sport_id);
        $deleteStmt->execute();
    }
}

header("Location: all.php?deleted=1");
exit();
?>
