<?php
include "db.php";
session_start();

// Only allow players
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'player') {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['entered_email'];

// Fetch player info
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$player = $stmt->get_result()->fetch_assoc();

$sport_id = $player['sport_id'];
$player_id = $player['id'];
$profileImage = !empty($player['profile_image']) ? $player['profile_image'] : "assets/images/default.png";

// Fetch upcoming EVENTS (today → future)
$eventsSql = $conn->prepare("
    SELECT event_id, event_name AS title, event_date AS date, description, 'event' AS type 
    FROM events 
    WHERE sport_id = ? AND event_date >= CURDATE()
    ORDER BY event_date ASC
");
$eventsSql->bind_param("i", $sport_id);
$eventsSql->execute();
$events = $eventsSql->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch upcoming SESSIONS (today → future)
$sessionsSql = $conn->prepare("
    SELECT session_id, session_date AS date, description, session_time, location, 'session' AS type 
    FROM sessions 
    WHERE sport_id = ? AND session_date >= CURDATE()
    ORDER BY session_date ASC
");
$sessionsSql->bind_param("i", $sport_id);
$sessionsSql->execute();
$sessions = $sessionsSql->get_result()->fetch_all(MYSQLI_ASSOC);

// Merge all
$timelineItems = array_merge($events, $sessions);
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Player Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.today-highlight { border: 3px solid #facc15 !important; box-shadow: 0 0 10px #facc15; animation: pulse 1.5s infinite; }
@keyframes pulse { 0% { box-shadow: 0 0 8px #facc15; } 50% { box-shadow: 0 0 16px #facc15; } 100% { box-shadow: 0 0 8px #facc15; } }
.today-badge { background: #facc15; padding: 2px 8px; font-size: 12px; border-radius: 8px; margin-left: 10px; font-weight: bold; color: black; }
.event-label { color: #dc2626; font-weight: bold; }
.session-label { color: #16a34a; font-weight: bold; }
.filter-btn { background: white; border: 1px solid #ccc; padding: 6px 12px; border-radius: 8px; cursor: pointer; }
.filter-btn:hover { background: #f4f4f4; }
.countdown { margin-top: 5px; font-weight: bold; color: #2563eb; }
</style>
</head>

<body class="bg-gray-100">

<!-- NAVIGATION BAR (from player_calendar.php) -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
        <a href="player.php" class="font-semibold hover:text-yellow-400">Home</a>
        <a href="player_dashboard.php" class="font-semibold hover:text-yellow-400">Dashboard</a>
        <a href="player_myteam.php" class="font-semibold hover:text-yellow-400">My Team</a>
        <a href="player_events.php" class="font-semibold hover:text-yellow-400">Events</a>
        <a href="player_calendar.php" class="font-semibold hover:text-yellow-400">Calendar</a>
    </div>
    <div class="relative">
        <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="User" class="h-10 w-10 rounded-full border cursor-pointer" onclick="toggleDropdown()">
        <div id="dropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
            <a href="player_view.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
            <a href="player_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
            <a href="attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
            <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
        </div>
    </div>
</nav>

<div class="pt-32 px-8">

<h1 class="text-3xl font-bold mb-6">Timeline</h1>

<div class="relative inline-block mb-6">
    <button id="filterBtn" class="filter-btn">Next 30 Days ▼</button>
    <div id="filterMenu" class="absolute hidden bg-white border rounded shadow-md w-40 mt-2">
        <button onclick="applyFilter('all')" class="block w-full text-left px-4 py-2 hover:bg-yellow-100">All</button>
        <button onclick="applyFilter('next7')" class="block w-full text-left px-4 py-2 hover:bg-yellow-100">Next 7 Days</button>
        <button onclick="applyFilter('next30')" class="block w-full text-left px-4 py-2 hover:bg-yellow-100">Next 30 Days</button>
    </div>
</div>

<div id="timelineList" class="space-y-4">
<?php
$today = date("Y-m-d");
foreach ($timelineItems as $item):
    $isToday = ($item['date'] === $today);
    $label = $item['type'] === "event" 
            ? "<span class='event-label'>EVENT</span>" 
            : "<span class='session-label'>SESSION</span>";
    $title = $item['type'] === "event" ? $item['title'] : "Training Session";
    $datetime = $item['type'] === "session" 
                ? $item['date'].' '.$item['session_time'] 
                : $item['date'].' 00:00';
?>
    <div class="timeline-item bg-white p-4 rounded shadow border"
         data-date="<?php echo $item['date']; ?>"
         data-datetime="<?php echo $datetime; ?>">

 
    <h2 class="text-xl font-semibold">
        <?php echo $title; ?>
        <?php if ($isToday): ?>
            <span class="today-badge">TODAY</span>
        <?php endif; ?>
    </h2>

    <p class="mt-1"><?php echo $label; ?></p>
    <p class="mt-1 text-gray-700"><b>Date:</b> <?php echo $item['date']; ?></p>

    <?php if ($item['type'] === "session"): ?>
        <p><b>Time:</b> <?php echo $item['session_time']; ?></p>
        <p><b>Location:</b> <?php echo $item['location']; ?></p>
    <?php endif; ?>

    <p class="mt-2 text-gray-600"><?php echo $item['description']; ?></p>
    <p class="countdown">Starts in: <span class="time-remaining">Loading...</span></p>
</div>
 

<?php endforeach; ?>

</div>

</div>

<script>
const userMenu = document.querySelector('.relative img');
const userDropdown = document.getElementById('dropdown');
userMenu.addEventListener('click', () => { userDropdown.classList.toggle('hidden'); });
window.addEventListener('click', function (e) { if (!userMenu.contains(e.target)) userDropdown.classList.add('hidden'); });

document.getElementById("filterBtn").onclick = () => { document.getElementById("filterMenu").classList.toggle("hidden"); };

function applyFilter(type) {
    const items = document.querySelectorAll(".timeline-item");
    const today = new Date(); today.setHours(0,0,0,0);
    items.forEach(item => {
        let itemDate = new Date(item.dataset.date); itemDate.setHours(0,0,0,0);
        let show = true;
        if (type === "next7") { let next7 = new Date(today); next7.setDate(today.getDate() + 7); show = itemDate >= today && itemDate <= next7; }
        else if (type === "next30") { let next30 = new Date(today); next30.setDate(today.getDate() + 30); show = itemDate >= today && itemDate <= next30; }
        else if (type === "all") show = itemDate >= today;
        item.style.display = show ? "block" : "none";
    });
    document.getElementById("filterMenu").classList.add("hidden");
}

function highlightToday() {
    const today = new Date().toISOString().split("T")[0];
    document.querySelectorAll(".timeline-item").forEach(item => { if (item.dataset.date === today) item.classList.add("today-highlight"); });
}
highlightToday();

// Countdown timer
function updateCountdowns() {
    document.querySelectorAll(".timeline-item").forEach(item => {
        const timeSpan = item.querySelector(".time-remaining");
        const target = new Date(item.dataset.datetime);
        let diff = target - new Date();
        if (diff <= 0) timeSpan.textContent = "Started";
        else {
            const days = Math.floor(diff / (1000*60*60*24)); diff -= days*1000*60*60*24;
            const hours = Math.floor(diff / (1000*60*60)); diff -= hours*1000*60*60;
            const minutes = Math.floor(diff / (1000*60)); diff -= minutes*1000*60;
            const seconds = Math.floor(diff / 1000);
            timeSpan.textContent = (days>0?days+"d ":"")+hours+"h "+minutes+"m "+seconds+"s";
        }
    });
}
setInterval(updateCountdowns, 1000); updateCountdowns();
</script>

</body>
</html>
