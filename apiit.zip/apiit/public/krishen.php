<?php
include 'db.php';

$user_id = 13;

// Fetch coach/user info
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$userResult = $stmt->get_result();
$user = $userResult->fetch_assoc();

// Handle profile update
if(isset($_POST['save_profile'])){
    $username = $_POST['username'];
    $role = $_POST['role'];
    $phone = $_POST['phone'];
    $profile_image = $_POST['profile_image'];

    $updateStmt = $conn->prepare("UPDATE users SET username=?, role=?, phone=?, profile_image=? WHERE user_id=?");
    $updateStmt->bind_param("ssssi", $username, $role, $phone, $profile_image, $user_id);
    $updateStmt->execute();

    header("Location: krishen.php");
    exit();
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $user['username']; ?> - Profile</title>

<!-- Tailwind CSS -->

<script src="https://cdn.tailwindcss.com"></script>

<style>
.nav-item:hover { color: #facc15; }
.active { color: #facc15; }

.dropdown-content, .user-dropdown {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  z-index: 10;
}

.dropdown-content a, .user-dropdown a {
  color: black;
  padding: 10px 16px;
  display: block;
}

.dropdown:hover .dropdown-content,
.user-menu:hover .user-dropdown {
  display: block;
}
</style>

</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- Navbar -->

<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" alt="Logo" class="h-12 w-12">
    <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
    <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>
    <div class="dropdown relative">
      <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
      <div class="dropdown-content rounded-md">
        <a href="all.php">All Teams</a>
        <a href="coaches.php">Coaches</a>
        <a href="players.php">Player Search</a>
      </div>
    </div>
    <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
    <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
  </div>

  <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400">
    <span class="text-black">▼</span>
    <div class="user-dropdown rounded-md right-0">
      <a href="admin_profile.php">Profile</a>
      <a href="calendar.php">Calendar</a>
      <a href="messages.php">Messages</a>
      <a href="reports.php">Reports</a>
      <a href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<main class="flex-grow pt-24 px-8">

  <!-- Profile Section -->

  <div id="profile-section" class="bg-white p-6 rounded-lg shadow-md mb-6">
    <div class="flex items-center space-x-6">
      <img id="coach-image" src="<?php echo $user['profile_image']; ?>" alt="<?php echo $user['username']; ?>" class="w-28 h-28 rounded-full border-2 border-gray-300 object-cover">
      <div>
        <h1 id="coach-name" class="text-2xl font-bold text-gray-800"><?php echo $user['username']; ?></h1>
        <p id="coach-role" class="text-gray-600"><?php echo $user['role']; ?></p>
        <p id="coach-info" class="text-gray-500 mt-2">Phone: <?php echo $user['phone']; ?></p>

 
    <div class="mt-4 flex space-x-3">
      <button id="edit-btn" class="bg-teal-500 hover:bg-teal-600 text-white font-semibold px-4 py-2 rounded-md">Edit Profile</button>
    </div>
  </div>
</div>

<!-- Hidden Edit Form -->
<div id="edit-form" class="hidden mt-6 border-t pt-4">
  <form method="post">
    <label class="block font-semibold mb-1">Coach Name:</label>
    <input type="text" name="username" class="border rounded-md px-3 py-2 w-full mb-3" value="<?php echo $user['username']; ?>">

    <label class="block font-semibold mb-1">Role:</label>
    <input type="text" name="role" class="border rounded-md px-3 py-2 w-full mb-3" value="<?php echo $user['role']; ?>">

    <label class="block font-semibold mb-1">Phone:</label>
    <input type="text" name="phone" class="border rounded-md px-3 py-2 w-full mb-3" value="<?php echo $user['phone']; ?>">

    <label class="block font-semibold mb-1">Profile Image URL:</label>
    <input type="text" name="profile_image" class="border rounded-md px-3 py-2 w-full mb-3" value="<?php echo $user['profile_image']; ?>">

    <div class="flex gap-3">
      <button type="submit" name="save_profile" class="bg-green-500 hover:bg-green-600 text-white font-semibold px-4 py-2 rounded-md">Save</button>
      <button type="button" id="cancel-btn" class="bg-gray-400 hover:bg-gray-500 text-white font-semibold px-4 py-2 rounded-md">Cancel</button>
    </div>
  </form>
</div>


  </div>

</main>

<script>
const editBtn = document.getElementById("edit-btn");
const editForm = document.getElementById("edit-form");
const cancelBtn = document.getElementById("cancel-btn");

editBtn.addEventListener("click", () => editForm.classList.toggle("hidden"));
cancelBtn.addEventListener("click", () => editForm.classList.add("hidden"));
</script>

</body>
</html>
