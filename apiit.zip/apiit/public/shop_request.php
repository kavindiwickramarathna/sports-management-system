<?php
include 'db.php';
session_start();

// Set Sri Lanka timezone correctly
$tz = new DateTimeZone('Asia/Colombo');

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT user_id, username, profile_image, sport_id FROM users WHERE email=?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$stmt->bind_result($captain_id, $captain_name, $profileImage, $captainSportID);
$stmt->fetch();
$stmt->close();

$profileImage = $profileImage ?: 'assets/images/default.png';

// Fetch captain’s sport name safely
$captainSportName = 'N/A';
if ($captainSportID) {
    $stmtSport = $conn->prepare("SELECT sport_name FROM sports WHERE sport_id = ?");
    $stmtSport->bind_param("i", $captainSportID);
    $stmtSport->execute();
    $stmtSport->bind_result($sportName);
    if ($stmtSport->fetch()) {
        $captainSportName = $sportName;
    }
    $stmtSport->close();
}

// Handle success message after redirect
$message = '';
if(isset($_GET['success'])) {
    $message = "Jersey request submitted successfully!";
}

// Handle form submission
if(isset($_POST['submit_jersey'])) {
    $quantity = $_POST['quantity'];
    $remarks = $_POST['remarks'];

    // Get current Sri Lanka time
    $now = new DateTime('now', $tz);
    $requested_at = $now->format('Y-m-d H:i:s');

    $status = 'pending';
    $message = '';

    // Design image upload
    $designFileName = '';
    if(isset($_FILES['design_image']) && $_FILES['design_image']['error'] == 0) {
        $fileTmp = $_FILES['design_image']['tmp_name'];
        $fileName = time() . '_' . basename($_FILES['design_image']['name']);
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        if(in_array($fileExt, ['png','jpg','jpeg'])) {
            $targetDir = 'assets/files/';
            if(!is_dir($targetDir)) mkdir($targetDir, 0777, true);
            $targetFile = $targetDir . $fileName;
            if(move_uploaded_file($fileTmp, $targetFile)) {
                $designFileName = $fileName;
            } else { $message = "Error uploading design file."; }
        } else { $message = "Only PNG or JPG files are allowed for design."; }
    } else { $message = "Please upload a design file."; }

    // Player list PDF upload
    $playerListFile = '';
    if(isset($_FILES['player_list']) && $_FILES['player_list']['error'] == 0) {
        $playerTmp = $_FILES['player_list']['tmp_name'];
        $playerName = time() . '_players_' . basename($_FILES['player_list']['name']);
        $playerExt = strtolower(pathinfo($playerName, PATHINFO_EXTENSION));
        if($playerExt === 'pdf') {
            $targetDir = 'assets/files/';
            if(!is_dir($targetDir)) mkdir($targetDir, 0777, true);
            $playerFilePath = $targetDir . $playerName;
            if(move_uploaded_file($playerTmp, $playerFilePath)) {
                $playerListFile = $playerName;
            } else { $message = "Error uploading player list file."; }
        } else { $message = "Player list must be a PDF file."; }
    } else { $message = "Please upload the player list PDF."; }

    // Insert into database if no errors
    if(!$message) {
        $stmt = $conn->prepare("INSERT INTO jersey_requests 
            (captain_id, sport_id, design_image, player_list, quantity, status, requested_at, remarks)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param(
            "iississs",
            $captain_id,
            $captainSportID,
            $designFileName,
            $playerListFile,
            $quantity,
            $status,
            $requested_at,
            $remarks
        );
        if($stmt->execute()) {
            $stmt->close();
            header("Location: shop_request.php?success=1");
            exit();
        } else {
            $message = "Error: Could not submit request.";
        }
    }
}

// Handle deletion only if pending
if(isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $fileResult = $conn->query("SELECT design_image, player_list, status FROM jersey_requests WHERE request_id=$delete_id AND captain_id=".$captain_id);
    if($fileRow = $fileResult->fetch_assoc()) {
        if($fileRow['status'] === 'pending') {
            if(file_exists('assets/files/'.$fileRow['design_image'])) unlink('assets/files/'.$fileRow['design_image']);
            if(file_exists('assets/files/'.$fileRow['player_list'])) unlink('assets/files/'.$fileRow['player_list']);
            $conn->query("DELETE FROM jersey_requests WHERE request_id=$delete_id AND captain_id=".$captain_id);
            $message = "Jersey request deleted successfully!";
        } else {
            $message = "Cannot delete request. Already ".$fileRow['status'];
        }
    }
}

// Fetch captain requests
$requestsResult = $conn->query("SELECT jr.*, s.sport_name FROM jersey_requests jr LEFT JOIN sports s ON jr.sport_id = s.sport_id WHERE jr.captain_id=".$captain_id." ORDER BY jr.requested_at DESC");
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Jersey Request</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 pt-24">
 
    <!-- Navigation Bar -->
<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="captain.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>

        <!-- My Team Dropdown -->
        <div class="relative">
            <button id="myTeamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
                <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
                <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
                <a href="captain_budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>

        <a href="captain_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
        <a href="captain_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
    </div>

    <!-- Right side: User menu -->
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?php echo htmlspecialchars($profileImage); ?>" 
             alt="User Profile" 
             class="h-10 w-10 rounded-full border border-gray-400">
        <span class="text-black select-none">▼</span>
        <div id="userDropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-12 w-48 py-2 z-50">
    <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
    <a href="captain_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
    <a href="captain_account_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
    <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
</div>

    </div>
</nav>

<!-- Dropdown JS -->
<script>
    // My Team Dropdown
    const myTeamBtn = document.getElementById('myTeamBtn');
    const myTeamDropdown = document.getElementById('myTeamDropdown');

    myTeamBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        myTeamDropdown.classList.toggle('hidden');
    });

    // User Menu Dropdown
    const userMenu = document.querySelector('.user-menu');
    const userDropdown = document.getElementById('userDropdown');

    userMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdown.classList.toggle('hidden');
    });

    // Close dropdowns if clicking outside
    window.addEventListener('click', () => {
        myTeamDropdown.classList.add('hidden');
        userDropdown.classList.add('hidden');
    });
</script>

<div class="container mx-auto p-6 bg-white rounded shadow-md">

<h1 class="text-3xl font-bold mb-4">Submit Your Jersey Request</h1>

<?php if($message): ?>

<p class="mb-4 text-green-600 font-semibold"><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<form action="" method="POST" enctype="multipart/form-data" class="bg-white shadow-md rounded-lg p-6 w-[95%] max-w-xl mx-auto mb-6">
    <label class="block mb-2 font-semibold text-gray-700">Sport / Team</label>
    <input type="text" value="<?= htmlspecialchars($captainSportName) ?>" class="w-full mb-4 p-2 border border-gray-300 rounded bg-gray-100" readonly>

 
<label class="block mb-2 font-semibold text-gray-700">Quantity</label>
<input type="number" name="quantity" required min="1" class="w-full mb-4 p-2 border border-gray-300 rounded">

<label class="block mb-2 font-semibold text-gray-700">Design File (PNG/JPG)</label>
<input type="file" name="design_image" accept="image/png, image/jpeg" required class="w-full mb-4">

<label class="block mb-2 font-semibold text-gray-700">Player List PDF</label>
<input type="file" name="player_list" accept="application/pdf" required class="w-full mb-4">

<label class="block mb-2 font-semibold text-gray-700">Remarks</label>
<textarea name="remarks" rows="3" class="w-full mb-4 p-2 border border-gray-300 rounded"></textarea>

<button type="submit" name="submit_jersey" class="bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600 transition">Submit Request</button>
 

</form>

<h2 class="text-2xl font-bold mb-4">Your Jersey Requests</h2>
<table class="w-full bg-white shadow-md rounded-lg overflow-hidden">
    <thead class="bg-teal-500 text-white">
        <tr>
            <th class="px-4 py-2">Sport</th>
            <th class="px-4 py-2">Quantity</th>
            <th class="px-4 py-2">Design</th>
            <th class="px-4 py-2">Player List</th>
            <th class="px-4 py-2">Status</th>
            <th class="px-4 py-2">Requested At</th>
            <th class="px-4 py-2">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php while($req = $requestsResult->fetch_assoc()): ?>
        <tr class="border-t text-center">
            <td class="px-4 py-2"><?= htmlspecialchars($req['sport_name'] ?? 'N/A') ?></td>
            <td class="px-4 py-2"><?= $req['quantity'] ?></td>
            <td class="px-4 py-2"><a href="assets/files/<?= $req['design_image'] ?>" target="_blank" class="text-blue-600 underline">View</a></td>
            <td class="px-4 py-2"><a href="assets/files/<?= $req['player_list'] ?>" target="_blank" class="text-blue-600 underline">View</a></td>
            <td class="px-4 py-2"><?= ucfirst($req['status']) ?></td>
            <td class="px-4 py-2"><?= $req['requested_at'] ?></td>
            <td class="px-4 py-2">
                <?php if($req['status'] === 'pending'): ?>
                    <a href="?delete_id=<?= $req['request_id'] ?>" onclick="return confirm('Are you sure you want to delete this request?');" class="text-red-600 underline">Delete</a>
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
</div>
</body>
</html>
