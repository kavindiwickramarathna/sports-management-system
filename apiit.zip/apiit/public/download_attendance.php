<?php
include "db.php";
session_start();

// Only allow logged-in players
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'player') {
    header("Location: login.php");
    exit();
}

// Get logged-in player info
$playerEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT user_id, username FROM users WHERE email=? AND role='player' LIMIT 1");
$stmt->bind_param("s", $playerEmail);
$stmt->execute();
$result = $stmt->get_result();
$player = $result->fetch_assoc();

if (!$player) {
    echo "Player not found!";
    exit();
}

$player_id = $player['user_id'];

// Get month and year from query parameters
$month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Fetch attendance records
$attendance_stmt = $conn->prepare("
    SELECT a.date, s.sport_name, a.status, a.remarks
    FROM attendance a
    LEFT JOIN sports s ON a.sport_id = s.sport_id
    WHERE a.user_id=? AND MONTH(a.date)=? AND YEAR(a.date)=?
    ORDER BY a.date ASC
");
$attendance_stmt->bind_param("iii", $player_id, $month, $year);
$attendance_stmt->execute();
$result = $attendance_stmt->get_result();

// Set CSV headers
$filename = "attendance_{$player['username']}_{$year}_{$month}.csv";
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');

// Open output stream
$output = fopen('php://output', 'w');

// CSV column headers
fputcsv($output, ['Date', 'Sport', 'Status', 'Remarks']);

// Write data rows
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['date'],
        $row['sport_name'] ?? 'N/A',
        $row['status'] ?? '',
        $row['remarks'] ?? ''
    ]);
}

fclose($output);
exit();
