<?php
include "db.php";
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get logged-in captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT user_id, username FROM users WHERE email=? AND role='captain' LIMIT 1");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$result = $stmt->get_result();
$captain = $result->fetch_assoc();

if (!$captain) {
    echo "Captain not found!";
    exit();
}

$captain_id = $captain['user_id'];

// Handle month/year filter
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Get attendance records for the logged-in captain filtered by month/year
$attendance_stmt = $conn->prepare("
    SELECT a.date, a.status, a.remarks, s.sport_name 
    FROM attendance a
    LEFT JOIN sports s ON a.sport_id = s.sport_id
    WHERE a.user_id=? AND MONTH(a.date)=? AND YEAR(a.date)=?
    ORDER BY a.date DESC
");
$attendance_stmt->bind_param("iii", $captain_id, $selected_month, $selected_year);
$attendance_stmt->execute();
$attendance_result = $attendance_stmt->get_result();

// Calculate summary stats
$total_sessions = $attendance_result->num_rows;
$total_present = 0;
$total_absent = 0;
foreach ($attendance_result as $row) {
    if (strtolower($row['status'] ?? '') === 'present') $total_present++;
    elseif (strtolower($row['status'] ?? '') === 'absent') $total_absent++;
}
$attendance_percentage = $total_sessions > 0 ? round(($total_present / $total_sessions) * 100, 2) : 0;

// Reset pointer to fetch rows again
$attendance_result->data_seek(0);
?>

<!DOCTYPE html>

<html>
<head>
    <title>Captain Attendance</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #eef2f7; margin: 0; padding: 20px; }
        h2 { margin-bottom: 20px; color: #333; }
        .filter { margin-bottom: 20px; }
        select, button { padding: 8px 12px; margin-right: 10px; border-radius: 5px; border: 1px solid #ccc; }
        button { background-color: teal; color: white; border: none; cursor: pointer; }
        button:hover { background-color: #45a049; }
        .summary-cards { display: flex; gap: 20px; margin-bottom: 20px; flex-wrap: wrap; }
        .card { flex: 1 1 150px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 3px 8px rgba(0,0,0,0.1); text-align: center; }
        .card h3 { margin: 0 0 10px 0; font-size: 20px; }
        .card p { margin: 0; font-size: 16px; }
        .present { color: green; font-weight: bold; }
        .absent { color: red; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; background-color: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1);}
        th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background-color: teal; color: #fff; }
        tr:hover { background-color: #f1f1f1; }
        .btn { padding: 10px 18px; background-color: #2196F3; color: #fff; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; margin-bottom: 20px; display: inline-block;}
        .btn:hover { background-color:teal; }
        @media(max-width:768px){ .summary-cards{flex-direction:column;} table, th, td{font-size:14px;} }
    </style>
</head>
<body>

<h2>Attendance for Captain <?php echo htmlspecialchars($captain['username']); ?></h2>

<div class="filter">
    <form method="GET">
        <label>Month:
            <select name="month">
                <?php for($m=1; $m<=12; $m++): ?>
                    <option value="<?php echo $m; ?>" <?php if($m==$selected_month) echo 'selected'; ?>>
                        <?php echo date('F', mktime(0,0,0,$m,1)); ?>
                    </option>
                <?php endfor; ?>
            </select>
        </label>
        <label>Year:
            <select name="year">
                <?php for($y=date('Y'); $y>=date('Y')-5; $y--): ?>
                    <option value="<?php echo $y; ?>" <?php if($y==$selected_year) echo 'selected'; ?>><?php echo $y; ?></option>
                <?php endfor; ?>
            </select>
        </label>
        <button type="submit">Filter</button>
    </form>
</div>

<div class="summary-cards">
    <div class="card">
        <h3>Total Sessions</h3>
        <p><?php echo $total_sessions; ?></p>
    </div>
    <div class="card">
        <h3>Present</h3>
        <p class="present"><?php echo $total_present; ?></p>
    </div>
    <div class="card">
        <h3>Absent</h3>
        <p class="absent"><?php echo $total_absent; ?></p>
    </div>
    <div class="card">
        <h3>Attendance %</h3>
        <p><?php echo $attendance_percentage; ?>%</p>
    </div>
</div>

<a class="btn" href="captain_download_attendance.php?month=<?php echo $selected_month; ?>&year=<?php echo $selected_year; ?>">Download CSV</a> <button class="btn" onclick="window.history.back();">Go Back</button>

<table>
    <tr>
        <th>Date</th>
        <th>Sport</th>
        <th>Status</th>
        <th>Remarks</th>
    </tr>
    <?php if ($total_sessions > 0): ?>
        <?php while($row = $attendance_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['date'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($row['sport_name'] ?? 'N/A'); ?></td>
                <td class="<?php echo strtolower($row['status'] ?? ''); ?>">
                    <?php echo htmlspecialchars($row['status'] ?? ''); ?>
                </td>
                <td><?php echo htmlspecialchars($row['remarks'] ?? ''); ?></td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="4">No attendance records found for this month.</td>
        </tr>
    <?php endif; ?>
</table>

</body>
</html>
