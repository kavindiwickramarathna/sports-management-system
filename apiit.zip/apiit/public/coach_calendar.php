<?php
include "db.php";
session_start();

// Only allow coaches
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach') {
    header("Location: login.php");
    exit();
}

// Get logged-in coach info
$coachEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND role='coach' LIMIT 1");
$stmt->bind_param("s", $coachEmail);
$stmt->execute();
$result = $stmt->get_result();
$coach = $result->fetch_assoc();
$stmt->close();

// safety: handle if coach not found
if (!$coach) {
    header("Location: login.php");
    exit();
}

$coach_id = isset($coach['user_id']) ? (int)$coach['user_id'] : 0;
$sport_id = isset($coach['sport_id']) ? (int)$coach['sport_id'] : 0;
$profileImage = !empty($coach['profile_image']) ? $coach['profile_image'] : "assets/images/default.png";

// Fetch Events
$events = [];
$q1 = $conn->prepare("SELECT * FROM events WHERE sport_id=? AND coach_id=?");
if ($q1) {
    $q1->bind_param("ii", $sport_id, $coach_id);
    $q1->execute();
    $res1 = $q1->get_result();
    while ($row = $res1->fetch_assoc()) {
        $row['type'] = "event";
        $row['date'] = $row['event_date'];
        $events[] = $row;
    }
    $q1->close();
}

// Fetch Sessions
$sessions = [];
$q2 = $conn->prepare("SELECT * FROM sessions WHERE sport_id=? AND coach_id=?");
if ($q2) {
    $q2->bind_param("ii", $sport_id, $coach_id);
    $q2->execute();
    $res2 = $q2->get_result();
    while ($row = $res2->fetch_assoc()) {
        $row['type'] = "session";
        $row['date'] = $row['session_date'];
        $sessions[] = $row;
    }
    $q2->close();
}

$calendarData = array_merge($events, $sessions);
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Coach Calendar</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.day-cell{min-height:90px;height:90px;border:1px solid #ddd;padding:6px;cursor:pointer;background:white;}
.dot-wrap{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px;}
.dot{width:10px;height:10px;border-radius:50%;}
.calendar-small{width:60%;margin:auto;transition:.3s;}
.calendar-big{width:100%;transition:.3s;}
#detailModalBox,#addModalBox{max-height:80vh;overflow-y:auto;}
button{position:relative; z-index:10;}
</style>
</head>
<body class="bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="coach.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="coach_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>

 
    <!-- Team Dropdown -->
    <div class="dropdown relative">
        <button id="teamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center gap-1">
            Team ▼
        </button>
        <div id="teamDropdown" class="absolute hidden bg-white shadow-lg rounded-md mt-2 w-40">
            <a href="coach_team.php" class="block px-4 py-2 text-black hover:bg-yellow-100">My Team</a>
        </div>
    </div>

    <a href="coach_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
    <a href="coach_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
</div>

<!-- User Menu -->
<div class="user-menu relative z-50">
    <img src="<?php echo htmlspecialchars($profileImage); ?>" 
         alt="User Profile" 
         class="h-10 w-10 rounded-full border border-gray-400 cursor-pointer"
         onclick="toggleDropdown()">
    <span class="text-black select-none cursor-pointer" onclick="toggleDropdown()">▼</span>
    <div class="user-dropdown absolute right-0 top-full mt-2 bg-white shadow-lg rounded-md w-48 py-2 hidden">
        <a href="coach_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
        <a href="coach_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
        <a href="messages.php" class="block px-4 py-2 hover:bg-yellow-100">Messages</a>
        <a href="reports.php" class="block px-4 py-2 hover:bg-yellow-100">Reports</a>
        <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
    </div>
</div>
 

</nav>

<div class="pt-32 px-8">
    <h1 class="text-3xl font-bold mb-6">Sport Calendar</h1>

 
<div class="mb-4 space-x-4">
    <button onclick="event.stopPropagation(); openAddModal('event')" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-700">Add Event</button>
    <button onclick="event.stopPropagation(); openAddModal('session')" class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-700">Add Session</button>
</div>

<div class="flex items-center space-x-4 mb-5">
    <div class="flex items-center space-x-2"><div class="dot bg-red-500"></div><span>Event</span></div>
    <div class="flex items-center space-x-2"><div class="dot bg-green-500"></div><span>Session</span></div>
</div>

<div id="calendarContainer" class="calendar-small" onclick="expandCalendar()">
    <div class="flex justify-between mb-3">
        <h2 id="monthTitle" class="text-2xl font-semibold"></h2>
        <div class="flex space-x-2">
            <select id="monthSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
            <select id="yearSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
        </div>
    </div>
    <div class="grid grid-cols-7 font-semibold text-center mb-2">
        <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
    </div>
    <div id="calendarGrid" class="grid grid-cols-7 gap-1"></div>
</div>
 

</div>

<!-- Detail Modal -->

<div id="detailModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div id="detailModalBox" class="bg-white w-96 p-5 rounded shadow-lg relative">
        <button onclick="closeModal()" class="absolute top-2 right-3 text-xl font-bold">&times;</button>
        <h2 class="text-xl font-semibold mb-3" id="modalTitle"></h2>
        <div id="modalContent"></div>
        <button onclick="closeModal()" class="mt-4 px-4 py-2 bg-gray-700 text-white rounded w-full">Close</button>
    </div>
</div>

<!-- Add Modal -->

<div id="addModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div id="addModalBox" class="bg-white w-96 p-5 rounded shadow-lg relative">
        <button onclick="closeAddModal()" class="absolute top-2 right-3 text-xl font-bold">&times;</button>
        <h2 class="text-xl font-semibold mb-3" id="addModalTitle">Add Item</h2>
        <form id="addForm">
            <input type="hidden" name="type" id="itemType">
            <div class="mb-2">
                <label class="block font-semibold">Name / Description</label>
                <input type="text" name="name" id="itemName" class="border px-2 py-1 w-full rounded" required>
            </div>
            <div class="mb-2" id="timeLocationFields">
                <label class="block font-semibold">Time</label>
                <input type="time" name="time" id="itemTime" class="border px-2 py-1 w-full rounded">
                <label class="block font-semibold mt-2">Location</label>
                <input type="text" name="location" id="itemLocation" class="border px-2 py-1 w-full rounded">
            </div>
            <div class="mb-2">
                <label class="block font-semibold">Date</label>
                <input type="date" name="date" id="itemDate" class="border px-2 py-1 w-full rounded" required>
            </div>
            <div class="mb-2">
                <label class="block font-semibold">Description</label>
                <textarea name="description" id="itemDescription" class="border px-2 py-1 w-full rounded"></textarea>
            </div>
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-800 w-full">Save</button>
        </form>
    </div>
</div>

<script>
// Calendar Data
let calendarData = <?php echo json_encode($calendarData, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>;
let currentDate = new Date();
const actionURL = "coach_calendar_action.php";

// Render calendar
function renderCalendar(){
    let year = currentDate.getFullYear();
    let month = currentDate.getMonth();
    document.getElementById("monthTitle").innerText = currentDate.toLocaleString("default",{month:"long"})+" "+year;
    document.getElementById("monthSelect").value = month;
    document.getElementById("yearSelect").value = year;

    const firstDay = new Date(year,month,1).getDay();
    const daysInMonth = new Date(year,month+1,0).getDate();
    let grid = "";
    for(let i=0;i<firstDay;i++) grid+=`<div class='day-cell bg-gray-100'></div>`;
    for(let day=1;day<=daysInMonth;day++){
        let dateStr=`${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
        let dots="";
        calendarData.forEach(item=>{
            if(item.date===dateStr) dots+=`<div class='dot ${item.type==="event"?"bg-red-500":"bg-green-500"}'></div>`;
        });
        grid+=`<div class='day-cell' onclick="openModal('${dateStr}');event.stopPropagation();">
        <div class="font-bold">${day}</div><div class="dot-wrap">${dots}</div></div>`;
    }
    document.getElementById("calendarGrid").innerHTML=grid;
}

// Month/Year selects
(function(){
    let monthSel=document.getElementById("monthSelect");
    let yearSel=document.getElementById("yearSelect");
    for(let m=0;m<12;m++) monthSel.innerHTML+=`<option value="${m}">${new Date(0,m).toLocaleString('default',{month:'long'})}</option>`;
    let year = new Date().getFullYear();
    for(let y=year-5;y<=year+5;y++) yearSel.innerHTML+=`<option value="${y}">${y}</option>`;
})();

function changeMonth(){
    currentDate.setFullYear(parseInt(document.getElementById("yearSelect").value));
    currentDate.setMonth(parseInt(document.getElementById("monthSelect").value));
    renderCalendar();
}
function expandCalendar(){
    const div=document.getElementById("calendarContainer");
    div.classList.toggle("calendar-big");
    div.classList.toggle("calendar-small");
}

function openModal(date){
    let list=calendarData.filter(x=>x.date===date);
    let html="";
    if(list.length===0) html="<p>No events or sessions on this date.</p>";
    else list.forEach(item=>{
        let idField = (item.type==='event' ? 'event_id' : 'session_id');
        let idVal = item[idField] || "";
        let delBtn = `<button onclick="deleteItem('${item.type}','${idVal}')" class='mt-1 px-2 py-1 bg-red-500 text-white rounded text-sm'>Delete</button>`;
        html+=`<div class="border-b py-2"><span class="font-semibold ${item.type==='event'?'text-red-500':'text-green-500'}">${item.type==="event"?"Event":"Session"}</span><br>
        ${item.event_name?`<b>${item.event_name}</b><br>`:""}${item.name?`<b>${item.name}</b><br>`:""}${item.description?`${item.description}<br>`:""}${item.session_time?`Time: ${item.session_time}<br>`:""}${item.location?`Location: ${item.location}<br>`:""}${delBtn}</div>`;
    });
    document.getElementById("modalTitle").innerText="Details for "+date;
    document.getElementById("modalContent").innerHTML=html;
    document.getElementById("detailModal").classList.remove("hidden");
}
function closeModal(){document.getElementById("detailModal").classList.add("hidden");}

function openAddModal(type){
    document.getElementById("addModalTitle").innerText=type==="event"?"Add Event":"Add Session";
    document.getElementById("itemType").value=type;
    document.getElementById("itemName").value="";
    document.getElementById("itemDate").value="";
    document.getElementById("itemTime").value="";
    document.getElementById("itemLocation").value="";
    document.getElementById("itemDescription").value="";
    document.getElementById("timeLocationFields").style.display=type==="event"?"none":"block";
    document.getElementById("addModal").classList.remove("hidden");
}
function closeAddModal(){document.getElementById("addModal").classList.add("hidden");}

document.getElementById("addForm").addEventListener("submit", function(e){
    e.preventDefault();
    const type=document.getElementById("itemType").value;
    const name=document.getElementById("itemName").value;
    const date=document.getElementById("itemDate").value;
    const time=document.getElementById("itemTime").value;
    const location=document.getElementById("itemLocation").value;
    const description=document.getElementById("itemDescription").value;

    if(!name || !date){ alert("Name and Date are required."); return; }

    const formData = new FormData();
    formData.append("action","add");
    formData.append("type",type);
    formData.append("name",name);
    formData.append("date",date);
    formData.append("time",time);
    formData.append("location",location);
    formData.append("description",description);

    fetch(actionURL,{method:"POST",body:formData})
    .then(r=>r.json())
    .then(res=>{
        if(res.status==="success"){
            calendarData.push(res.item);
            renderCalendar();
            closeAddModal();
            alert(res.message);
        } else alert(res.message);
    }).catch(err=>console.error(err));
});

function deleteItem(type,id){
    if(!confirm("Are you sure you want to delete this "+type+"?")) return;
    const formData = new FormData();
    formData.append("action","delete");
    formData.append("type",type);
    formData.append("id",id);

    fetch(actionURL,{method:"POST",body:formData})
    .then(r=>r.json())
    .then(res=>{
        if(res.status==="success"){
            calendarData = calendarData.filter(x => !(x.type===type && (type==='event'?x.event_id:x.session_id)==id));
            renderCalendar();
            alert(res.message);
        } else alert(res.message);
    }).catch(err=>console.error(err));
}

// ---------------- Dropdown JS ----------------
// Team dropdown logic
const teamBtn = document.getElementById('teamBtn');
const teamDropdown = document.getElementById('teamDropdown');

teamBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    teamDropdown.classList.toggle('hidden');
});

// User menu dropdown logic
function toggleDropdown() {
    const userDropdown = document.querySelector('.user-dropdown');
    userDropdown.classList.toggle('hidden');
}

// Close all dropdowns when clicking outside
window.addEventListener('click', (e) => {
    if (!teamBtn.contains(e.target) && !teamDropdown.contains(e.target)) {
        teamDropdown.classList.add('hidden');
    }
    if (!e.target.closest('.user-menu')) {
        document.querySelector('.user-dropdown').classList.add('hidden');
    }
});

renderCalendar();
</script>

</body>
</html>
