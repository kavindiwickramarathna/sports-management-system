<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $maxFiles = 150;
    $maxSize = 100 * 1024 * 1024; // 100 MB
    $uploadDir = "uploads/";

    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (count($_FILES['budgetFiles']['name']) > $maxFiles) {
        die("❌ Maximum 150 files allowed.");
    }

    foreach ($_FILES['budgetFiles']['tmp_name'] as $key => $tmpName) {
        $fileName = basename($_FILES['budgetFiles']['name'][$key]);
        $fileType = $_FILES['budgetFiles']['type'][$key];
        $fileSize = $_FILES['budgetFiles']['size'][$key];
        $targetFile = $uploadDir . $fileName;

        // Validate file type & size
        if ($fileType !== "application/pdf") {
            die("❌ Only PDF files are allowed.");
        }
        if ($fileSize > $maxSize) {
            die("❌ File exceeds 100 MB limit.");
        }

        move_uploaded_file($tmpName, $targetFile);
    }

    echo "✅ Files uploaded successfully.";
}
?>
