<?php
include 'db.php';

// Handle form submission (Add Team)
if (isset($_POST['add_team'])) {
    $teamName = trim($_POST['team_name']);
    $imageFile = "";

    // Handle image upload
    if (isset($_FILES['team_image']) && $_FILES['team_image']['error'] == 0) {
        $uploadDir = "assets/images/";
        $imageFile = $uploadDir . basename($_FILES['team_image']['name']);
        move_uploaded_file($_FILES['team_image']['tmp_name'], $imageFile);
    }

    if ($teamName != "") {
        $stmt = $conn->prepare("INSERT INTO sports (sport_name, image) VALUES (?, ?)");
        $stmt->bind_param("ss", $teamName, $imageFile);
        $stmt->execute();
        header("Location: all.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Admin Dashboard - Sports Management System</title>

  <!-- Tailwind -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    .nav-item:hover { color: #facc15; }
    .active { color: #facc15; }

    .dropdown-content, .user-dropdown {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
      z-index: 10;
    }

    .dropdown-content a, .user-dropdown a {
      color: black;
      padding: 10px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover, .user-dropdown a:hover {
      background-color: #facc15;
      color: white;
    }

    .dropdown:hover .dropdown-content,
    .user-menu:hover .user-dropdown {
      display: block;
    }

    .modal-overlay {
      position: fixed;
      inset: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: rgba(0,0,0,0.5);
      z-index: 50;
    }
  </style>
</head>

<body class="flex flex-col min-h-screen bg-gray-100">

<!-- NAVBAR -->
<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" class="h-14 w-14">

    <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
    <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

    <div class="dropdown relative">
      <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
      <div class="dropdown-content rounded-md">
        <a href="all.php">All Teams</a>
        <a href="coaches.php">Coaches</a>
        <a href="players.php">Player Search</a>
      </div>
    </div>

    <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
      <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
    <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
  </div>

  <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="assets/images/vithara.png" class="h-10 w-10 rounded-full border border-gray-400">
    <span class="text-black">▼</span>
    <div class="user-dropdown rounded-md right-0">
      <a href="admin_profile.php">Profile</a>
      <a href="calendar.php">Calendar</a>
      <a href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<!-- MAIN -->
<main class="flex-grow mt-24 px-10 pb-20">
  <h1 class="text-3xl font-bold mb-4">All Teams</h1>

  <!-- SEARCH -->
  <form method="GET" class="flex gap-4 mb-8">
    <input 
      type="text"
      name="search"
      value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>"
      placeholder="Search for a team..."
      class="bg-white border border-black rounded-md px-4 py-2 w-64"
    />
    <button class="bg-gray-800 text-white px-4 py-2 rounded-md">Search</button>
  </form>

  <?php
  // Search logic
  if (isset($_GET['search']) && trim($_GET['search']) !== "") {
      $search = "%".trim($_GET['search'])."%";
      $stmt = $conn->prepare("SELECT * FROM sports WHERE sport_name LIKE ?");
      $stmt->bind_param("s", $search);
      $stmt->execute();
      $result = $stmt->get_result();
  } else {
      $result = $conn->query("SELECT * FROM sports");
  }

  function getImageFile($imagePath) {
    if (!empty($imagePath) && file_exists($imagePath)) return $imagePath;
    return "assets/images/default.jpg";
  }
  ?>

  <!-- TEAM CARDS -->
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
    <?php while ($row = $result->fetch_assoc()) {
      $sportName = $row['sport_name'];
      $sportFile = strtolower(str_replace(" ", "_", $sportName)) . ".php";
      $imgFile = getImageFile($row['image']);
    ?>

    <a href="<?php echo $sportFile; ?>" class="team-card relative bg-white rounded-lg shadow-md p-3 w-60 hover:shadow-lg transition text-center">
      <div class="absolute top-2 right-2">
        <button class="menu-toggle text-gray-700 text-lg font-bold">⋮</button>

        <div class="menu hidden absolute -right-2 mt-2 bg-white border rounded-md shadow-md w-36">
          <form method="POST" action="delete_team.php" onsubmit="return confirm('Delete this team?');">
            <input type="hidden" name="sport_id" value="<?php echo $row['sport_id']; ?>">
            <button type="submit" class="block w-full text-left px-4 py-2 hover:bg-gray-100">
              Remove Team
            </button>
          </form>
        </div>
      </div>

      <img src="<?php echo $imgFile; ?>" class="rounded-md mb-2 w-full h-40 object-contain bg-gray-100">
      <h2 class="text-lg font-bold"><?php echo $sportName; ?> Team</h2>
      <p class="text-gray-600 text-sm">Official <?php echo $sportName; ?> team.</p>
    </a>

    <?php } ?>
  </div>
</main>

<!-- Add Team Floating Button -->
<div class="fixed bottom-6 right-6">
  <button id="addTeamBtn" class="bg-teal-800 text-white text-3xl rounded-full w-14 h-14">+</button>
</div>

<!-- Add Team Modal -->
<div id="addTeamModal" class="modal-overlay hidden">
  <div class="bg-white p-6 rounded-md w-96">
    <h2 class="text-xl font-semibold mb-4">Add Team</h2>
    <form method="POST" enctype="multipart/form-data" class="flex flex-col gap-4">
      <input type="text" name="team_name" placeholder="Team Name" class="border px-3 py-2 rounded-md" required>
      <input type="file" name="team_image" accept="image/*" class="border px-3 py-2 rounded-md">
      <div class="flex justify-end gap-4">
        <button type="submit" name="add_team" class="bg-teal-800 text-white px-4 py-2 rounded-md">Add</button>
        <button type="button" id="cancelAdd" class="bg-gray-500 text-white px-4 py-2 rounded-md">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>

// Fix ⋮ button (don't open card)
document.querySelectorAll(".menu-toggle").forEach(btn => {
  btn.addEventListener("click", function(e) {
    e.stopPropagation();
    e.preventDefault();
    const menu = this.nextElementSibling;

    document.querySelectorAll(".menu").forEach(m => {
      if (m !== menu) m.classList.add("hidden");
    });

    menu.classList.toggle("hidden");
  });
});

// Prevent menu click from opening page
document.querySelectorAll(".menu").forEach(menu => {
  menu.addEventListener("click", function(e) {
    e.stopPropagation();
    e.preventDefault();
  });
});

// Close menu on outside click
document.addEventListener("click", () => {
  document.querySelectorAll(".menu").forEach(menu => menu.classList.add("hidden"));
});

// Add Team Modal Logic
const addBtn = document.getElementById("addTeamBtn");
const addModal = document.getElementById("addTeamModal");
const cancelBtn = document.getElementById("cancelAdd");

addBtn.addEventListener("click", () => addModal.classList.remove("hidden"));
cancelBtn.addEventListener("click", () => addModal.classList.add("hidden"));
addModal.addEventListener("click", (e) => {
  if (e.target === addModal) addModal.classList.add("hidden");
});
</script>

</body>
</html>
