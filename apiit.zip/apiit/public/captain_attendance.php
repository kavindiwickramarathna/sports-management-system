<?php
include 'db.php';
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get captain
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$captain = $stmt->get_result()->fetch_assoc();
$stmt->close();

$sportId = $captain['sport_id'];
$today = date('Y-m-d');

$attendanceHistory = false;
$selectedHistoryDate = "";
$successMsg = "";

// FETCH MEMBERS (player + coach + captain)
$membersStmt = $conn->prepare("
    SELECT user_id, username, role 
    FROM users 
    WHERE sport_id=? AND role IN ('player', 'coach', 'captain')
");
$membersStmt->bind_param("i", $sportId);
$membersStmt->execute();
$membersResult = $membersStmt->get_result();
$members = $membersResult->fetch_all(MYSQLI_ASSOC);
$membersStmt->close();

// ============ SAVE ATTENDANCE =============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {

    $date = $_POST['attendance_date'];
    $memberIds = $_POST['member_id'];
    $statusArr = $_POST['status'];
    $remarksArr = $_POST['remarks'];

    foreach ($memberIds as $i => $memberId) {

        $status = strtolower($statusArr[$i]);
        $remarks = trim($remarksArr[$i]);
        if ($remarks === "") $remarks = NULL;

        // Insert or update via UNIQUE (user_id, sport_id, date)
        $stmt = $conn->prepare("
            INSERT INTO attendance (user_id, sport_id, date, status, remarks)
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE status=?, remarks=?
        ");

        $stmt->bind_param(
            "iisssss",
            $memberId, $sportId, $date, $status, $remarks,
            $status, $remarks
        );
        $stmt->execute();
        $stmt->close();
    }

    $successMsg = "Attendance saved successfully!";
}

// ============ VIEW HISTORY =============
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['view_history'])) {
    $attendanceHistory = true;
    $selectedHistoryDate = $_POST['history_date'];
}

// ============ FETCH ATTENDANCE DATES (past + today) =============
$dateStmt = $conn->prepare("
    SELECT DISTINCT date 
    FROM attendance 
    WHERE sport_id=?
    ORDER BY date DESC
");
$dateStmt->bind_param("i", $sportId);
$dateStmt->execute();
$dateResult = $dateStmt->get_result();
$attendanceDates = array_column(mysqli_fetch_all($dateResult, MYSQLI_ASSOC), 'date');

if (!in_array($today, $attendanceDates)) {
    array_unshift($attendanceDates, $today);
}

// ============ FUNCTION TO GET ATTENDANCE ROW ============
function getAttendance($conn, $uid, $sid, $date) {
    $stmt = $conn->prepare("
        SELECT status, remarks 
        FROM attendance 
        WHERE user_id=? AND sport_id=? AND date=?
    ");
    $stmt->bind_param("iis", $uid, $sid, $date);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $res;
}

// Profile image
$profileImage = !empty($captain['profile_image']) ? $captain['profile_image'] : 'assets/images/default_profile.png';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Captain Attendance</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<!-- NAV BAR -->
<nav class="bg-white shadow-md fixed top-0 w-full px-6 py-3 z-20 flex justify-between">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" class="h-10 w-10">
        <a href="captain.php" class="font-semibold hover:text-yellow-400">Home</a>
        <a href="captain_dashboard.php" class="font-semibold hover:text-yellow-400">Dashboard</a>

        <div class="relative">
            <button id="myTeamBtn" class="font-semibold hover:text-yellow-400 flex items-center">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>

            <div id="myTeamDropdown" class="absolute left-0 w-48 bg-white shadow-md rounded-md py-2 hidden">
                <a href="team_overview.php" class="block px-4 py-2 hover:bg-yellow-100">Team Overview</a>
                <a href="captain_attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
                <a href="captain_budget.php" class="block px-4 py-2 hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>

        <a href="captain_events.php" class="font-semibold hover:text-yellow-400">Events</a>
        <a href="captain_calendar.php" class="font-semibold hover:text-yellow-400">Calendar</a>
    </div>

    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?php echo $profileImage; ?>" class="h-10 w-10 rounded-full border">
        <span>▼</span>

        <div id="userDropdown" class="absolute right-0 top-full bg-white w-48 rounded-md shadow-md hidden py-2">
            <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
            <a href="captain_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
            <a href="captain_account_attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
            <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
        </div>
    </div>
</nav>

<script>
const myTeamBtn = document.getElementById('myTeamBtn');
const myTeamDropdown = document.getElementById('myTeamDropdown');
myTeamBtn.onclick = () => myTeamDropdown.classList.toggle('hidden');

const userMenu = document.querySelector('.user-menu');
const userDropdown = document.getElementById('userDropdown');
userMenu.onclick = () => userDropdown.classList.toggle('hidden');

window.onclick = (e) => {
    if (!myTeamBtn.contains(e.target)) myTeamDropdown.classList.add('hidden');
    if (!userMenu.contains(e.target)) userDropdown.classList.add('hidden');
};
</script>

<div class="pt-36 max-w-4xl mx-auto bg-white p-6 rounded shadow mt-6">

<!-- SUCCESS MSG -->
<?php if ($successMsg): ?>
<div class="bg-green-200 text-green-800 rounded p-3 mb-4">
    <?= $successMsg ?>
</div>
<?php endif; ?>

<!-- MARK ATTENDANCE -->
<h2 class="text-2xl font-bold mb-4">Mark Attendance</h2>

<form method="POST">
<label class="font-semibold mb-2 block">Select Date (Today or Future)</label>
<input type="date" name="attendance_date" value="<?= $today ?>" min="<?= $today ?>" class="w-full border p-2 rounded mb-4" required>

<table class="w-full border-collapse border">
<thead>
<tr>
<th class="border p-2">Member</th>
<th class="border p-2">Role</th>
<th class="border p-2">Status</th>
<th class="border p-2">Remarks</th>
</tr>
</thead>
<tbody>

<?php foreach ($members as $m): ?>
<tr>
<td class="border p-2"><?= $m['username'] ?></td>
<td class="border p-2 capitalize"><?= $m['role'] ?></td>

<td class="border p-2">
    <input type="hidden" name="member_id[]" value="<?= $m['user_id'] ?>">
    <select name="status[]" class="border p-1 rounded w-full">
        <option value="present">Present</option>
        <option value="absent">Absent</option>
    </select>
</td>

<td class="border p-2">
<input type="text" name="remarks[]" class="border p-1 rounded w-full">
</td>

</tr>
<?php endforeach; ?>

</tbody>
</table>

<button name="save_attendance" class="mt-3 bg-teal-700 text-white px-4 py-2 rounded hover:bg-teal-900">Save Attendance</button>
</form>

<hr class="my-6">

<!-- ATTENDANCE HISTORY -->
<h2 class="text-2xl font-bold mb-4">Attendance History</h2>

<form method="POST" class="mb-4">
<label class="font-semibold mb-2 block">Select Date</label>

<select name="history_date" class="w-full border p-2 rounded" required>
<?php foreach ($attendanceDates as $d): ?>
<option value="<?= $d ?>" <?= ($selectedHistoryDate == $d ? "selected" : "") ?>><?= $d ?></option>
<?php endforeach; ?>
</select>

<button name="view_history" class="bg-blue-700 text-white px-4 py-2 rounded mt-2 hover:bg-blue-900">View Attendance</button>
</form>

<?php if ($attendanceHistory && $selectedHistoryDate): ?>

<div id="attendance-history-section" class="relative bg-white border p-4 rounded shadow mb-6">

    <h3 class="text-xl font-semibold mb-3">Attendance for <?= $selectedHistoryDate ?></h3>

    <table class="w-full border-collapse border mb-4">
    <thead>
    <tr>
    <th class="border p-2">Member</th>
    <th class="border p-2">Role</th>
    <th class="border p-2">Status</th>
    <th class="border p-2">Remarks</th>
    </tr>
    </thead>
    <tbody>

    <?php foreach ($members as $m):
        $att = getAttendance($conn, $m['user_id'], $sportId, $selectedHistoryDate);
        $status = $att['status'] ?? 'absent';
        $remarks = $att['remarks'] ?? '';
    ?>
    <tr>
        <td class="border p-2"><?= $m['username'] ?></td>
        <td class="border p-2 capitalize"><?= $m['role'] ?></td>
        <td class="border p-2 <?= ($status=='present'?'text-green-600':'text-red-600') ?>"><?= ucfirst($status) ?></td>
        <td class="border p-2"><?= htmlspecialchars($remarks) ?></td>
    </tr>
    <?php endforeach; ?>

    </tbody>
    </table>

    <button id="download-btn" class="mt-3 bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-900">Download PDF</button>
    <input type="hidden" id="attendance-date" value="<?= $selectedHistoryDate ?>">

</div>

<script>
const downloadBtn = document.getElementById("download-btn");
downloadBtn.addEventListener("click", async () => {
    const wrapper = document.getElementById("attendance-history-section");
    const canvas = await html2canvas(wrapper, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p','pt','a4');
    const pdfWidth = pdf.internal.pageSize.getWidth() - 40;
    const pdfHeight = canvas.height * (pdfWidth / canvas.width);

    const dateStr = document.getElementById("attendance-date").value;

    pdf.setFontSize(18);
    pdf.text(`Attendance (${dateStr})`, 20, 30);
    pdf.addImage(imgData,'PNG',20,50,pdfWidth,pdfHeight);
    pdf.save(`Attendance_${dateStr}.pdf`);
});
</script>

<?php endif; ?>

<div class="text-center mt-6">
<a href="team_overview.php" class="bg-blue-700 text-white px-6 py-2 rounded hover:bg-blue-900">Back to Team</a>
</div>

</div>
</body>
</html>
