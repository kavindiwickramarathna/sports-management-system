<?php
include 'db.php';
session_start();

if(!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach'){
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$coachEmail = $_SESSION['entered_email'];
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$cb_number = $_POST['cb_number'] ?? '';
$played_before = isset($_POST['played_before']) ? (int)$_POST['played_before'] : 0;

// Simple validation
if(!$email || !$phone || !$cb_number){
    echo json_encode(['error' => 'Please fill all fields']);
    exit();
}

$stmt = $conn->prepare("UPDATE users SET email=?, phone=?, cb_number=?, played_before=? WHERE email=? AND role='coach'");
$stmt->bind_param("sssis", $email, $phone, $cb_number, $played_before, $coachEmail);

if($stmt->execute()){
    // Update session email in case it changed
    $_SESSION['entered_email'] = $email;

    // Return updated username for display
    $stmt2 = $conn->prepare("SELECT username FROM users WHERE email=? LIMIT 1");
    $stmt2->bind_param("s", $email);
    $stmt2->execute();
    $res = $stmt2->get_result();
    $row = $res->fetch_assoc();

    echo json_encode(['success' => true, 'username' => $row['username']]);
} else {
    echo json_encode(['error' => 'Database error']);
}

$stmt->close();
?>
