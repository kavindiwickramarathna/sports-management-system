<?php
// player_calendar.php
include "db.php";
session_start();

// Only allow players
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'player') {
    header("Location: login.php");
    exit();
}

// Get logged-in player info
$playerEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND role='player' LIMIT 1");
$stmt->bind_param("s", $playerEmail);
$stmt->execute();
$player = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$player) {
    header("Location: login.php");
    exit();
}

$sport_id = (int)$player['sport_id'];
$profileImage = !empty($player['profile_image']) ? $player['profile_image'] : "assets/images/default.png";

// Fetch ONLY approved events
$calendarData = [];
$q = $conn->prepare("SELECT *, 'event' as type, event_date as date 
                     FROM events 
                     WHERE sport_id=? AND status='approved'");
$q->bind_param("i", $sport_id);
$q->execute();
$calendarData = $q->get_result()->fetch_all(MYSQLI_ASSOC);
$q->close();

// Fetch sessions
$q = $conn->prepare("SELECT *, 'session' as type, session_date as date 
                     FROM sessions 
                     WHERE sport_id=?");
$q->bind_param("i", $sport_id);
$q->execute();
$sessions = $q->get_result()->fetch_all(MYSQLI_ASSOC);
$q->close();

$calendarData = array_merge($calendarData, $sessions);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Player Calendar</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.day-cell { min-height: 90px; border:1px solid #ddd; padding:6px; cursor:pointer; background:white; }
.dot-wrap { display:flex; flex-wrap:wrap; gap:4px; margin-top:6px; }
.dot { width:10px; height:10px; border-radius:50%; }
.calendar-small { width:60%; margin:auto; transition:.3s; }
.calendar-big { width:100%; transition:.3s; }
#detailModalBox { max-height:80vh; overflow-y:auto; }
</style>
</head>
<body class="bg-gray-100">

<!-- Navigation Bar -->
<nav class="bg-white shadow-md flex justify-between items-center px-6 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
        <a href="player.php" class="font-semibold hover:text-yellow-400">Home</a>
        <a href="player_dashboard.php" class="font-semibold hover:text-yellow-400">Dashboard</a>
        <a href="player_myteam.php" class="font-semibold hover:text-yellow-400">My Team</a>
        <a href="player_events.php" class="font-semibold hover:text-yellow-400">Events</a>
        <a href="player_calendar.php" class="font-semibold hover:text-yellow-400">Calendar</a>
    </div>

    <div class="relative">
        <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="User" 
             class="h-10 w-10 rounded-full border cursor-pointer" onclick="toggleDropdown()">
        <div id="dropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
            <a href="player_view.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
            <a href="player_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
            <a href="attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
            <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
        </div>
    </div>
</nav>

<div class="pt-32 px-8">
    <h1 class="text-3xl font-bold mb-6">Sport Calendar</h1>

<!-- Legend -->
<div class="flex items-center space-x-4 mb-5">
    <div class="flex items-center space-x-2"><div class="dot bg-red-500"></div><span>Event</span></div>
    <div class="flex items-center space-x-2"><div class="dot bg-green-500"></div><span>Session</span></div>
</div>

<!-- Calendar -->
<div id="calendarContainer" class="calendar-small" onclick="expandCalendar()">
    <div class="flex justify-between mb-3">
        <h2 id="monthTitle" class="text-2xl font-semibold"></h2>
        <div class="flex space-x-2">
            <select id="monthSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
            <select id="yearSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
        </div>
    </div>

    <div class="grid grid-cols-7 font-semibold text-center mb-2">
        <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
    </div>

    <div id="calendarGrid" class="grid grid-cols-7 gap-1"></div>
</div>
</div>

<!-- Modal -->
<div id="detailModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div id="detailModalBox" class="bg-white w-96 p-5 rounded shadow-lg relative">
        <button onclick="closeModal()" class="absolute top-2 right-3 text-xl font-bold">&times;</button>
        <h2 class="text-xl font-semibold mb-3" id="modalTitle"></h2>
        <div id="modalContent"></div>
        <button onclick="closeModal()" class="mt-4 px-4 py-2 bg-gray-700 text-white rounded w-full">Close</button>
    </div>
</div>

<script>
let calendarData = <?php echo json_encode($calendarData); ?>;
let currentDate = new Date();

function renderCalendar() {
    let year = currentDate.getFullYear();
    let month = currentDate.getMonth();
    document.getElementById("monthTitle").innerText =
        currentDate.toLocaleString("default",{month:"long"})+" "+year;

    document.getElementById("monthSelect").value = month;
    document.getElementById("yearSelect").value = year;

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month+1, 0).getDate();

    let grid = "";
    for (let i = 0; i < firstDay; i++)
        grid += `<div class='day-cell bg-gray-100'></div>`;

    for (let day = 1; day <= daysInMonth; day++) {
        let dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
        let dots = "";

        calendarData.forEach(item => {
            if (item.date === dateStr)
                dots += `<div class='dot ${item.type === "event" ? "bg-red-500" : "bg-green-500"}'></div>`;
        });

        grid += `<div class='day-cell' onclick="openModal('${dateStr}');event.stopPropagation();">
                    <div class="font-bold">${day}</div>
                    <div class="dot-wrap">${dots}</div>
                </div>`;
    }

    document.getElementById("calendarGrid").innerHTML = grid;
}

function populateSelects() {
    const monthSel = document.getElementById("monthSelect");
    const yearSel = document.getElementById("yearSelect");

    for (let m = 0; m < 12; m++)
        monthSel.innerHTML += `<option value="${m}">${new Date(0, m).toLocaleString('default',{month:'long'})}</option>`;

    const year = new Date().getFullYear();
    for (let y = year - 5; y <= year + 5; y++)
        yearSel.innerHTML += `<option value="${y}">${y}</option>`;
}
populateSelects();

function changeMonth() {
    currentDate.setFullYear(parseInt(document.getElementById("yearSelect").value));
    currentDate.setMonth(parseInt(document.getElementById("monthSelect").value));
    renderCalendar();
}

function expandCalendar() {
    const div = document.getElementById("calendarContainer");
    div.classList.toggle("calendar-big");
    div.classList.toggle("calendar-small");
}

function toggleDropdown() {
    document.getElementById("dropdown").classList.toggle("hidden");
}

function openModal(date) {
    let items = calendarData.filter(x => x.date === date);
    let html = items.length ? "" : "<p>No events or sessions on this date.</p>";

    items.forEach(item => {
        html += `<div class="border-b py-2">
            <span class="font-semibold ${item.type === 'event' ? 'text-red-500' : 'text-green-500'}">
                ${item.type === 'event' ? 'Event' : 'Session'}
            </span><br>
            ${item.event_name ? `<b>${item.event_name}</b><br>` : ""}
            ${item.description ? `${item.description}<br>` : ""}
            ${item.session_time ? `Time: ${item.session_time}<br>` : ""}
            ${item.location ? `Location: ${item.location}<br>` : ""}
        </div>`;
    });

    document.getElementById("modalTitle").innerText = "Details for " + date;
    document.getElementById("modalContent").innerHTML = html;
    document.getElementById("detailModal").classList.remove("hidden");
}

function closeModal() {
    document.getElementById("detailModal").classList.add("hidden");
}

renderCalendar();
</script>

</body>
</html>
