<?php
include 'db.php';
session_start();

// Only allow logged-in admin
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Get admin info
$adminEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $adminEmail);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();

// Fetch all budget requests with captain and sport info
$budgetRequestsQuery = "
    SELECT br.request_id, br.captain_id, u.username AS captain_name, u.sport_id, s.sport_name, 
           br.amount, br.description, br.status, br.requested_at, br.due_date
    FROM budget_requests br
    JOIN users u ON br.captain_id = u.user_id
    JOIN sports s ON br.sport_id = s.sport_id
    ORDER BY br.requested_at DESC
";
$budgetRequests = $conn->query($budgetRequestsQuery);
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - Sports Management System</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    .nav-item:hover { color: #facc15 !important; }
    .dropdown-content, .user-dropdown { display: none; position: absolute; background: white; min-width: 160px; box-shadow: 0 4px 8px rgba(0,0,0,0.2); z-index:10; }
    .dropdown-content a, .user-dropdown a { color:black; padding:10px 16px; text-decoration:none; display:block; }
    .dropdown-content a:hover, .user-dropdown a:hover { background:#facc15; color:white; }
    .dropdown:hover .dropdown-content, .user-menu:hover .user-dropdown { display:block; }
</style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
        <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

        <div class="dropdown relative">
            <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
            <div class="dropdown-content rounded-md">
                <a href="all.php">All Teams</a>
                <a href="coaches.php">Coaches</a>
                <a href="players.php">Player Search</a>
            </div>
        </div>

        <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
        <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
        <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>

    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
        <span class="text-black">▼</span>
        <div class="user-dropdown absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
            <a href="admin_profile.php">Profile</a>
            <a href="calendar.php">Calendar</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="flex-grow mt-24 px-10">
<h1 class="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>

<!-- Timeline Section -->

<div class="bg-white shadow-md rounded-lg p-6 w-[95%] mx-auto">
    <h2 class="text-2xl font-semibold mb-4 text-gray-700">Timeline</h2>

    <!-- ✅ FILTER BUTTONS ADDED HERE -->
    <div class="flex space-x-3 mb-4">
        <button onclick="filterTimeline('all')" 
                class="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">
            All
        </button>

        <button onclick="filterTimeline('approved')" 
                class="px-4 py-2 bg-green-200 text-green-800 rounded-md hover:bg-green-300">
            Approved
        </button>

        <button onclick="filterTimeline('expired')" 
                class="px-4 py-2 bg-red-200 text-red-800 rounded-md hover:bg-red-300">
            Deadline Passed
        </button>

        <button onclick="filterTimeline('pending')" 
                class="px-4 py-2 bg-yellow-200 text-yellow-800 rounded-md hover:bg-yellow-300">
            Need to Approve
        </button>
    </div>
    <!-- END FILTER BUTTONS -->

<!-- Timeline -->
<div id="timelineContainer" class="flex flex-col space-y-4">
<?php if($budgetRequests->num_rows > 0): ?>
    <?php while($row = $budgetRequests->fetch_assoc()): ?>
        <?php
        $today = date('Y-m-d');
        $isExpired = ($today > $row['due_date']);
        $hasResponded = ($row['status'] !== 'pending');
        ?>
        <div class="timeline-item flex items-center justify-between bg-gray-50 rounded-md p-4"
             data-sport="<?= strtolower($row['sport_name']); ?>"
             data-requested="<?= $row['requested_at']; ?>"
             data-due="<?= $row['due_date']; ?>">

            <div>
                <p class="text-lg font-semibold text-teal-600">📄 Budget Request</p>
                <p class="text-sm text-gray-600">
                    <?= htmlspecialchars($row['captain_name']); ?>
                    requested $<?= htmlspecialchars($row['amount']); ?>
                    for <?= htmlspecialchars($row['sport_name']); ?>
                    on <?= date('d M Y', strtotime($row['requested_at'])); ?>
                </p>
                <p class="text-sm text-gray-500">Due: <?= date('d M Y', strtotime($row['due_date'])); ?></p>
            </div>

            <button onclick="handleViewBudget(<?= $row['request_id']; ?>, this)"
                    class="bg-teal-500 text-white px-4 py-2 rounded-md hover:bg-teal-600 transition"
                    data-expired="<?= $isExpired ? '1' : '0'; ?>"
                    data-responded="<?= $hasResponded ? '1' : '0'; ?>">
                View Budget
            </button>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p class="text-gray-600">No budget requests available.</p>
<?php endif; ?>
</div>

</div>

<!-- Recently Accessed Sports Section -->

<div class="bg-white shadow-md rounded-lg p-6 w-[95%] mx-auto mt-10">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-semibold text-gray-700">Recently Accessed Sports</h2>
        <div class="flex space-x-3">
            <button id="prevBtn" class="hidden px-4 py-2 bg-gray-200 rounded-md shadow hover:bg-gray-300">◀ Prev</button>
            <button id="nextBtn" class="px-4 py-2 bg-gray-200 rounded-md shadow hover:bg-gray-300">Next ▶</button>
        </div>
    </div>

<div id="sportsContainer" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    <a href="cricket.php" class="block">
        <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hover:shadow-lg transition">
            <img src="assets/images/hero.png" alt="Cricket" class="h-32 w-full object-cover rounded-md mb-3">
            <p class="font-semibold text-gray-700">Cricket</p>
        </div>
    </a>
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center">
        <img src="assets/images/football.jpg" alt="Football" class="h-32 w-full object-cover rounded-md mb-3">
        <p class="font-semibold text-gray-700">Football</p>
    </div>
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center">
        <img src="assets/images/rugby.jpg" alt="Rugby" class="h-32 w-full object-cover rounded-md mb-3">
        <p class="font-semibold text-gray-700">Rugby</p>
    </div>
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center">
        <img src="assets/images/futsal.jpg" alt="Futsal" class="h-32 w-full object-cover rounded-md mb-3">
        <p class="font-semibold text-gray-700">Futsal</p>
    </div>
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
        <img src="assets/images/swimming.jpg" alt="Swimming" class="h-32 w-full object-cover rounded-md mb-3">
        <p class="font-semibold text-gray-700">Swimming</p>
    </div>
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
        <img src="assets/images/netball.JPG" alt="Netball" class="h-32 w-full object-cover rounded-md mb-3">
        <p class="font-semibold text-gray-700">Netball</p>
    </div>
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
        <img src="assets/images/athletic.JPG" alt="Athletics" class="h-32 w-full object-cover rounded-md mb-3">
        <p class="font-semibold text-gray-700">Athletics</p>
    </div>
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
        <img src="assets/images/basketball.jpg" alt="Basketball" class="h-32 w-full object-cover rounded-md mb-3">
        <p class="font-semibold text-gray-700">Basketball</p>
    </div>
</div>

</div>

<footer class="bg-black text-white text-center py-4">
    <p>© 2025 Sports Management System | All Rights Reserved</p>
</footer>

<script>
function handleViewBudget(requestId, btn) {
    const alreadyResponded = btn.dataset.responded === "1";
    if(alreadyResponded) { alert("You already responded to this budget."); return; }

    const isExpired = btn.dataset.expired === "1";
    if(isExpired) { window.location.href = "expired_budget.php"; return; }

    window.location.href = `view_budget.php?request_id=${requestId}`;
}

// ✅ TIMELINE FILTER FUNCTION
function filterTimeline(type) {
    const items = document.querySelectorAll(".timeline-item");
    const today = new Date().toISOString().split('T')[0];

    items.forEach(item => {
        const due = item.dataset.due;
        const statusBtn = item.querySelector("button");
        const status = statusBtn.dataset.responded === "1" ? "approved" : "pending";
        const isExpired = (today > due);

        item.style.display = "flex";

        if (type === "approved" && status !== "approved") item.style.display = "none";
        if (type === "expired" && !isExpired) item.style.display = "none";
        if (type === "pending" && (status !== "pending" || isExpired)) item.style.display = "none";
        if (type === "all") item.style.display = "flex";
    });
}

// Sports Card Next/Prev
const cards = document.querySelectorAll('.card');
const nextBtn = document.getElementById('nextBtn');
const prevBtn = document.getElementById('prevBtn');
let showingFirstSet = true;

nextBtn.addEventListener('click', () => {
    if(showingFirstSet) {
        cards.forEach((card,index) => { card.classList.toggle('hidden', index<4); });
        nextBtn.classList.add('hidden'); prevBtn.classList.remove('hidden');
        showingFirstSet = false;
    }
});

prevBtn.addEventListener('click', () => {
    if(!showingFirstSet) {
        cards.forEach((card,index) => { card.classList.toggle('hidden', index>=4); });
        prevBtn.classList.add('hidden'); nextBtn.classList.remove('hidden');
        showingFirstSet = true;
    }
});
</script>

</body>
</html>
