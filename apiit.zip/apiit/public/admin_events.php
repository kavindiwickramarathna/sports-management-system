<?php
include 'db.php';
session_start();

// Only allow admins
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Get logged-in admin info
$admin_email = $_SESSION['entered_email'];
$stmtAdmin = $conn->prepare("SELECT user_id FROM users WHERE email=? AND role='admin' LIMIT 1");
$stmtAdmin->bind_param("s", $admin_email);
$stmtAdmin->execute();
$admin_id = $stmtAdmin->get_result()->fetch_assoc()['user_id'] ?? null;

// Handle new event submission
if (isset($_POST['add_event'])) {
    $event_name = $_POST['event_name'];
    $sport_id = $_POST['sport_id'];
    $event_date = $_POST['event_date'];
    $description = $_POST['description'];
    $status = 'approved';

    $stmt = $conn->prepare("INSERT INTO events (sport_id, coach_id, event_name, event_date, status, description, captain_id) VALUES (?, NULL, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssi", $sport_id, $event_name, $event_date, $status, $description, $admin_id);
    $stmt->execute();
}

// Handle status update
if (isset($_POST['update_status'])) {
    $event_id = $_POST['event_id'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE events SET status=? WHERE event_id=?");
    $stmt->bind_param("si", $status, $event_id);
    $stmt->execute();
}

// Handle event deletion
if (isset($_POST['delete_event'])) {
    $event_id = $_POST['event_id'];
    $stmt = $conn->prepare("DELETE FROM events WHERE event_id=?");
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
}

// Today's date
$today = date("Y-m-d");

// Filter by team
$team_filter = $_GET['team_id'] ?? '';
$filter_query = '';
if ($team_filter !== '') $filter_query = " AND t.team_id=? ";

// Fetch upcoming events
$upcoming_sql = "
    SELECT e.*, u.username AS captain_name, s.sport_name, t.team_name
    FROM events e
    JOIN users u ON e.captain_id = u.user_id
    JOIN sports s ON e.sport_id = s.sport_id
    JOIN teams t ON e.captain_id = t.captain_id
    WHERE e.event_date >= ? $filter_query
    ORDER BY s.sport_name, e.event_date ASC
";
$upcoming_stmt = $conn->prepare($upcoming_sql);
if ($team_filter !== '') $upcoming_stmt->bind_param("si", $today, $team_filter);
else $upcoming_stmt->bind_param("s", $today);
$upcoming_stmt->execute();
$upcoming_events = $upcoming_stmt->get_result();

// Fetch expired events
$expired_sql = "
    SELECT e.*, u.username AS captain_name, s.sport_name, t.team_name
    FROM events e
    JOIN users u ON e.captain_id = u.user_id
    JOIN sports s ON e.sport_id = s.sport_id
    JOIN teams t ON e.captain_id = t.captain_id
    WHERE e.event_date < ? $filter_query
    ORDER BY e.event_date DESC
";
$expired_stmt = $conn->prepare($expired_sql);
if ($team_filter !== '') $expired_stmt->bind_param("si", $today, $team_filter);
else $expired_stmt->bind_param("s", $today);
$expired_stmt->execute();
$expired_events = $expired_stmt->get_result();

// Fetch sports
$sports = $conn->query("SELECT sport_id, sport_name FROM sports")->fetch_all(MYSQLI_ASSOC);

// Fetch teams
$teams = $conn->query("SELECT team_id, team_name FROM teams")->fetch_all(MYSQLI_ASSOC);

// Fetch events added by admin
$added_stmt = $conn->prepare("
    SELECT e.*, s.sport_name
    FROM events e
    JOIN sports s ON e.sport_id = s.sport_id
    WHERE e.captain_id = ?
    ORDER BY e.event_date ASC
");
$added_stmt->bind_param("i", $admin_id);
$added_stmt->execute();
$added_events = $added_stmt->get_result();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin - Event Management</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex flex-col min-h-screen bg-gray-100 pt-36">


  <style>
    /* Dropdown and hover effects */
    .nav-item:hover { color: #facc15; }
    .active { color: #facc15; }

    .dropdown-content, .user-dropdown {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
      z-index: 10;
    }

    .dropdown-content a, .user-dropdown a {
      color: black;
      padding: 10px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover, .user-dropdown a:hover {
      background-color: #facc15;
      color: white;
    }

    .dropdown:hover .dropdown-content,
    .user-menu:hover .user-dropdown {
      display: block;
    }
  </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

  <!-- ✅ Navigation Bar -->
  <nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
      <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">


      <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
      <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

      <div class="dropdown relative">
        <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
        <div class="dropdown-content rounded-md">
          <a href="all.php">All Teams</a>
          <a href="coaches.php">Coaches</a>
          <a href="players.php">Player Search</a>
        </div>
      </div>

      <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
      <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
      <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>

    </div>
    
    

    <!-- Right side -->
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
      <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
      <span class="text-black">▼</span>
      <div class="user-dropdown rounded-md right-0">
        <a href="admin_profile.php">Profile</a>
        <a href="calendar.php">Calendar</a>
        <a href="logout.php">Logout</a>
      </div>
    </div>
  </nav>

<div class="pt-16 px-8 max-w-6xl mx-auto">

<h1 class="text-3xl font-bold mb-6 text-center">Event Administration Panel</h1>

<!-- Buttons -->

<div class="flex gap-4 justify-center mb-8">
    <button onclick="toggleAddEvent()" class="bg-blue-600 text-white px-5 py-2 rounded hover:bg-blue-800">
        ➕ Add Event
    </button>
    <button onclick="toggleAddedEvents()" class="bg-green-600 text-white px-5 py-2 rounded hover:bg-green-800">
        📌 Events Added By You
    </button>
</div>

<!-- Team Filter -->

<div class="max-w-md mx-auto mb-6">
    <form method="GET" class="flex gap-2">
        <select name="team_id" class="border p-2 w-full rounded">
            <option value="">All Teams</option>
            <?php foreach ($teams as $team): ?>
                <option value="<?= $team['team_id'] ?>" <?= $team_filter == $team['team_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($team['team_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-800">Filter</button>
    </form>
</div>

<!-- Add Event Form -->

<div id="addEventForm" class="hidden bg-white p-5 rounded shadow mb-8">
<h2 class="text-2xl font-semibold mb-4">Add New Event</h2>
<form method="POST" class="space-y-4">
    <div>
        <label class="block font-semibold">Event Name</label>
        <input type="text" name="event_name" required class="border p-2 w-full rounded">
    </div>
 
 
<div>
    <label class="block font-semibold">Sport</label>
    <select name="sport_id" required class="border p-2 w-full rounded">
        <?php foreach ($sports as $sport): ?>
            <option value="<?= $sport['sport_id'] ?>"><?= htmlspecialchars($sport['sport_name']) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<div>
    <label class="block font-semibold">Event Date</label>
    <input type="date" name="event_date" min="<?= $today ?>" required class="border p-2 w-full rounded">
</div>

<div>
    <label class="block font-semibold">Description</label>
    <textarea name="description" class="border p-2 w-full rounded"></textarea>
</div>

<button type="submit" name="add_event" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-800">Add Event</button>
 

</form>
</div>

<!-- Events Added By You -->

<div id="addedByYou" class="hidden max-w-6xl mx-auto bg-white p-5 rounded shadow mt-8">
<h2 class="text-2xl font-semibold mb-4 text-blue-700">Events Added By You</h2>
<?php if ($added_events->num_rows > 0): ?>
<table class="min-w-full table-auto border-collapse">
<thead class="bg-blue-200">
<tr>
    <th class="border px-4 py-2">Event Name</th>
    <th class="border px-4 py-2">Date</th>
    <th class="border px-4 py-2">Sport</th>
    <th class="border px-4 py-2">Description</th>
    <th class="border px-4 py-2">Status</th>
</tr>
</thead>
<tbody>
<?php while ($e = $added_events->fetch_assoc()): ?>
<tr class="hover:bg-gray-100">
    <td class="border px-4 py-2"><?= htmlspecialchars($e['event_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($e['event_date']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($e['sport_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($e['description']) ?></td>
    <td class="border px-4 py-2 font-semibold <?= $e['status']=='approved'?'text-green-700':'text-yellow-600' ?>">
        <?= ucfirst($e['status']) ?>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
<?php else: ?>
<p class="text-center text-gray-500 italic">No events added by you.</p>
<?php endif; ?>
</div>

<!-- UPCOMING EVENTS -->

<div class="max-w-6xl mx-auto bg-white p-5 rounded shadow">
<?php
$current_sport = null;
while ($event = $upcoming_events->fetch_assoc()):
    if ($current_sport !== $event['sport_name']):
        if ($current_sport !== null) echo "</tbody></table><br>";
        $current_sport = $event['sport_name'];
?>
<h3 class="text-xl font-semibold mt-6 mb-2 text-green-700"><?= $current_sport ?> Events</h3>
<table class="min-w-full table-auto border-collapse mb-6">
<thead class="bg-gray-200">
<tr>
    <th class="border px-4 py-2">Event Name</th>
    <th class="border px-4 py-2">Date</th>
    <th class="border px-4 py-2">Captain</th>
    <th class="border px-4 py-2">Team</th>
    <th class="border px-4 py-2">Description</th>
    <th class="border px-4 py-2">Status</th>
    <th class="border px-4 py-2">Actions</th>
</tr>
</thead>
<tbody>
<?php endif; ?>

<tr class="hover:bg-gray-100">
    <td class="border px-4 py-2"><?= htmlspecialchars($event['event_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($event['event_date']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($event['captain_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($event['team_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($event['description']) ?></td>

 
<td class="border px-4 py-2 font-semibold 
    <?= $event['status']=='pending'?'text-yellow-600':($event['status']=='approved'?'text-green-700':'text-red-700') ?>">
    <?= ucfirst($event['status']) ?>
</td>

<td class="border px-4 py-2 flex gap-2">
    <form method="POST" class="flex gap-2">
        <input type="hidden" name="event_id" value="<?= $event['event_id'] ?>">
        <select name="status" class="border p-1 rounded">
            <option value="pending" <?= $event['status']=='pending'?'selected':'' ?>>Pending</option>
            <option value="approved" <?= $event['status']=='approved'?'selected':'' ?>>Approved</option>
            <option value="rejected" <?= $event['status']=='rejected'?'selected':'' ?>>Rejected</option>
        </select>
        <button type="submit" name="update_status" class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-800">Save</button>
    </form>
</td>
 

</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<!-- EXPIRED EVENTS -->

<h2 class="text-2xl font-bold mt-10 mb-4 text-red-700 text-center">Expired Events</h2>
<div class="max-w-6xl mx-auto bg-white p-5 rounded shadow">
<table class="min-w-full table-auto border-collapse">
<thead class="bg-red-200">
<tr>
    <th class="border px-4 py-2">Event Name</th>
    <th class="border px-4 py-2">Date</th>
    <th class="border px-4 py-2">Sport</th>
    <th class="border px-4 py-2">Captain</th>
    <th class="border px-4 py-2">Team</th>
    <th class="border px-4 py-2">Description</th>
    <th class="border px-4 py-2">Status</th>
</tr>
</thead>
<tbody>
<?php while ($exp = $expired_events->fetch_assoc()): ?>
<tr class="bg-red-50">
    <td class="border px-4 py-2"><?= htmlspecialchars($exp['event_name']) ?></td>
    <td class="border px-4 py-2 text-red-700 font-bold"><?= htmlspecialchars($exp['event_date']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($exp['sport_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($exp['captain_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($exp['team_name']) ?></td>
    <td class="border px-4 py-2"><?= htmlspecialchars($exp['description']) ?></td>
    <td class="border px-4 py-2 text-red-800 font-semibold">Expired</td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

</div>

<script>
function toggleAddEvent() { document.getElementById("addEventForm").classList.toggle("hidden"); }
function toggleAddedEvents() { document.getElementById("addedByYou").classList.toggle("hidden"); }
</script>

</body>
</html>
