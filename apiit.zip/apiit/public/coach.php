<?php
include 'db.php';
session_start();

// Only allow logged-in coaches
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach') {
    header("Location: login.php");
    exit();
}

// Get logged-in coach email
$coachEmail = $_SESSION['entered_email'];

// Fetch coach info from database
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $coachEmail);
$stmt->execute();
$result = $stmt->get_result();
$coach = $result->fetch_assoc();
$stmt->close();

// Map sport_id to theme image
$sportThemes = [
    1 => 'assets/images/hero.png',       // Cricket
    2 => 'assets/images/football.jpg',   // Football
    3 => 'assets/images/rugby.jpg',      // Rugby
    4 => 'assets/images/futsal.jpg',     // Futsal
    5 => 'assets/images/swimming.jpg',   // Swimming
    6 => 'assets/images/netball.JPG',    // Netball
    7 => 'assets/images/athletic.JPG',   // Athletics
    8 => 'assets/images/basketball.jpg'  // Basketball
];

// Get sport_id from coach record
$sportId = intval($coach['sport_id'] ?? 0);
$themeImage = $sportThemes[$sportId] ?? null;

// Get profile image (use default if not set)
$profileImage = $coach['profile_image'] ?? 'assets/images/default_user.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coach Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-100">
    <!-- Navigation Bar -->

<nav class="bg-white shadow-md fixed w-full top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex items-center space-x-6">
                <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14">
                <a href="coach.php" class="font-semibold text-black hover:text-yellow-400 transition">Home</a>
                <a href="coach_dashboard.php" class="font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>
                <div class="relative">
                    <button id="teamBtn" class="font-semibold text-black hover:text-yellow-400 flex items-center gap-1">
                        Team ▼
                    </button>
                    <div id="teamDropdown" class="absolute left-0 mt-2 w-44 bg-white rounded-md shadow-lg hidden">
                        <a href="coach_team.php" class="block px-4 py-2 text-black hover:bg-yellow-100">My Team</a>
                    </div>
                </div>
                <a href="coach_events.php" class="font-semibold text-black hover:text-yellow-400 transition">Events</a>
                <a href="coach_calendar.php" class="font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
            </div>

   <div class="user-menu relative z-50">
    <img src="<?php echo htmlspecialchars($profileImage); ?>" 
         alt="User Profile" 
         class="h-10 w-10 rounded-full border border-gray-400 cursor-pointer"
         onclick="toggleDropdown()">
    <span class="text-black select-none cursor-pointer" onclick="toggleDropdown()">▼</span>

 
<div class="user-dropdown absolute right-0 top-full mt-2 bg-white shadow-lg rounded-md w-48 py-2 hidden">
    <a href="coach_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
    <a href="coach_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
    <a href="coach_account_attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
    
    <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
</div>
 

</div>
    </nav>

<script>
function toggleDropdown() {
    const dropdown = document.querySelector('.user-dropdown');
    dropdown.classList.toggle('hidden');
}

// Close dropdown when clicking outside
window.addEventListener('click', e => {
    if (!e.target.closest('.user-menu')) {
        document.querySelector('.user-dropdown').classList.add('hidden');
    }
});
</script>
<script>
// Team dropdown logic
const teamBtn = document.getElementById('teamBtn');
const teamDropdown = document.getElementById('teamDropdown');

teamBtn.addEventListener('click', (e) => {
    e.stopPropagation(); // Prevent closing immediately
    teamDropdown.classList.toggle('hidden');
});

// User menu dropdown logic
function toggleDropdown() {
    const userDropdown = document.querySelector('.user-dropdown');
    userDropdown.classList.toggle('hidden');
}

// Close all dropdowns when clicking outside
window.addEventListener('click', (e) => {
    if (!teamBtn.contains(e.target) && !teamDropdown.contains(e.target)) {
        teamDropdown.classList.add('hidden');
    }
    if (!e.target.closest('.user-menu')) {
        document.querySelector('.user-dropdown').classList.add('hidden');
    }
});
</script>



    <!-- ✅ Hero Section with Dynamic Background -->
    <div class="w-full min-h-screen bg-cover bg-center pt-20"
         <?php if($themeImage) echo "style=\"background-image: url('$themeImage');\""; ?>>
        <!-- No welcome box or text here -->
    </div>
</body>
</html>
