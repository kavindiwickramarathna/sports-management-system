<?php
include 'db.php';
session_start();

// Only allow logged-in coaches
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach') {
    header("Location: login.php");
    exit();
}

// Get logged-in coach info
$coachEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND role = 'coach' LIMIT 1");
$stmt->bind_param("s", $coachEmail);
$stmt->execute();
$result = $stmt->get_result();
$coach = $result->fetch_assoc();
$stmt->close();

if (!$coach) {
    echo "Coach not found or not authorized.";
    exit();
}

$coachUserId = (int)$coach['user_id'];
$coachSportId = (int)$coach['sport_id'];
$profileImage = !empty($coach['profile_image']) ? $coach['profile_image'] : 'assets/images/default_user.png';

// Get sport details
$sportName = "Sport";
$sportImage = null;
$sportStmt = $conn->prepare("SELECT sport_name, image FROM sports WHERE sport_id = ? LIMIT 1");
$sportStmt->bind_param("i", $coachSportId);
$sportStmt->execute();
$sportResult = $sportStmt->get_result();
if ($sportRow = $sportResult->fetch_assoc()) {
    $sportName = $sportRow['sport_name'];
    $sportImage = $sportRow['image'];
}
$sportStmt->close();

// Fetch events
$events = [];
$eventsStmt = $conn->prepare("
    SELECT event_id, sport_id, coach_id, event_name, event_date, status, description, captain_id
    FROM events
    WHERE coach_id = ? AND sport_id = ?
    ORDER BY event_date ASC
");
$eventsStmt->bind_param("ii", $coachUserId, $coachSportId);
$eventsStmt->execute();
$eventsResult = $eventsStmt->get_result();
if ($eventsResult) {
    $events = $eventsResult->fetch_all(MYSQLI_ASSOC);
}
$eventsStmt->close();

// Fetch sessions (7-day window)
$sessions = [];
$sessionsStmt = $conn->prepare("
    SELECT session_id, coach_id, sport_id, session_date, session_time, location, description
    FROM sessions
    WHERE coach_id = ? 
      AND sport_id = ?
      AND session_date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()
    ORDER BY session_date ASC, session_time ASC
");
$sessionsStmt->bind_param("ii", $coachUserId, $coachSportId);
$sessionsStmt->execute();
$sessionsResult = $sessionsStmt->get_result();
if ($sessionsResult) {
    $sessions = $sessionsResult->fetch_all(MYSQLI_ASSOC);
}
$sessionsStmt->close();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title><?php echo htmlspecialchars($coach['username']); ?> — <?php echo htmlspecialchars($sportName); ?> Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md fixed w-full top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex items-center space-x-6">
                <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14">
                <a href="coach.php" class="font-semibold text-black hover:text-yellow-400 transition">Home</a>
                <a href="coach_dashboard.php" class="font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>
                <div class="relative">
                    <button id="teamBtn" class="font-semibold text-black hover:text-yellow-400 flex items-center gap-1">
                        Team ▼
                    </button>
                    <div id="teamDropdown" class="absolute left-0 mt-2 w-44 bg-white rounded-md shadow-lg hidden">
                        <a href="coach_team.php" class="block px-4 py-2 text-black hover:bg-yellow-100">My Team</a>
                    </div>
                </div>
                <a href="coach_events.php" class="font-semibold text-black hover:text-yellow-400 transition">Events</a>
                <a href="coach_calendar.php" class="font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
            </div>

 
        <div class="relative">
            <button id="userBtn" class="flex items-center gap-2 focus:outline-none">
                <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="Profile" class="h-10 w-10 rounded-full border border-gray-400">
                <span class="text-black select-none">▼</span>
            </button>
            <div id="userDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg hidden">
                <a href="coach_profile.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Profile</a>
                <a href="coach_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
                <a href="messages.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Messages</a>
                <a href="reports.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Reports</a>
                <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
            </div>
        </div>
    </div>
</div>
 

</nav>

<?php if ($sportImage): ?>

<div class="w-full h-40 bg-cover bg-center mt-16" style="background-image: url('<?php echo htmlspecialchars($sportImage); ?>');"></div>
<?php else: ?>
<div class="w-full h-12 mt-16"></div>
<?php endif; ?>

<!-- Dashboard Content -->

<div class="pt-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap gap-6">
    <!-- Sport Dashboard -->
    <section class="bg-white shadow-md rounded-lg p-6 flex-1 min-w-[420px]">
        <h2 class="text-xl font-bold mb-4"><?php echo htmlspecialchars($sportName); ?> Dashboard</h2>

 
    <!-- Upcoming Events -->
    <div class="mb-6">
        <h3 class="font-semibold mb-2">Upcoming Events</h3>
        <?php if (!empty($events)): ?>
        <ul class="space-y-3">
            <?php foreach ($events as $event): ?>
            <li class="border p-3 rounded">
                <div class="flex justify-between items-start">
                    <div>
                        <strong class="block text-lg"><?php echo htmlspecialchars($event['event_name']); ?></strong>
                        <div class="text-sm text-gray-600"><?php echo htmlspecialchars($event['event_date']); ?> — Status: <?php echo htmlspecialchars($event['status']); ?></div>
                    </div>
                    <div class="text-sm text-right">
                        <?php if (!empty($event['captain_id'])): ?>
                            <div>Captain: <?php echo htmlspecialchars($event['captain_id']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if (!empty($event['description'])): ?>
                    <p class="mt-2 text-gray-700"><?php echo htmlspecialchars($event['description']); ?></p>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php else: ?>
        <p class="text-gray-600">No upcoming events for <?php echo htmlspecialchars($sportName); ?>.</p>
        <?php endif; ?>
    </div>

    <!-- Upcoming Sessions -->
    <div id="sessionsContainer">
        <div class="flex justify-between items-center mb-2">
            <h3 class="font-semibold">Upcoming Sessions (last 7 days)</h3>
            <button id="toggleSessionsBtn" class="text-sm px-2 py-1 bg-gray-200 rounded hover:bg-gray-300">Minimize</button>
        </div>
        <div id="sessionsList">
        <?php if (!empty($sessions)): ?>
            <ul class="space-y-3">
                <?php foreach ($sessions as $session): ?>
                <li class="border p-3 rounded">
                    <div>
                        <div class="text-sm font-medium"><?php echo htmlspecialchars($session['session_date']); ?> <?php echo htmlspecialchars($session['session_time']); ?></div>
                        <div class="text-gray-700"><?php echo htmlspecialchars($session['location']); ?></div>
                        <?php if (!empty($session['description'])): ?>
                            <p class="mt-2 text-gray-700"><?php echo htmlspecialchars($session['description']); ?></p>
                        <?php endif; ?>
                    </div>
                </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="text-gray-600">No upcoming sessions for <?php echo htmlspecialchars($sportName); ?> in the last 7 days.</p>
        <?php endif; ?>
        </div>
    </div>
</section>

<!-- User Profile with Inline Edit -->

<aside class="bg-white shadow-md rounded-lg p-6 w-80">
    <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="Profile Image" class="h-28 w-28 rounded-full mx-auto mb-4 object-cover">

 
<h2 class="text-xl font-semibold text-center mb-2" id="usernameDisplay"><?php echo htmlspecialchars($coach['username']); ?></h2>

<form id="profileForm" class="text-sm text-gray-700 space-y-1">
    <div>
        <label>Email:</label>
        <input type="email" name="email" id="emailInput" value="<?php echo htmlspecialchars($coach['email']); ?>" class="w-full border rounded px-2 py-1 text-sm" required>
    </div>
    <div>
        <label>Phone:</label>
        <input type="text" name="phone" id="phoneInput" value="<?php echo htmlspecialchars($coach['phone']); ?>" class="w-full border rounded px-2 py-1 text-sm" required>
    </div>
    <div>
        <label>CB Number:</label>
        <input type="text" name="cb_number" id="cbInput" value="<?php echo htmlspecialchars($coach['cb_number']); ?>" class="w-full border rounded px-2 py-1 text-sm" required>
    </div>
    <div>
        <label>Played Before:</label>
        <select name="played_before" id="playedInput" class="w-full border rounded px-2 py-1 text-sm">
            <option value="1" <?php echo ($coach['played_before'] ? 'selected' : ''); ?>>Yes</option>
            <option value="0" <?php echo (!$coach['played_before'] ? 'selected' : ''); ?>>No</option>
        </select>
    </div>
    <div>
        <label>Sport:</label>
        <input type="text" value="<?php echo htmlspecialchars($sportName); ?>" class="w-full border rounded px-2 py-1 text-sm bg-gray-100 cursor-not-allowed" disabled>
    </div>

    <div class="mt-2 text-center">
        <button type="submit" class="inline-block px-4 py-2 bg-teal-600 text-white rounded hover:bg-teal-700">Update Profile</button>
    </div>
</form>

<div id="profileMessage" class="mt-2 text-center text-sm text-green-600 hidden"></div>
 

</aside>

<script>
// AJAX profile update
document.getElementById('profileForm').addEventListener('submit', function(e){
    e.preventDefault();
    const formData = new FormData(this);

    fetch('update_profile.php', {
        method: 'POST',
        body: formData
    }).then(res => res.json())
      .then(data => {
          const msg = document.getElementById('profileMessage');
          msg.classList.remove('hidden');
          if(data.success){
              msg.textContent = 'Profile updated successfully!';
              // update username display
              document.getElementById('usernameDisplay').textContent = data.username;
          } else {
              msg.textContent = data.error || 'Update failed!';
          }
      }).catch(err => {
          console.error(err);
          const msg = document.getElementById('profileMessage');
          msg.textContent = 'Network error!';
          msg.classList.remove('hidden');
      });
});
</script>


 

</div>

<script>
    // Dropdowns
    const teamBtn = document.getElementById('teamBtn');
    const teamDropdown = document.getElementById('teamDropdown');
    teamBtn.addEventListener('click', e => { e.stopPropagation(); teamDropdown.classList.toggle('hidden'); });

    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');
    userBtn.addEventListener('click', e => { e.stopPropagation(); userDropdown.classList.toggle('hidden'); });

    window.addEventListener('click', () => {
        teamDropdown.classList.add('hidden');
        userDropdown.classList.add('hidden');
    });
    teamDropdown.addEventListener('click', e => e.stopPropagation());
    userDropdown.addEventListener('click', e => e.stopPropagation());

    // Minimize Sessions
    const toggleBtn = document.getElementById('toggleSessionsBtn');
    const sessionsList = document.getElementById('sessionsList');
    toggleBtn.addEventListener('click', () => {
        if (sessionsList.style.display === 'none') {
            sessionsList.style.display = 'block';
            toggleBtn.textContent = 'Minimize';
        } else {
            sessionsList.style.display = 'none';
            toggleBtn.textContent = 'Show';
        }
    });
</script>

</body>
</html>
