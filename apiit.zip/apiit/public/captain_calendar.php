<?php
include "db.php";
session_start();

// Only allow captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$captain = $stmt->get_result()->fetch_assoc();
$stmt->close();

$sport_id = $captain['sport_id'] ?? 0;
$profileImage = $captain['profile_image'] ?? 'assets/images/default_user.png';


// -------------------------------
// FETCH APPROVED EVENTS ONLY
// -------------------------------
$events = [];
$q1 = $conn->prepare("SELECT * FROM events WHERE sport_id=? AND status='approved'");
$q1->bind_param("i", $sport_id);
$q1->execute();
$res1 = $q1->get_result();

while ($row = $res1->fetch_assoc()) {
    $row['type'] = "event";  
    $row['date'] = $row['event_date'];
    $events[] = $row;
}


// -------------------------------
// FETCH ALL SESSIONS (NO STATUS COLUMN)
// -------------------------------
$sessions = [];
$q2 = $conn->prepare("SELECT * FROM sessions WHERE sport_id=?");
$q2->bind_param("i", $sport_id);
$q2->execute();
$res2 = $q2->get_result();

while ($row = $res2->fetch_assoc()) {
    $row['type'] = "session";
    $row['date'] = $row['session_date'];
    $sessions[] = $row;
}

$calendarData = array_merge($events, $sessions);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Captain Calendar</title>
<script src="https://cdn.tailwindcss.com"></script>

<style>
.day-cell { min-height: 90px; height: 90px; border: 1px solid #ddd; padding: 4px; cursor: pointer; background: white; }
.dot-wrap { display: flex; flex-wrap: wrap; gap: 2px; }
.dot { width: 8px; height: 8px; border-radius: 50%; }
.calendar-small { width: 60%; margin: auto; transition: .3s; }
.calendar-big { width: 100%; transition: .3s; }
#detailModalBox { max-height: 80vh; overflow-y: auto; }
</style>
</head>

<body class="bg-gray-100 pt-20">

<!-- NAVIGATION BAR -->
<nav class="bg-white shadow-md flex justify-between items-center px-6 py-3 fixed w-full z-50 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" class="h-12 w-12">

        <a href="captain.php" class="font-semibold hover:text-yellow-500">Home</a>
        <a href="captain_dashboard.php" class="font-semibold hover:text-yellow-500">Dashboard</a>

        <div class="relative">
            <button id="myTeamBtn" class="font-semibold flex items-center hover:text-yellow-500">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                </svg>
            </button>

            <div id="myTeamDropdown" class="hidden absolute mt-2 w-48 bg-white shadow-md rounded py-2 z-40">
                <a href="team_overview.php" class="block px-4 py-2 hover:bg-yellow-100">Team Overview</a>
                <a href="captain_attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
                <a href="captain_budget.php" class="block px-4 py-2 hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>

        <a href="captain_events.php" class="font-semibold hover:text-yellow-500">Events</a>
        <a href="captain_calendar.php" class="font-semibold hover:text-yellow-500">Calendar</a>
    </div>

    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?php echo $profileImage; ?>" class="h-10 w-10 rounded-full border">
        <span>▼</span>
        <div id="userDropdown" class="hidden absolute right-0 top-full bg-white shadow-md rounded w-48 py-2 mt-2">
            <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
            <a href="captain_account_attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
            <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
        </div>
    </div>
</nav>

<script>
const myTeamBtn = document.getElementById('myTeamBtn');
const myTeamDropdown = document.getElementById('myTeamDropdown');
const userMenu = document.querySelector('.user-menu');
const userDropdown = document.getElementById('userDropdown');

myTeamBtn.onclick = e => { e.stopPropagation(); myTeamDropdown.classList.toggle('hidden'); userDropdown.classList.add('hidden'); };
userMenu.onclick = e => { e.stopPropagation(); userDropdown.classList.toggle('hidden'); myTeamDropdown.classList.add('hidden'); };
window.onclick = () => { myTeamDropdown.classList.add('hidden'); userDropdown.classList.add('hidden'); };
</script>

<!-- PAGE CONTENT -->
<div class="pt-32 px-8">
<h1 class="text-3xl font-bold mb-6">Sport Calendar</h1>

<div class="flex items-center space-x-4 mb-5">
    <div class="flex items-center"><div class="dot bg-red-500"></div><span class="ml-2">Event</span></div>
    <div class="flex items-center"><div class="dot bg-green-500"></div><span class="ml-2">Session</span></div>
</div>

<div id="calendarContainer" class="calendar-small" onclick="expandCalendar()">

    <div class="flex justify-between mb-3">
        <h2 id="monthTitle" class="text-2xl font-semibold"></h2>

        <div class="flex space-x-2">
            <select id="monthSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
            <select id="yearSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
        </div>
    </div>

    <div class="grid grid-cols-7 text-center font-semibold">
        <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
    </div>

    <div id="calendarGrid" class="grid grid-cols-7 gap-1"></div>
</div>
</div>


<!-- MODAL -->
<div id="detailModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div id="detailModalBox" class="bg-white p-5 w-96 rounded shadow relative">
        <button onclick="closeModal()" class="absolute top-2 right-3 text-2xl font-bold">&times;</button>
        <h2 id="modalTitle" class="text-xl font-semibold mb-3"></h2>
        <div id="modalContent"></div>
        <button onclick="closeModal()" class="w-full bg-gray-700 text-white py-2 rounded mt-4">Close</button>
    </div>
</div>


<script>
// LOAD DATA
let calendarData = <?php echo json_encode($calendarData); ?>;
let currentDate = new Date();

// ---------------------------
// RENDER CALENDAR
// ---------------------------
function renderCalendar() {
    let year = currentDate.getFullYear();
    let month = currentDate.getMonth();

    document.getElementById("monthTitle").innerText =
        currentDate.toLocaleString("default", { month: "long" }) + " " + year;

    document.getElementById("monthSelect").value = month;
    document.getElementById("yearSelect").value = year;

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    let grid = "";

    for (let i = 0; i < firstDay; i++)
        grid += `<div class='day-cell bg-gray-100'></div>`;

    for (let day = 1; day <= daysInMonth; day++) {
        let dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        let dots = "";

        calendarData.forEach(item => {
            if (item.date === dateStr) {
                dots += `<div class="dot ${item.type === 'event' ? 'bg-red-500' : 'bg-green-500'}"></div>`;
            }
        });

        grid += `
        <div class='day-cell' onclick="openModal('${dateStr}'); event.stopPropagation();">
            <div class="font-bold">${day}</div>
            <div class="dot-wrap mt-1">${dots}</div>
        </div>`;
    }

    document.getElementById("calendarGrid").innerHTML = grid;
}


// ---------------------------
// MONTH DROPDOWN SETUP
// ---------------------------
(function () {
    let monthSel = document.getElementById("monthSelect");
    let yearSel = document.getElementById("yearSelect");

    for (let m = 0; m < 12; m++)
        monthSel.innerHTML += `<option value="${m}">${new Date(0, m).toLocaleString("default", { month: "long" })}</option>`;

    let year = new Date().getFullYear();
    for (let y = year - 5; y <= year + 5; y++)
        yearSel.innerHTML += `<option value="${y}">${y}</option>`;
})();

function changeMonth() {
    currentDate.setFullYear(parseInt(document.getElementById("yearSelect").value));
    currentDate.setMonth(parseInt(document.getElementById("monthSelect").value));
    renderCalendar();
}

function expandCalendar() {
    let div = document.getElementById("calendarContainer");
    div.classList.toggle("calendar-big");
    div.classList.toggle("calendar-small");
}


// ---------------------------
// MODAL OPEN
// ---------------------------
function openModal(date) {
    let items = calendarData.filter(x => x.date === date);
    let html = "";

    if (items.length === 0) {
        html = "<p>No events or sessions on this date.</p>";
    } else {
        items.forEach(item => {
            html += `
                <div class="border-b py-2">
                    <span class="font-semibold ${item.type === 'event' ? 'text-red-500' : 'text-green-500'}">
                        ${item.type === "event" ? "Event" : "Session"}
                    </span><br>
                    ${item.event_name ? `<b>${item.event_name}</b><br>` : ""}
                    ${item.description ? `${item.description}<br>` : ""}
                    ${item.session_time ? `Time: ${item.session_time}<br>` : ""}
                    ${item.location ? `Location: ${item.location}<br>` : ""}
                </div>`;
        });
    }

    document.getElementById("modalTitle").innerHTML = `Details for ${date}`;
    document.getElementById("modalContent").innerHTML = html;
    document.getElementById("detailModal").classList.remove("hidden");
}

function closeModal() {
    document.getElementById("detailModal").classList.add("hidden");
}

renderCalendar();
</script>

</body>
</html>
