<?php
include 'db.php'; 
session_start();

$emailError = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = trim($_POST["email"] ?? "");
  $emailLower = strtolower($email);

  $pattern = '/^cb0\d{5}@(students|admin|coach|captain|player)\.apiit\.lk$/';

  // 1️⃣ Check email format first
  if (!preg_match($pattern, $emailLower)) {
    $emailError = "Please enter a valid APIIT email (e.g., cb012345@students.apiit.lk)";
  } else {

    // 2️⃣ Check if email exists in your database
    $stmt = $conn->prepare("SELECT role FROM users WHERE email = ?");
    $stmt->bind_param("s", $emailLower);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
      // Email exists → save to session
      $stmt->bind_result($role);
      $stmt->fetch();

      $_SESSION['entered_email'] = $emailLower;
      $_SESSION['email_found'] = true;
      $_SESSION['user_role'] = $role;

      // 3️⃣ Move to password page
      header("Location: password.php");
      exit();

    } else {
      // Email NOT found
      $emailError = "This email is not registered in the system.";
      $_SESSION['email_found'] = false;
    }

    $stmt->close();
  }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Login - APIIT Sports Management System</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex items-center justify-center bg-cover bg-center relative" style="background-image: url('assets/images/login.jpg');">
  <div class="absolute inset-0 bg-black bg-opacity-60"></div>

  <div class="relative bg-white rounded-2xl p-8 w-80 sm:w-96 shadow-xl z-10">
    <div class="flex flex-col items-start">
      <img src="assets/images/logo.png" alt="APIIT Logo" class="w-28 mb-4">
    </div>

    <h2 class="text-2xl font-semibold mb-6">Sign in</h2>

    <form method="POST" action="">
      <label for="email" class="block text-gray-700 text-sm mb-2">Email address</label>
      <input
        type="text"
        id="email"
        name="email"
        placeholder="cb012345@students.apiit.lk"
        value="<?php echo htmlspecialchars($email); ?>"
        class="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        required
      >
      <?php if ($emailError): ?>
        <p class="text-red-600 text-sm mt-2"><?php echo htmlspecialchars($emailError); ?></p>
      <?php endif; ?>

      <div class="mt-3">
        <a href="account.php" class="text-blue-600 text-sm hover:underline">Can't access your account?</a>
      </div>

      <button type="submit" class="w-full mt-6 bg-blue-600 text-white font-medium py-2 rounded-lg hover:bg-blue-700 transition duration-300">
        Next
      </button>
    </form>
  </div>
</body>
</html>
