<?php
include "db.php";
session_start();

// Only allow players
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'player') {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['entered_email'];

// Fetch logged-in player info
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$player = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch team members of the same sport (excluding the logged-in player)
$teamStmt = $conn->prepare("SELECT * FROM users WHERE sport_id=? AND email != ?");
$teamStmt->bind_param("is", $player['sport_id'], $email);
$teamStmt->execute();
$teamMembers = $teamStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$teamStmt->close();

// Include logged-in player first
$allMembers = array_merge([$player], $teamMembers);

// Sort so logged-in player comes first
usort($allMembers, function($a, $b) use ($player) {
    if ($a['email'] == $player['email']) return -1;
    if ($b['email'] == $player['email']) return 1;
    return 0;
});
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>My Team</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.profile-card { transition: transform 0.2s, box-shadow 0.2s; cursor: pointer; border-width: 3px; }
.profile-card:hover { transform: translateY(-5px); box-shadow: 0 8px 20px rgba(0,0,0,0.15); }
/* Role-based borders */
.border-coach { border-color: #3b82f6; } /* Blue */
.border-captain { border-color: #facc15; } /* Yellow */
.border-player { border-color: #10b981; } /* Green for logged-in player */
.label-me { background-color: #10b981; color: white; font-size: 0.75rem; padding: 0.25rem 0.5rem; border-radius: 0.25rem; position: absolute; top: 0.5rem; right: 0.5rem; }
</style>
</head>
<body class="bg-gray-100">

<!-- NAVIGATION BAR -->

<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
        <a href="player.php" class="font-semibold text-black hover:text-yellow-400">Home</a>
        <a href="player_dashboard.php" class="font-semibold text-black hover:text-yellow-400">Dashboard</a>
        <a href="player_myteam.php" class="font-semibold text-black hover:text-yellow-400">My Team</a>
        <a href="player_events.php" class="font-semibold text-black hover:text-yellow-400">Events</a>
        <a href="player_calendar.php" class="font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>
    <div class="relative">
        <img src="<?php echo htmlspecialchars($player['profile_image']); ?>" 
             alt="User" class="h-10 w-10 rounded-full border cursor-pointer" onclick="toggleDropdown()">
        <div id="dropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
            <a href="player_view.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
             <a href="player_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
            <a href="attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
            <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
        </div>
    </div>
</nav>

<script>
function toggleDropdown() {
    document.getElementById('dropdown').classList.toggle('hidden');
}
window.addEventListener('click', e => { if (!e.target.closest('.relative')) document.getElementById('dropdown').classList.add('hidden'); });
</script>

<div class="pt-32 px-8">
<h1 class="text-3xl font-bold mb-6">My Team</h1>

<?php if(count($allMembers) === 0): ?>

 
<p class="text-gray-700">No team members found.</p>
 

<?php else: ?>

 
<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
    <?php foreach($allMembers as $member):
        $borderClass = '';
        if($member['role'] === 'coach') $borderClass = 'border-coach';
        else if($member['role'] === 'captain') $borderClass = 'border-captain';
        else if($member['email'] === $player['email']) $borderClass = 'border-player';
    ?>
        <div onclick="openMemberModal(<?php echo htmlspecialchars(json_encode($member)); ?>)" 
             class="profile-card bg-white rounded-lg shadow p-4 flex flex-col items-center text-center relative <?php echo $borderClass; ?>">
            <?php if($member['email'] === $player['email']): ?>
                <div class="label-me">Me</div>
            <?php endif; ?>
            <img src="<?php echo htmlspecialchars($member['profile_image']); ?>" 
                 alt="<?php echo htmlspecialchars($member['username']); ?>" 
                 class="h-24 w-24 rounded-full object-cover mb-4 border border-gray-300">
            <h2 class="text-xl font-semibold"><?php echo htmlspecialchars($member['username']); ?></h2>
            <p class="text-gray-600">CB Number: <?php echo htmlspecialchars($member['cb_number']); ?></p>
            <p class="text-gray-600">Role: <?php echo ucfirst($member['role']); ?></p>
            <?php if($member['role'] === 'player'): ?>
                <p class="text-gray-600">Played Before: <?php echo htmlspecialchars($member['played_before']); ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>
 

<?php endif; ?>

</div>

<!-- Member Detail Modal -->

<div id="memberModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div class="bg-white w-96 p-5 rounded shadow-lg relative">
        <button onclick="closeMemberModal()" class="absolute top-2 right-3 text-xl font-bold">&times;</button>
        <h2 class="text-xl font-semibold mb-3" id="modalName"></h2>
        <img id="modalImage" src="" class="h-24 w-24 rounded-full object-cover mb-3 border border-gray-300 mx-auto">
        <p id="modalCB" class="text-gray-700 mb-1"></p>
        <p id="modalRole" class="text-gray-700 mb-1"></p>
        <p id="modalPlayed" class="text-gray-700 mb-1"></p>
        <p id="modalEmail" class="text-gray-700 mb-1"></p>
        <button onclick="closeMemberModal()" class="mt-4 px-4 py-2 bg-gray-700 text-white rounded w-full">Close</button>
    </div>
</div>

<script>
function openMemberModal(member) {
    document.getElementById('modalName').innerText = member.username + (member.email === "<?php echo $player['email']; ?>" ? " (Me)" : "");
    document.getElementById('modalImage').src = member.profile_image;
    document.getElementById('modalCB').innerText = "CB Number: " + member.cb_number;
    document.getElementById('modalRole').innerText = "Role: " + member.role.charAt(0).toUpperCase() + member.role.slice(1);
    document.getElementById('modalPlayed').innerText = member.played_before ? "Played Before: " + member.played_before : "";
    document.getElementById('modalEmail').innerText = "Email: " + member.email;
    document.getElementById('memberModal').classList.remove('hidden');
}

function closeMemberModal() {
    document.getElementById('memberModal').classList.add('hidden');
}
</script>

</body>
</html>
