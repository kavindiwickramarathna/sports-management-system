<?php
header('Content-Type: application/json');
include 'db.php';

$response = ['exists' => 0];

// Make sure cb_number is sent via GET
if(isset($_GET['cb_number']) && !empty(trim($_GET['cb_number']))) {
    $cb_number = trim($_GET['cb_number']);

    // Prepare statement
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE cb_number = ?");
    if($stmt) {
        $stmt->bind_param("s", $cb_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result && $result->num_rows > 0) {
            $response['exists'] = 1;
        }

        $stmt->close();
    } else {
        $response['error'] = "Failed to prepare statement";
    }
}

echo json_encode($response);
?>
