<?php
include "db.php";
session_start();

// Fetch all teams for filter
$teams = [];
$teamQuery = $conn->query("SELECT team_id, team_name, sport_id FROM teams");
while($row = $teamQuery->fetch_assoc()){
    $teams[] = $row;
}

// Determine selected team (from GET or default to first team)
$selected_team_id = isset($_GET['team_id']) ? intval($_GET['team_id']) : ($teams[0]['team_id'] ?? 0);

// Get the sport_id for the selected team
$selected_sport_id = 0;
foreach($teams as $team){
    if($team['team_id'] == $selected_team_id){
        $selected_sport_id = $team['sport_id'];
        break;
    }
}

// Fetch sessions for selected sport
$sessions = [];
$q1 = $conn->query("SELECT session_id, session_date AS date, session_time, location, description 
                    FROM sessions 
                    WHERE sport_id = $selected_sport_id");
while ($row = $q1->fetch_assoc()) { 
    $row["type"] = "session"; 
    $sessions[] = $row; 
}

// Fetch approved events for selected sport
$events = [];
$q2 = $conn->query("SELECT event_id, event_name, event_date AS date, description 
                    FROM events 
                    WHERE status = 'approved' AND sport_id = $selected_sport_id");
while ($row = $q2->fetch_assoc()) { 
    $row["type"] = "event"; 
    $events[] = $row; 
}

// Merge data
$calendarData = array_merge($sessions, $events);

// Format dates
foreach ($calendarData as &$item) {
    $item["date"] = date("Y-m-d", strtotime($item["date"]));
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<script src="https://cdn.tailwindcss.com"></script>
<style>
.day-cell { min-height: 90px; height: 90px; border: 1px solid #ddd; padding: 4px; cursor: pointer; background: white; }
.dot-wrap { display: flex; flex-wrap: wrap; gap: 2px; }
.dot { width: 8px; height: 8px; border-radius: 50%; }
.calendar-small { width: 60%; margin: auto; transition: 0.3s; }
.calendar-big { width: 100%; transition: 0.3s; }
#detailModalBox { max-height: 80vh; overflow-y: auto; }
/* Navigation hover */
.nav-item:hover { color: #facc15; }
.dropdown-content, .user-dropdown {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
  z-index: 10;
}
.dropdown-content a, .user-dropdown a {
  color: black;
  padding: 10px 16px;
  text-decoration: none;
  display: block;
}
.dropdown-content a:hover, .user-dropdown a:hover {
  background-color: #facc15;
  color: white;
}
.dropdown:hover .dropdown-content,
.user-menu:hover .user-dropdown {
  display: block;
}
</style>
</head>
<body class="bg-gray-100">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" class="h-14 w-14">
        <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
        <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>
        <div class="dropdown relative">
            <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
            <div class="dropdown-content rounded-md">
                <a href="all.php">All Teams</a>
                <a href="coaches.php">Coaches</a>
                <a href="players.php">Player Search</a>
            </div>
        </div>
        <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
        <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
        <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="assets/images/vithara.png" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
        <span>▼</span>
        <div class="user-dropdown absolute hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
            <a href="admin_profile.php">Profile</a>
            <a href="calendar.php">Calendar</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="pt-32 px-8">
    <h1 class="text-3xl font-bold mb-6">Calendar</h1>

 
<!-- Team Filter -->
<form method="get" class="mb-5">
    <label for="teamSelect" class="font-semibold mr-2">Filter by Team:</label>
    <select name="team_id" id="teamSelect" onchange="this.form.submit()" class="border px-2 py-1 rounded">
        <?php foreach($teams as $team): ?>
            <option value="<?= $team['team_id'] ?>" <?= $team['team_id']==$selected_team_id ? 'selected' : '' ?>>
                <?= htmlspecialchars($team['team_name']) ?>
            </option>
        <?php endforeach; ?>
    </select>
</form>

<div class="flex space-x-6 mb-5">
    <div class="flex items-center space-x-2"><div class="dot bg-red-500"></div><span>Event</span></div>
    <div class="flex items-center space-x-2"><div class="dot bg-green-500"></div><span>Session</span></div>
</div>

<div id="calendarContainer" class="calendar-small" onclick="expandCalendar()">
    <div class="flex justify-between mb-3">
        <h2 id="monthTitle" class="text-2xl font-semibold"></h2>
        <div class="flex space-x-2">
            <select id="monthSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
            <select id="yearSelect" onchange="changeMonth()" class="border px-2 py-1 rounded"></select>
        </div>
    </div>

    <div class="grid grid-cols-7 font-semibold text-center mb-2">
        <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
    </div>

    <div id="calendarGrid" class="grid grid-cols-7 gap-1"></div>
</div>
 

</div>

<!-- Modal -->

<div id="detailModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div id="detailModalBox" class="bg-white w-96 p-5 rounded shadow-lg relative">
        <button onclick="closeModal()" class="absolute top-2 right-3 text-xl font-bold">&times;</button>
        <h2 class="text-xl font-semibold mb-3" id="modalTitle"></h2>
        <div id="modalContent"></div>
        <button onclick="closeModal()" class="mt-4 px-4 py-2 bg-gray-700 text-white rounded w-full">Close</button>
    </div>
</div>

<script>
let data = <?php echo json_encode($calendarData); ?>;
let currentDate = new Date();

(function loadPickers() {
    let monthSel = document.getElementById("monthSelect");
    let yearSel = document.getElementById("yearSelect");
    for (let m = 0; m < 12; m++) {
        monthSel.innerHTML += `<option value="${m}">${new Date(0, m).toLocaleString('default',{month:'long'})}</option>`;
    }
    let year = new Date().getFullYear();
    for (let y = year-5; y<=year+5; y++) { yearSel.innerHTML += `<option value="${y}">${y}</option>`; }
})();

function renderCalendar() {
    let year = currentDate.getFullYear();
    let month = currentDate.getMonth();
    document.getElementById("monthTitle").innerText = currentDate.toLocaleString("default",{month:"long"}) + " " + year;
    document.getElementById("monthSelect").value = month;
    document.getElementById("yearSelect").value = year;

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month+1, 0).getDate();
    let grid = "";

    for (let i=0;i<firstDay;i++){ grid += `<div class='day-cell bg-gray-100'></div>`; }

    for (let day=1; day<=daysInMonth; day++){
        let dateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
        let dots = "";
        data.forEach(item=>{
            if(item.date===dateStr){
                dots += `<div class='dot ${item.type==="event"?"bg-red-500":"bg-green-500"}'></div>`;
            }
        });
        grid += `<div class='day-cell' onclick="openModal('${dateStr}'); event.stopPropagation();">
                    <div class="font-bold">${day}</div>
                    <div class="dot-wrap mt-1">${dots}</div>
                 </div>`;
    }

    document.getElementById("calendarGrid").innerHTML = grid;
}

function changeMonth(){
    currentDate.setFullYear(parseInt(document.getElementById("yearSelect").value));
    currentDate.setMonth(parseInt(document.getElementById("monthSelect").value));
    renderCalendar();
}

function expandCalendar(){
    const div = document.getElementById("calendarContainer");
    div.classList.toggle("calendar-big");
    div.classList.toggle("calendar-small");
}

function openModal(date){
    let list = data.filter(x=>x.date===date);
    let html = "";
    if(list.length===0){ html="<p>No events or sessions on this date.</p>"; }
    else{
        list.forEach(item=>{
            html += `<div class="border-b py-2">
                        <span class="font-semibold ${item.type==='event'?'text-red-500':'text-green-500'}">
                            ${item.type==="event"?"Event":"Session"}
                        </span><br>
                        ${item.event_name?`<b>${item.event_name}</b><br>`:""}
                        ${item.description?`${item.description}<br>`:""}
                        ${item.session_time?`Time: ${item.session_time}<br>`:""}
                        ${item.location?`Location: ${item.location}<br>`:""}
                     </div>`;
        });
    }
    document.getElementById("modalTitle").innerText = "Details for " + date;
    document.getElementById("modalContent").innerHTML = html;
    document.getElementById("detailModal").classList.remove("hidden");
}

function closeModal(){ document.getElementById("detailModal").classList.add("hidden"); }

renderCalendar();
</script>

</body>
</html>
