<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Sports Management System</title>

  <!-- ✅ Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    /* Dropdown and hover effects */
    .nav-item:hover { color: #facc15; }
    .active { color: #facc15; }

    .dropdown-content, .user-dropdown {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
      z-index: 10;
    }

    .dropdown-content a, .user-dropdown a {
      color: black;
      padding: 10px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover, .user-dropdown a:hover {
      background-color: #facc15;
      color: white;
    }

    .dropdown:hover .dropdown-content,
    .user-menu:hover .user-dropdown {
      display: block;
    }
  </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

  <!-- ✅ Navigation Bar -->
  <nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
      <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">


      <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
      <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

      <div class="dropdown relative">
        <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
        <div class="dropdown-content rounded-md">
          <a href="all.php">All Teams</a>
          <a href="coaches.php">Coaches</a>
          <a href="players.php">Player Search</a>
        </div>
      </div>

      <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
      <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
      <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>

    </div>
    
    

    <!-- Right side -->
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
      <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
      <span class="text-black">▼</span>
      <div class="user-dropdown rounded-md right-0">
        <a href="admin_profile.php">Profile</a>
        <a href="calendar.php">Calendar</a>
        <a href="logout.php">Logout</a>
      </div>
    </div>
  </nav>
  <!-- ✅ Fullscreen Image Slider -->
<main class="flex-grow mt-16">
  <div class="relative w-full h-[calc(100vh-4rem)] overflow-hidden bg-black flex justify-center items-center">
    
    <!-- Slider Wrapper -->
    <div class="slider flex transition-transform duration-700 ease-in-out" id="slider">
      <img src="assets/images/1.jpg" alt="Slide 1" class="min-w-full h-[calc(100vh-4rem)] object-contain bg-black">
      <img src="assets/images/2.jpg" alt="Slide 2" class="min-w-full h-[calc(100vh-4rem)] object-contain bg-black">
      <img src="assets/images/3.jpg" alt="Slide 3" class="min-w-full h-[calc(100vh-4rem)] object-contain bg-black">
      <img src="assets/images/4.jpg" alt="Slide 4" class="min-w-full h-[calc(100vh-4rem)] object-contain bg-black">
      <img src="assets/images/5.jpg" alt="Slide 5" class="min-w-full h-[calc(100vh-4rem)] object-contain bg-black">
      <img src="assets/images/6.jpg" alt="Slide 6" class="min-w-full h-[calc(100vh-4rem)] object-contain bg-black">
    </div>

    <!-- Left Button -->
    <button id="prevBtn" class="absolute top-1/2 left-5 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-3 rounded-full hover:bg-yellow-500 focus:outline-none">
      &#10094;
    </button>

    <!-- Right Button -->
    <button id="nextBtn" class="absolute top-1/2 right-5 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-3 rounded-full hover:bg-yellow-500 focus:outline-none">
      &#10095;
    </button>
  </div>
  </main>

  <!-- ✅ Footer -->
  <footer class="bg-black text-white text-center py-4">
    <p>© 2025 Sports Management System | All Rights Reserved</p>
  </footer>

  <!-- ✅ JavaScript for Slider -->
  <script>
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slider img');
    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    let counter = 0;

    function updateSlider() {
      slider.style.transform = `translateX(-${counter * 100}%)`;
    }

    nextBtn.addEventListener('click', () => {
      counter = (counter + 1) % slides.length;
      updateSlider();
    });

    prevBtn.addEventListener('click', () => {
      counter = (counter - 1 + slides.length) % slides.length;
      updateSlider();
    });

    // Auto slide every 4 seconds
    setInterval(() => {
      counter = (counter + 1) % slides.length;
      updateSlider();
    }, 4000);
  </script>

</body>
</html>
