<?php
include 'db.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>APIIT Sports Management System</title>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="flex flex-col min-h-screen">

  <!-- Header -->
  <header class="bg-teal-600 text-white text-center py-5">
    <h1 class="text-2xl md:text-3xl font-semibold">APIIT Sports Management System</h1>
  </header>

  <!-- Hero Section -->
  <main class="flex-grow relative">
    <div class="absolute inset-0 w-full h-full bg-cover bg-center" style="background-image: url('assets/images/hero.png');">
      <!-- Overlay -->
      <div class="absolute inset-0 bg-black bg-opacity-40 flex justify-center items-center">
        
        <!-- Card -->
        <div class="bg-white bg-opacity-10 backdrop-blur-md rounded-2xl p-8 w-80 sm:w-96 text-center shadow-lg">
          <!-- Logo (natural shape, no border or circle) -->
          <img src="assets/images/logo.png" alt="APIIT Logo" class="mx-auto mb-4 w-32 h-auto">
          
          <!-- Login Text -->
          <p class="text-white text-lg mb-4">Login using your APIIT email:</p>
          
          <!-- Login Button -->
          <a href="login.php" class="inline-flex items-center justify-center gap-2 bg-white text-teal-700 font-medium px-4 py-2 rounded-lg shadow hover:bg-teal-100 transition duration-300">
            <img src="https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg" alt="Microsoft Logo" class="w-5 h-5">
            Log in here
          </a>
          <!-- Add this under the existing Next button -->

<div class="mt-4 text-center">
  <a href="new_player_form.php" class="inline-block bg-green-600 text-white font-medium px-4 py-2 rounded-lg hover:bg-green-700 transition duration-300">
    New Player?
  </a>
</div>

        </div>

      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-teal-600 text-white text-center py-3">
    <p>@ 2025 APIIT IT Department. All rights reserved.</p>
  </footer>

</body>
</html>
