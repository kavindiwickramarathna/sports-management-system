<?php
// coach_account_attendance.php
include 'db.php';
session_start();

// Only allow logged-in coaches
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach') {
    header("Location: login.php");
    exit();
}

// Get logged-in coach info
$coachEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT user_id, username, profile_image FROM users WHERE email=? AND role='coach'");
$stmt->bind_param("s", $coachEmail);
$stmt->execute();
$result = $stmt->get_result();
$coach = $result->fetch_assoc();

if (!$coach) {
    echo "Coach not found!";
    exit();
}

$coach_id = $coach['user_id'];
$profileImage = $coach['profile_image'] ?: 'assets/images/default.png';

// Handle month/year filter
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Get attendance records for the logged-in coach filtered by month/year
$attendance_stmt = $conn->prepare("
    SELECT a.date, a.status, a.remarks, s.sport_name 
    FROM attendance a
    LEFT JOIN sports s ON a.sport_id = s.sport_id
    WHERE a.user_id=? AND MONTH(a.date)=? AND YEAR(a.date)=?
    ORDER BY a.date DESC
");
$attendance_stmt->bind_param("iii", $coach_id, $selected_month, $selected_year);
$attendance_stmt->execute();
$attendance_result = $attendance_stmt->get_result();

// Calculate summary stats
$total_sessions = $attendance_result->num_rows;
$total_present = 0;
$total_absent = 0;
foreach ($attendance_result as $row) {
    if (strtolower($row['status'] ?? '') === 'present') $total_present++;
    elseif (strtolower($row['status'] ?? '') === 'absent') $total_absent++;
}
$attendance_percentage = $total_sessions > 0 ? round(($total_present / $total_sessions) * 100, 2) : 0;
$attendance_result->data_seek(0);
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coach Attendance</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<style>
body { background-color: #eef2f7; padding-top: 80px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
nav { background: white; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 0.5rem 1.5rem; display: flex; justify-content: space-between; align-items: center; position: fixed; top:0; width:100%; z-index:50;}
nav a { margin-right: 1rem; text-decoration: none; color: black; font-weight: 500; }
.dropdown { position: relative; }
.dropdown-content { display: none; position: absolute; top: 100%; left: 0; background: white; min-width: 150px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); border-radius: 5px; }
.dropdown-content a { display: block; padding: 8px 12px; color: black; }
.dropdown:hover .dropdown-content { display: block; }
.profile-img { height: 40px; width: 40px; border-radius: 50%; }
table { width: 100%; border-collapse: collapse; background-color: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1);}
th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
th { background-color: teal; color: #fff; }
tr:hover { background-color: #f1f1f1; }
.present { color: green; font-weight: bold; }
.absent { color: red; font-weight: bold; }
.btn { padding: 10px 16px; background-color: teal; color: white; border-radius: 5px; text-decoration: none; margin-right: 10px; }
.btn:hover { background-color: #0d6466; }
</style>
</head>
<body>

<nav>
    <div style="display:flex; align-items:center;">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 mr-4">
        <a href="coach.php">Home</a>
        <a href="coach_dashboard.php">Dashboard</a>
        <a href="coach_calendar.php">Calendar</a>
        <a href="coach_events.php">Events</a>
    </div>
    <div class="dropdown">
        <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="Profile" class="profile-img">
        <div class="dropdown-content" style="right:0; left:auto;">
            <a href="coach_profile.php">Profile</a>
            <a href="coach_account_attendance.php">Attendance</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
</nav>

<div class="container mx-auto p-6 bg-white rounded shadow-md">
    <h2 class="text-2xl font-bold mb-4">Attendance for Coach <?php echo htmlspecialchars($coach['username']); ?></h2>

 
<div class="mb-4">
    <form method="GET" class="flex flex-wrap gap-4 items-center">
        <div>
            <label class="font-semibold">Month:</label>
            <select name="month" class="p-2 border rounded">
                <?php for($m=1;$m<=12;$m++): ?>
                <option value="<?php echo $m; ?>" <?php if($m==$selected_month) echo 'selected'; ?>><?php echo date('F', mktime(0,0,0,$m,1)); ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div>
            <label class="font-semibold">Year:</label>
            <select name="year" class="p-2 border rounded">
                <?php for($y=date('Y'); $y>=date('Y')-5;$y--): ?>
                <option value="<?php echo $y; ?>" <?php if($y==$selected_year) echo 'selected'; ?>><?php echo $y; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <button type="submit" class="bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-800">Filter</button>
    </form>
</div>

<div class="flex gap-4 mb-6 flex-wrap">
    <div class="bg-white p-4 rounded shadow text-center w-48">
        <h3 class="font-semibold">Total Sessions</h3>
        <p><?php echo $total_sessions; ?></p>
    </div>
    <div class="bg-white p-4 rounded shadow text-center w-48">
        <h3 class="font-semibold text-green-700">Present</h3>
        <p><?php echo $total_present; ?></p>
    </div>
    <div class="bg-white p-4 rounded shadow text-center w-48">
        <h3 class="font-semibold text-red-600">Absent</h3>
        <p><?php echo $total_absent; ?></p>
    </div>
    <div class="bg-white p-4 rounded shadow text-center w-48">
        <h3 class="font-semibold">Attendance %</h3>
        <p><?php echo $attendance_percentage; ?>%</p>
    </div>
</div>

<div class="mb-4">
    <a href="coach_attendance_download.php?month=<?php echo $selected_month; ?>&year=<?php echo $selected_year; ?>" class="btn">Download CSV</a>
    <button onclick="window.history.back();" class="btn">Go Back</button>
</div>

<table>
    <thead>
        <tr>
            <th>Date</th>
            <th>Sport</th>
            <th>Status</th>
            <th>Remarks</th>
        </tr>
    </thead>
    <tbody>
        <?php if($total_sessions > 0): ?>
            <?php while($row = $attendance_result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['date'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($row['sport_name'] ?? 'N/A'); ?></td>
                <td class="<?php echo strtolower($row['status'] ?? ''); ?>"><?php echo htmlspecialchars($row['status'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($row['remarks'] ?? ''); ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No attendance records found for this month.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
 

</div>
</body>
</html>
