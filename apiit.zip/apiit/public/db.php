<?php
$host = "localhost"; 
$port = 8889;             // MAMP default MySQL port
$username = "root";       // MAMP default username
$password = "root";       // MAMP default password
$database = "sports_management";

$conn = new mysqli($host, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
