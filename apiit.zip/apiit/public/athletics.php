<?php
include 'db.php';
$team_id = 7; // Change to dynamic if needed, e.g., via GET parameter

// Fetch team info
$teamStmt = $conn->prepare("SELECT * FROM teams WHERE team_id = ?");
$teamStmt->bind_param("i", $team_id);
$teamStmt->execute();
$teamResult = $teamStmt->get_result();
$team = $teamResult->fetch_assoc();

// Fetch coach info
$coachStmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$coachStmt->bind_param("i", $team['coach_id']);
$coachStmt->execute();
$coachResult = $coachStmt->get_result();
$coach = $coachResult->fetch_assoc();

// Fetch captain info
$captainStmt = $conn->prepare("SELECT * FROM users WHERE sport_id=? AND role='captain'");
$captainStmt->bind_param("i", $team['sport_id']);
$captainStmt->execute();
$captainResult = $captainStmt->get_result();
$captain = $captainResult->fetch_assoc();

// Fetch players for this team (excluding captain)
$playersStmt = $conn->prepare("SELECT * FROM users WHERE sport_id=? AND role='player'");
$playersStmt->bind_param("i", $team['sport_id']);
$playersStmt->execute();
$playersResult = $playersStmt->get_result();

// Handle player removal
if(isset($_POST['confirm_remove'])){
    $remove_id = $_POST['remove_id'];
    $delStmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
    $delStmt->bind_param("i", $remove_id);
    $delStmt->execute();
    header("Location: athletics.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>APIIT athletics Team</title>

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    .nav-item:hover { color: #facc15; }
    .active { color: #facc15; }
    .dropdown-content, .user-dropdown { display: none; position: absolute; background-color: white; min-width: 160px; box-shadow: 0px 4px 8px rgba(0,0,0,0.2); z-index: 50; }
    .dropdown-content a, .user-dropdown a { color: black; padding: 10px 16px; text-decoration: none; display: block; }
    .dropdown-content a:hover, .user-dropdown a:hover { background-color: #facc15; color: white; }
    .dropdown:hover .dropdown-content, .user-menu:hover .user-dropdown { display: block; }
    #addMemberBtn { width: 40px; height: 40px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 24px; cursor: pointer; margin-bottom: 10px; }
    .confirmation-box { display: none; position: absolute; background-color: white; padding: 10px; border-radius: 6px; box-shadow: 0 2px 6px rgba(0,0,0,0.2); top: 35px; right: 0; z-index: 30; text-align: center; }
    .confirmation-box button { margin: 0 5px; font-size: 16px; padding: 3px 8px; border-radius: 4px; cursor: pointer; }
    main, body { overflow: visible !important; }
  </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- Navbar -->
<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
    <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
    <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>
    <div class="dropdown relative">
      <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
      <div class="dropdown-content rounded-md">
        <a href="all.php">All Teams</a>
        <a href="coaches.php">Coaches</a>
        <a href="players.php">Player Search</a>
      </div>
    </div>
    <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
    <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
  </div>

  <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
    <span class="text-black">▼</span>
    <div class="user-dropdown rounded-md right-0">
      <a href="admin_profile.php">Profile</a>
      <a href="calendar.php">Calendar</a>
      <a href="messages.php">Messages</a>
      <a href="reports.php">Reports</a>
      <a href="logout.php">Logout</a>
    </div>
  </div>
</nav>

<!-- Main -->
<main class="flex-grow mt-24 px-10 pb-20">
  <h1 class="text-3xl font-bold text-gray-800 mb-4"><?php echo $team['team_name']; ?></h1>
  <h2 class="text-xl font-semibold text-gray-700 mb-2">Team Overview</h2>
  <hr class="border-gray-400 mb-6">

  <!-- Add Member Button -->
  <div class="flex items-start mb-6">
    <div id="addMemberBtn" class="bg-teal-500 text-white">+</div>
    <div id="addMemberText" class="ml-4 mt-2 px-3 py-1 bg-teal-500 text-white rounded hidden">
      <a href="add_member.php?team_id=<?php echo $team['team_id']; ?>">Add a Member</a>
    </div>
  </div>

  <!-- Coach Section -->
  <div class="flex flex-col items-center mt-4 relative group">
    <img src="<?php echo $coach['profile_image']; ?>" alt="Coach" class="h-32 w-32 rounded-full border-4 border-gray-300 object-cover cursor-pointer">
    <a href="bandara.php" class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white font-semibold text-sm rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300">
      View Profile
    </a>
    <p class="mt-4 text-lg font-bold text-gray-800">Coach Name: <?php echo $coach['username']; ?></p>
  </div>

  <!-- Players Section including Captain -->
  <div class="mt-12 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">

    <!-- Captain Card -->
    <?php if($captain): ?>
      <div class="bg-yellow-100 shadow-md rounded-lg p-4 flex flex-col items-center relative border-2 border-yellow-400">
        <img src="<?php echo $captain['profile_image']; ?>" alt="<?php echo $captain['username']; ?>" class="h-28 w-28 rounded-full object-cover mb-3">
        <h3 class="text-lg font-semibold text-gray-800"><?php echo $captain['username']; ?></h3>
        <p class="text-gray-600 mb-3">Role: Captain</p>
        <a href="player_profile.php?user_id=<?php echo $captain['user_id']; ?>" 
           class="bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600 transition">
           View
        </a>
      </div>
    <?php endif; ?>

    <!-- Loop through all players -->
    <?php while($player = $playersResult->fetch_assoc()): ?>
      <div class="bg-white shadow-md rounded-lg p-4 flex flex-col items-center relative">
        <img src="<?php echo $player['profile_image']; ?>" alt="<?php echo $player['username']; ?>" class="h-24 w-24 rounded-full object-cover mb-3">
        <h3 class="text-lg font-semibold text-gray-800"><?php echo $player['username']; ?></h3>
        <p class="text-gray-600 mb-3">Role: <?php echo $player['role']; ?></p>
        <a href="player_profile.php?user_id=<?php echo $player['user_id']; ?>" 
           class="bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600 transition">
           View
        </a>

        <div class="dots-btn absolute top-2 right-2 cursor-pointer text-lg font-bold">...</div>
        <div class="confirmation-box">
          <p>Remove this player?</p>
          <form method="post">
            <input type="hidden" name="remove_id" value="<?php echo $player['user_id']; ?>">
            <button type="submit" name="confirm_remove" class="confirm-yes text-white bg-teal-500">✔️</button>
          </form>
          <button class="confirm-no text-white bg-red-500">❌</button>
        </div>
      </div>
    <?php endwhile; ?>

    <div class="col-span-full text-center mt-6">
      <a href="athletic_attendance.php" class="text-teal-500 font-semibold hover:underline text-lg">View Team Attendance</a>
    </div>
  </div>
</main>

<script>
const addBtn = document.getElementById("addMemberBtn");
const addText = document.getElementById("addMemberText");

addBtn.addEventListener("click", () => { addText.classList.toggle("hidden"); });

document.querySelectorAll(".dots-btn").forEach(btn => {
  btn.addEventListener("click", (e) => {
    const confBox = btn.nextElementSibling;
    confBox.style.display = confBox.style.display === "block" ? "none" : "block";
    e.stopPropagation();
  });
});

document.querySelectorAll(".confirmation-box").forEach(box => {
  const yesBtn = box.querySelector(".confirm-yes");
  const noBtn = box.querySelector(".confirm-no");
  const card = box.closest(".bg-white");

  yesBtn.addEventListener("click", () => { card.remove(); });
  noBtn.addEventListener("click", () => { box.style.display = "none"; });
});

window.addEventListener("click", () => {
  document.querySelectorAll(".confirmation-box").forEach(box => box.style.display = "none");
});
</script>
</body>
</html>
