<?php
include 'db.php';

$userId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : 'profile';

if(!$userId) { echo "User not found"; exit(); }

// Fetch user details
$stmt = $conn->prepare("SELECT username, role, cb_number, profile_image FROM users WHERE user_id=? LIMIT 1");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if(!$user){ echo "User not found"; exit(); }

if($type === 'profile'){
    // Return only profile info
    echo "<div class='flex flex-col items-center'>";
    echo "<img src='".(!empty($user['profile_image']) ? $user['profile_image'] : 'assets/images/default_user.png')."' class='h-32 w-32 rounded-full mb-4'>";
    echo "<h2 class='text-xl font-semibold mb-1'>".htmlspecialchars($user['username'])."</h2>";
    echo "<p class='text-gray-600'>Role: ".ucfirst($user['role'])."</p>";
    echo "<p class='text-gray-600'>CB Number: ".htmlspecialchars($user['cb_number'])."</p>";
    echo "</div>";
} elseif($type === 'attendance'){
    // Fetch attendance from attendance table
    $attStmt = $conn->prepare("SELECT date, status FROM attendance WHERE user_id=? ORDER BY date DESC");
    $attStmt->bind_param("i", $userId);
    $attStmt->execute();
    $attResult = $attStmt->get_result();
    
    echo "<div class='max-h-64 overflow-y-auto'>";
    echo "<table class='w-full text-left border'>";
    echo "<tr><th class='px-2 py-1 border'>Date</th><th class='px-2 py-1 border'>Status</th></tr>";
    while($row = $attResult->fetch_assoc()){
        echo "<tr><td class='px-2 py-1 border'>".$row['date']."</td><td class='px-2 py-1 border'>".$row['status']."</td></tr>";
    }
    echo "</table></div>";

    $attStmt->close();
}
?>
