<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Account Help - APIIT Sports Management System</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex items-center justify-center bg-cover bg-center relative" style="background-image: url('assets/images/hero.png');">

  <!-- Dark overlay -->
  <div class="absolute inset-0 bg-black bg-opacity-60"></div>

  <!-- Card -->
  <div class="relative bg-white rounded-2xl p-8 w-80 sm:w-96 shadow-xl z-10">

    <!-- Logo -->
    <div class="flex flex-col items-start mb-6">
      <img src="assets/images/logo.png" alt="APIIT Logo" class="w-28 mb-4">
    </div>

    <!-- Title -->
    <h2 class="text-2xl font-semibold mb-6">Which type of account do you need help with?</h2>

    <!-- Account Options -->
    <div class="flex flex-col gap-4">

      <!-- Work/School Account -->
      <a href="work.php" class="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-200 transition duration-300 cursor-pointer">
        <img src="assets/images/work.png" alt="Work or School Account" class="w-10 h-10">
        <div class="flex flex-col">
          <span class="text-gray-900 font-medium">Work or School Account</span>
          <span class="text-gray-500 text-sm -mt-1">Created by your IT department</span>
        </div>
      </a>

    <!-- Back Button -->
    <div class="mt-6">
      <a href="login.php" class="inline-block bg-gray-200 text-black font-medium py-2 px-4 rounded-lg hover:bg-gray-500 transition duration-300">
        Back
      </a>
    </div>

  </div>

</body>
</html>
