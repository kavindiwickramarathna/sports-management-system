<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Overdue - Sports Management System</title>

  <!-- ✅ Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    /* Navigation dropdown styling */
    .nav-item:hover { color: #facc15; }
    .active { color: #facc15; }

    .dropdown-content, .user-dropdown {
      display: none;
      position: absolute;
      background-color: white;
      min-width: 160px;
      box-shadow: 0px 4px 8px rgba(0,0,0,0.2);
      z-index: 10;
    }

    .dropdown-content a, .user-dropdown a {
      color: black;
      padding: 10px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content a:hover, .user-dropdown a:hover {
      background-color: #facc15;
      color: white;
    }

    .dropdown:hover .dropdown-content,
    .user-menu:hover .user-dropdown {
      display: block;
    }

    .timeline-dropdown {
      display: none;
      position: absolute;
      background-color: white;
      border: 1px solid #000;
      min-width: 180px;
      z-index: 20;
      margin-top: 5px;
      border-radius: 6px;
    }

    .timeline-dropdown a {
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: black;
      padding: 8px 14px;
      text-decoration: none;
    }

    .timeline-dropdown a:hover {
      background-color: #f3f4f6;
    }

    .divider {
      border-top: 1px solid #ddd;
      margin: 4px 0;
    }
  </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

  <!-- ✅ Navigation Bar -->
  <nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
      <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">

      <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
      <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

      <div class="dropdown relative">
        <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
        <div class="dropdown-content rounded-md">
          <a href="all.php">All Teams</a>
          <a href="coaches.php">Coaches</a>
          <a href="players.php">Player Search</a>
        </div>
      </div>

      <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
      <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>

    <!-- Right side -->
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
      <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
      <span class="text-black">▼</span>
      <div class="user-dropdown rounded-md right-0">
        <a href="admin_profile.php">Profile</a>
        <a href="calendar.php">Calendar</a>
        <a href="messages.php">Messages</a>
        <a href="reports.php">Reports</a>
        <a href="logout.php">Logout</a>
      </div>
    </div>
  </nav>

  <!-- ✅ Dashboard Content -->
  <main class="flex-grow mt-24 px-10">
    <h1 class="text-3xl font-bold text-gray-800 mb-8">Dashboard</h1>

    <!-- ✅ Timeline Box -->
    <div class="bg-white shadow-md rounded-lg p-6 w-[95%] mx-auto">

      <h2 class="text-2xl font-semibold mb-4 text-gray-700">Timeline</h2>

      <div class="flex space-x-6 relative">
        <!-- All Button -->
        <div class="relative">
          <button id="allBtn" class="px-4 py-2 border border-black text-black bg-white rounded-md hover:bg-gray-100">
            All ▼
          </button>
          <div id="allDropdown" class="timeline-dropdown">
            <a href="dashboard.php" onclick="selectOption('all')">
              <span>All</span><span id="tick-all" class="hidden">✔️</span>
            </a>
            <a href="overdue.php" onclick="selectOption('overdue')">
              <span>Overdue</span><span id="tick-overdue" class="hidden">✔️</span>
            </a>
            <div class="divider"></div>
            <a href="7.php" onclick="selectOption('7days')">
              <span>Next 7 Days</span><span id="tick-7days" class="hidden">✔️</span>
            </a>
            <a href="30.php" onclick="selectOption('30days')">
              <span>Next 30 Days</span><span id="tick-30days" class="hidden">✔️</span>
            </a>
          </div>
        </div>

        <!-- Sort Button -->
        <div class="relative">
          <button id="sortBtn" class="px-4 py-2 border border-black text-black bg-white rounded-md hover:bg-gray-100">
            Sort by ▼
          </button>
          <div id="sortDropdown" class="timeline-dropdown">
            <a href="dashboard.php" onclick="selectSort('dates')">
              <span>Sort by Dates</span><span id="tick-dates" class="hidden">✔️</span>
            </a>
            <a href="sort.php" onclick="selectSort('team')">
              <span>Sort by Team</span><span id="tick-team" class="hidden">✔️</span>
            </a>
          </div>
        </div>
      </div>

      <!-- ✅ Centered Image & Text Section -->
      <div class="mt-8 border-t-2 border-gray-300 pt-10 pb-12 flex flex-col items-center justify-center">
        <img src="assets/images/overdue.png" alt="No Activities" class="h-32 w-32 mb-4">
        <p class="text-lg font-semibold text-gray-700">No activities require action</p>
      </div>

    </div>
    <!-- ✅ Recently Accessed Sports Section -->
<div class="bg-white shadow-md rounded-lg p-6 w-[95%] mx-auto mt-10">
  <h2 class="text-2xl font-semibold mb-6 text-gray-700">Recently Accessed Sports</h2>

  <!-- Cards Container -->
  <div id="sportsContainer" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    <!-- 8 Cards -->
    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center">
      <img src="assets/images/cricket.jpg" alt="Cricket" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Cricket</p>
    </div>

    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center">
      <img src="assets/images/football.jpg" alt="Football" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Football</p>
    </div>

    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center">
      <img src="assets/images/basketball.jpg" alt="Basketball" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Basketball</p>
    </div>

    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center">
      <img src="assets/images/swimming.jpg" alt="Swimming" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Swimming</p>
    </div>

    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
      <img src="assets/images/volleyball.jpg" alt="Volleyball" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Volleyball</p>
    </div>

    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
      <img src="assets/images/tennis.jpg" alt="Tennis" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Tennis</p>
    </div>

    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
      <img src="assets/images/hockey.jpg" alt="Hockey" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Hockey</p>
    </div>

    <div class="card bg-gray-50 rounded-lg shadow p-4 flex flex-col items-center hidden">
      <img src="assets/images/rugby.jpg" alt="Rugby" class="h-32 w-full object-cover rounded-md mb-3">
      <p class="font-semibold text-gray-700">Rugby</p>
    </div>
  </div>

  <!-- Navigation Buttons -->
  <div class="flex justify-center items-center mt-6 space-x-6">
    <button id="prevBtn" class="hidden bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300">←</button>
    <button id="nextBtn" class="bg-gray-200 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-300">→</button>
  </div>
</div>

<!-- ✅ JS to toggle cards -->
<script>
  const cards = document.querySelectorAll('.card');
  const nextBtn = document.getElementById('nextBtn');
  const prevBtn = document.getElementById('prevBtn');
  let showingFirstSet = true;

  nextBtn.addEventListener('click', () => {
    if (showingFirstSet) {
      cards.forEach((card, index) => {
        card.classList.toggle('hidden', index < 4);
      });
      nextBtn.classList.add('hidden');
      prevBtn.classList.remove('hidden');
      showingFirstSet = false;
    }
  });

  prevBtn.addEventListener('click', () => {
    if (!showingFirstSet) {
      cards.forEach((card, index) => {
        card.classList.toggle('hidden', index >= 4);
      });
      prevBtn.classList.add('hidden');
      nextBtn.classList.remove('hidden');
      showingFirstSet = true;
    }
  });
</script>

  </main>

  <!-- ✅ Footer -->
  <footer class="bg-black text-white text-center py-4">
    <p>© 2025 Sports Management System | All Rights Reserved</p>
  </footer>

  <!-- ✅ JavaScript -->
  <script>
    const allBtn = document.getElementById("allBtn");
    const sortBtn = document.getElementById("sortBtn");
    const allDropdown = document.getElementById("allDropdown");
    const sortDropdown = document.getElementById("sortDropdown");

    // Toggle dropdowns
    allBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      allDropdown.style.display = allDropdown.style.display === "block" ? "none" : "block";
      sortDropdown.style.display = "none";
    });

    sortBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      sortDropdown.style.display = sortDropdown.style.display === "block" ? "none" : "block";
      allDropdown.style.display = "none";
    });

    // Close dropdown when clicking outside
    window.addEventListener("click", () => {
      allDropdown.style.display = "none";
      sortDropdown.style.display = "none";
    });

    // ✅ Selection ticks
    function selectOption(option) {
      const options = ["all", "overdue", "7days", "30days"];
      options.forEach(id => document.getElementById(`tick-${id}`).classList.add("hidden"));
      document.getElementById(`tick-${option}`).classList.remove("hidden");
    }

    function selectSort(sort) {
      const sorts = ["dates", "team"];
      sorts.forEach(id => document.getElementById(`tick-${id}`).classList.add("hidden"));
      document.getElementById(`tick-${sort}`).classList.remove("hidden");
    }
  </script>

</body>
</html>
