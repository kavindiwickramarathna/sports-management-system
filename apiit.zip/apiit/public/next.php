<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IT Department Message</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex items-center justify-center bg-gray-100">

  <!-- Card -->
  <div class="bg-white rounded-2xl p-8 w-80 sm:w-96 shadow-xl text-center">

    <!-- Logo -->
    <div class="flex justify-center mb-6">
      <img src="assets/images/logo.png" alt="APIIT Logo" class="w-24 h-auto">
    </div>

    <!-- Message -->
    <h1 class="text-xl font-semibold text-gray-800 mb-3">
      IT Department Notification
    </h1>
    <p class="text-gray-700 mb-4">
      IT department will get back to you soon or send your response to
      <a href="#" id="emailLink" class="text-blue-600 hover:underline">
        it@apiit.lk
      </a>
    </p>

    <!-- OK Button -->
    <button 
      id="okButton"
      class="bg-blue-600 text-white font-medium py-2 px-6 rounded-lg hover:bg-blue-700 transition duration-300"
    >
      OK
    </button>
  </div>

  <!-- Success Popup -->
  <div id="popup" class="hidden fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
    <div class="bg-white rounded-xl p-6 text-center shadow-lg w-72">
      <!-- Green Tick -->
      <div class="flex justify-center mb-3">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
        </svg>
      </div>
      <p class="text-green-600 font-medium mb-4">
        Your response has been sent to IT department
      </p>
      <button 
        id="closePopup"
        class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition duration-300"
      >
        Close
      </button>
    </div>
  </div>

  <script>
    // Show popup when clicking the email link
    document.getElementById("emailLink").addEventListener("click", function(event) {
      event.preventDefault();
      document.getElementById("popup").classList.remove("hidden");
    });

    // Close popup
    document.getElementById("closePopup").addEventListener("click", function() {
      document.getElementById("popup").classList.add("hidden");
    });

    // Redirect to index.php when clicking OK
    document.getElementById("okButton").addEventListener("click", function() {
      window.location.href = "index.php";
    });
  </script>

</body
