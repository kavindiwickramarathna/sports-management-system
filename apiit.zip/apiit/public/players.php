<?php
include 'db.php';

$addPlayerError = "";
$addPlayerSuccess = "";

// Handle form submission for adding a new player
if (isset($_POST['add_player'])) {
    $playerName = trim($_POST['player_name']);
    $playerEmail = trim($_POST['player_email']);
    $playerPhone = trim($_POST['player_phone']) ?: "";
    $sportId = $_POST['sport_id'] ?: null;
    $role = $_POST['role'] ?? "player";
    $imageFile = "";

    $cbNumber = "player_" . time() . rand(100,999);
    $defaultPassword = password_hash("Player@123", PASSWORD_DEFAULT);
    $playedBefore = "no";

    if (isset($_FILES['player_image']) && $_FILES['player_image']['error'] == 0) {
        $uploadDir = "assets/images/";
        $imageFile = $uploadDir . basename($_FILES['player_image']['name']);
        move_uploaded_file($_FILES['player_image']['tmp_name'], $imageFile);
    }

    if ($playerName !== "" && $playerEmail !== "" && $sportId !== null) {
        $stmt = $conn->prepare("INSERT INTO users (cb_number, username, password, role, email, phone, sport_id, profile_image, played_before) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sssssssss", $cbNumber, $playerName, $defaultPassword, $role, $playerEmail, $playerPhone, $sportId, $imageFile, $playedBefore);
            if ($stmt->execute()) {
                $addPlayerSuccess = "Player added successfully!";
            } else {
                $addPlayerError = "Database error: " . $stmt->error;
            }
        } else {
            $addPlayerError = "Prepare statement error: " . $conn->error;
        }
    } else {
        $addPlayerError = "Please fill in all required fields.";
    }
}

$search = isset($_GET['search']) ? trim($_GET['search']) : "";
$sports = $conn->query("SELECT * FROM sports ORDER BY sport_id ASC");

function getImageFile($imagePath) {
    if (!empty($imagePath) && file_exists($imagePath)) return $imagePath;
    return "assets/images/default.jpg";
}
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Players - Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.nav-item:hover { color: #facc15; }
.active { color: #facc15; }
.dropdown-content, .user-dropdown { display: none; position: absolute; background-color: white; min-width: 160px; box-shadow: 0px 4px 8px rgba(0,0,0,0.2); z-index: 10; }
.dropdown-content a, .user-dropdown a { color: black; padding: 10px 16px; text-decoration: none; display: block; }
.dropdown-content a:hover, .user-dropdown a:hover { background-color: #facc15; color: white; }
.dropdown:hover .dropdown-content, .user-menu:hover .user-dropdown { display: block; }
.modal-overlay { position: fixed; inset: 0; display: flex; justify-content: center; align-items: center; background-color: rgba(0,0,0,0.5); z-index: 50; }
</style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">

<!-- Navigation Bar -->
<nav class="bg-white shadow-md flex justify-between items-center px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="admin.php" class="nav-item font-semibold text-black hover:text-yellow-400">Home</a>
        <a href="dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400">Dashboard</a>

        <div class="dropdown relative">
            <button class="nav-item font-semibold text-black hover:text-yellow-400">Teams ▼</button>
            <div class="dropdown-content rounded-md">
                <a href="all.php">All Teams</a>
                <a href="coaches.php">Coaches</a>
                <a href="players.php">Player Search</a>
            </div>
        </div>

        <a href="budget.php" class="nav-item font-semibold text-black hover:text-yellow-400">Budget</a>
          <a href="admin_events.php" class="nav-item font-semibold text-black hover:text-yellow-400">Events</a>
        <a href="calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400">Calendar</a>
    </div>

    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="assets/images/vithara.png" alt="User Profile" class="h-10 w-10 rounded-full border border-gray-400" onclick="window.location.href='admin_profile.php'">
        <span class="text-black">▼</span>
        <div class="user-dropdown absolute right-0 hidden bg-white shadow-md rounded-md mt-2 w-48 py-2">
            <a href="admin_profile.php">Profile</a>
            <a href="calendar.php">Calendar</a>
          
            <a href="logout.php">Logout</a>
        </div>
    </div>
</nav>

<main class="flex-grow mt-24 px-10 pb-20">
<h1 class="text-3xl font-bold text-gray-800 mb-4">Players</h1>

<?php if($addPlayerSuccess) echo "<p class='text-green-600 font-semibold mb-4'>$addPlayerSuccess</p>"; ?>

<?php if($addPlayerError) echo "<p class='text-red-600 font-semibold mb-4'>$addPlayerError</p>"; ?>

<form method="GET" class="flex flex-wrap items-center gap-4 mb-8">
    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by CB number or name..." class="bg-white border border-black rounded-md px-4 py-2 w-64 focus:outline-none" />
    <button class="bg-gray-800 text-white px-4 py-2 rounded-md">Search</button>
</form>

<?php
if ($sports->num_rows > 0) {
    while ($sport = $sports->fetch_assoc()) {
        $sportId = $sport['sport_id'];
        $sportName = $sport['sport_name'];
        echo "<h2 class='text-2xl font-semibold mt-8 mb-4'>$sportName</h2>";
        echo "<hr class='mb-4'>";
        echo "<div class='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 justify-items-center'>";
        
        $query = "SELECT * FROM users WHERE sport_id=? AND (role='player' OR role='captain')";
        if ($search !== "") {
            $query .= " AND (username LIKE ? OR cb_number LIKE ?)";
            $stmt = $conn->prepare($query);
            $likeSearch = "%$search%";
            $stmt->bind_param("iss", $sportId, $likeSearch, $likeSearch);
        } else {
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $sportId);
        }

        $stmt->execute();
        $players = $stmt->get_result();

        if ($players->num_rows > 0) {
            while ($player = $players->fetch_assoc()) {
                $imgFile = getImageFile($player['profile_image']);
                $user_id = $player['user_id'];

                $cbNumber = $player['cb_number'];
                $highlightedCB = $cbNumber;
                if ($search !== "") {
                    $pos = stripos($cbNumber, $search);
                    if ($pos !== false) {
                        $highlightedCB = substr($cbNumber, 0, $pos)
                                       . "<span class='bg-yellow-300'>{$search}</span>"
                                       . substr($cbNumber, $pos + strlen($search));
                    }
                }

                /* -------------------------
                   CAPTAIN HIGHLIGHT ADDED
                -------------------------- */
                $cardBg = ($player['role'] === 'captain')
                    ? "bg-yellow-200 border-2 border-yellow-500"
                    : "bg-white border border-gray-200";

                echo "<a href='player_details.php?user_id=$user_id' class='player-card {$cardBg} rounded-lg shadow-md p-3 w-60 hover:shadow-lg transition text-center'>";
                echo "<img src='$imgFile' class='rounded-md mb-2 w-full h-40 object-contain bg-gray-100 mx-auto'>";
                echo "<h3 class='text-lg font-bold text-gray-900'>{$player['username']}</h3>";
                echo "<p class='text-gray-600 text-sm'>{$player['role']}</p>";
                echo "<p class='text-gray-600 text-sm'>{$highlightedCB}</p>";
                echo "<p class='text-gray-600 text-sm'>{$player['email']}</p>";
                echo "<p class='text-gray-600 text-sm'>{$player['phone']}</p>";
                echo "</a>";
            }
        } else {
            echo "<p class='text-center text-red-500 col-span-4'>No players found</p>";
        }
        echo "</div>";
    }
}
?>

</main>

<div class="fixed bottom-6 right-6">
  <button id="addPlayerBtn" class="bg-teal-800 text-white text-3xl rounded-full w-14 h-14 hover:bg-teal-700">+</button>
</div>

<div id="addPlayerModal" class="modal-overlay hidden">
  <div class="bg-white p-6 rounded-md shadow-lg w-96">
    <h2 class="text-xl font-semibold mb-4">Add Player</h2>
    <form method="POST" enctype="multipart/form-data" class="flex flex-col gap-4">
      <input type="text" name="player_name" placeholder="Player Name" class="border px-3 py-2 rounded-md" required>
      <input type="text" name="player_email" placeholder="Player Email" class="border px-3 py-2 rounded-md" required>
      <input type="text" name="player_phone" placeholder="Phone Number" class="border px-3 py-2 rounded-md">
      <select name="sport_id" class="border px-3 py-2 rounded-md" required>
        <option value="">Select Sport</option>
        <?php
        $sportsForModal = $conn->query("SELECT * FROM sports");
        while ($sportModal = $sportsForModal->fetch_assoc()) {
            echo "<option value='".$sportModal['sport_id']."'>".$sportModal['sport_name']."</option>";
        }
        ?>
      </select>
      <select name="role" class="border px-3 py-2 rounded-md" required>
        <option value="player">Player</option>
        <option value="captain">Captain</option>
      </select>
      <input type="file" name="player_image" accept="image/*" class="border px-3 py-2 rounded-md">
      <div class="flex justify-end gap-4">
        <button type="submit" name="add_player" class="bg-teal-800 text-white px-4 py-2 rounded-md hover:bg-teal-700">Add</button>
        <button type="button" id="cancelAddPlayer" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-400">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
const addBtn = document.getElementById("addPlayerBtn");
const addModal = document.getElementById("addPlayerModal");
const cancelBtn = document.getElementById("cancelAddPlayer");

addBtn.addEventListener("click", () => addModal.classList.remove("hidden"));
cancelBtn.addEventListener("click", () => addModal.classList.add("hidden"));
addModal.addEventListener("click", (e) => { if(e.target===addModal) addModal.classList.add("hidden"); });
</script>

</body>
</html>
