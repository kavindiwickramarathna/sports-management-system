<?php
include 'db.php';

$field = $_POST['field'];
$value = $_POST['value'];

$allowed_fields = ['cb_number','username','email'];
if(!in_array($field, $allowed_fields)){
    echo json_encode(['available'=>false]);
    exit;
}

// Safe query without using ? for column names
if ($field === 'cb_number') {
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE cb_number=?");
} elseif ($field === 'username') {
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username=?");
} else { // email
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email=?");
}

$stmt->bind_param("s", $value);
$stmt->execute();
$stmt->store_result();

echo json_encode(['available'=> $stmt->num_rows === 0]);
$stmt->close();
?>
