<?php
include 'db.php';
session_start();

// Only allow captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$captain = $stmt->get_result()->fetch_assoc();
$profileImage = $captain['profile_image'] ?? 'assets/images/default_profile.png';
$message = "";

// Automatically mark past events as expired
$today = date('Y-m-d');
$updateExpired = $conn->prepare("UPDATE events SET status='expired' WHERE event_date < ? AND status NOT IN ('expired')");
$updateExpired->bind_param("s", $today);
$updateExpired->execute();

// Handle captain response
if(isset($_POST['response'])){
    $event_id = $_POST['event_id'];
    $response = $_POST['response'];
    $player_id = $captain['user_id'];

    $stmtCheck = $conn->prepare("SELECT * FROM event_participation WHERE event_id=? AND player_id=?");
    $stmtCheck->bind_param("ii",$event_id,$player_id);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if($resultCheck->num_rows > 0){
        if($response === 'Remove'){
            $stmtDel = $conn->prepare("DELETE FROM event_participation WHERE event_id=? AND player_id=?");
            $stmtDel->bind_param("ii",$event_id,$player_id);
            $stmtDel->execute();
        } else {
            $stmtUpd = $conn->prepare("UPDATE event_participation SET status=? WHERE event_id=? AND player_id=?");
            $stmtUpd->bind_param("sii",$response,$event_id,$player_id);
            $stmtUpd->execute();
        }
    } else {
        if($response !== 'Remove'){
            $stmtIns = $conn->prepare("INSERT INTO event_participation (event_id, player_id, status) VALUES (?,?,?)");
            $stmtIns->bind_param("iis",$event_id,$player_id,$response);
            $stmtIns->execute();
        }
    }
}

// Handle Add Event
if(isset($_POST['add_event'])){
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $description = $_POST['description'];

    $stmtAdd = $conn->prepare("INSERT INTO events (sport_id, coach_id, captain_id, event_name, event_date, description, status) VALUES (?,?,?,?,?,?,?)");
    $coach_id = NULL;
    $status = "pending";
    $stmtAdd->bind_param("iiissss", $captain['sport_id'], $coach_id, $captain['user_id'], $event_name, $event_date, $description, $status);
    
    if($stmtAdd->execute()){
        $message = "Event added successfully!";
    } else {
        $message = "Failed to add event.";
    }
}

// Handle delete event
if(isset($_POST['delete_event'])){
    $deleteEventId = $_POST['delete_event_id'];

    $stmtCheck = $conn->prepare("SELECT event_date, status FROM events WHERE event_id=?");
    $stmtCheck->bind_param("i", $deleteEventId);
    $stmtCheck->execute();
    $eventData = $stmtCheck->get_result()->fetch_assoc();
    $eventDate = $eventData['event_date'];
    $eventStatus = $eventData['status'];

    $stmtRespCheck = $conn->prepare("SELECT COUNT(*) AS cnt FROM event_participation WHERE event_id=?");
    $stmtRespCheck->bind_param("i", $deleteEventId);
    $stmtRespCheck->execute();
    $responseCount = $stmtRespCheck->get_result()->fetch_assoc()['cnt'];

    // Only allow delete if event is pending, not expired, and has no responses
    if($eventStatus === 'pending' && strtotime($eventDate) >= strtotime($today) && $responseCount == 0){
        $stmtDel = $conn->prepare("DELETE FROM events WHERE event_id=?");
        $stmtDel->bind_param("i", $deleteEventId);
        if($stmtDel->execute()){
            $message = "Event deleted successfully!";
        } else {
            $message = "Failed to delete event.";
        }
    } else {
        $message = "Cannot delete this event (must be pending, not expired, and have no responses).";
    }
}

// Fetch captain added events
$stmtCaptainEvents = $conn->prepare("SELECT * FROM events WHERE sport_id=? AND captain_id=? ORDER BY event_date DESC");
$stmtCaptainEvents->bind_param("ii", $captain['sport_id'], $captain['user_id']);
$stmtCaptainEvents->execute();
$captainEvents = $stmtCaptainEvents->get_result();

// Fetch upcoming events **approved only**
$stmt = $conn->prepare("SELECT * FROM events WHERE sport_id=? AND status='approved' ORDER BY event_date ASC");
$stmt->bind_param("i", $captain['sport_id']);
$stmt->execute();
$events = $stmt->get_result();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Captain Events</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 pt-40 min-h-screen">

<!-- Navigation Bar -->
 
    <!-- Navigation Bar -->
<nav class="bg-white shadow-md flex justify-between items-center px-6 sm:px-8 py-3 fixed w-full z-20 top-0">
    <div class="flex items-center space-x-6">
        <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14 lg:h-16 lg:w-16">
        <a href="captain.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Home</a>
        <a href="captain_dashboard.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>

        <!-- My Team Dropdown -->
        <div class="relative">
            <button id="myTeamBtn" class="nav-item font-semibold text-black hover:text-yellow-400 transition flex items-center">
                My Team
                <svg class="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                </svg>
            </button>
            <div id="myTeamDropdown" class="absolute left-0 mt-2 w-48 bg-white shadow-md rounded-md py-2 hidden z-10">
                <a href="team_overview.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Team Overview</a>
                <a href="captain_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
                <a href="captain_budget.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Budget Requests</a>
                <a href="shop_request.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Jersey Request</a>
            </div>
        </div>

        <a href="captain_events.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Events</a>
        <a href="captain_calendar.php" class="nav-item font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
    </div>

    <!-- Right side: User menu -->
    <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
        <img src="<?php echo htmlspecialchars($profileImage); ?>" 
             alt="User Profile" 
             class="h-10 w-10 rounded-full border border-gray-400">
        <span class="text-black select-none">▼</span>
        <div id="userDropdown" class="absolute right-0 hidden bg-white shadow-md rounded-md mt-12 w-48 py-2 z-50">
    <a href="captain_profile.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
    <a href="captain_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
    <a href="captain_account_attendance.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Attendance</a>
    <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
</div>

    </div>
</nav>

<!-- Dropdown JS -->
<script>
    // My Team Dropdown
    const myTeamBtn = document.getElementById('myTeamBtn');
    const myTeamDropdown = document.getElementById('myTeamDropdown');

    myTeamBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        myTeamDropdown.classList.toggle('hidden');
    });

    // User Menu Dropdown
    const userMenu = document.querySelector('.user-menu');
    const userDropdown = document.getElementById('userDropdown');

    userMenu.addEventListener('click', (e) => {
        e.stopPropagation();
        userDropdown.classList.toggle('hidden');
    });

    // Close dropdowns if clicking outside
    window.addEventListener('click', () => {
        myTeamDropdown.classList.add('hidden');
        userDropdown.classList.add('hidden');
    });
</script>

<div class="max-w-4xl mx-auto p-6">
<?php if($message): ?>
    <div class="mb-4 p-3 bg-blue-100 text-blue-700 rounded"><?= $message ?></div>
<?php endif; ?>

<h1 class="text-3xl font-bold mb-4">Add New Event</h1>
<form method="POST" class="bg-white p-6 rounded shadow-md border-2 border-blue-200 mb-8">
    <input type="text" name="event_name" placeholder="Event Name" required class="w-full border p-2 rounded mb-4">
    <input type="date" name="event_date" required class="w-full border p-2 rounded mb-4">
    <textarea name="description" placeholder="Description" required class="w-full border p-2 rounded mb-4"></textarea>
    <button type="submit" name="add_event" class="w-full bg-teal-700 text-white p-3 rounded hover:bg-teal-900">Add Event</button>
</form>

<!-- Events Added by You -->

<h2 class="text-2xl font-bold mb-2">Events Added by You</h2>

<?php if(isset($captainEvents) && $captainEvents && $captainEvents->num_rows>0): ?>

<div class="overflow-x-auto bg-white rounded-lg shadow-md mb-6">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-teal-100">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Event Name</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Description</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-teal-700 uppercase tracking-wider">Action</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <?php while($ce = $captainEvents->fetch_assoc()): ?>
            <?php
                $isExpired = $ce['status'] == 'expired';
                $stmtResp = $conn->prepare("SELECT COUNT(*) AS cnt FROM event_participation WHERE event_id=?");
                $stmtResp->bind_param("i", $ce['event_id']);
                $stmtResp->execute();
                $hasResponses = $stmtResp->get_result()->fetch_assoc()['cnt'] > 0;
            ?>
            <tr class="<?= $isExpired ? 'bg-red-100' : 'hover:bg-gray-100' ?>">
                <td class="px-6 py-4"><?= htmlspecialchars($ce['event_name']) ?></td>
                <td class="px-6 py-4"><?= htmlspecialchars($ce['event_date']) ?></td>
                <td class="px-6 py-4"><?= htmlspecialchars(ucfirst($ce['status'])) ?></td>
                <td class="px-6 py-4"><?= htmlspecialchars($ce['description']) ?></td>
                <td class="px-6 py-4">
                    <?php if($ce['status']=='pending' && !$hasResponses && !$isExpired): ?>
                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this event?');">
                            <input type="hidden" name="delete_event_id" value="<?= $ce['event_id'] ?>">
                            <button type="submit" name="delete_event" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-800">Delete</button>
                        </form>
                    <?php else: ?>
                        <span class="text-gray-400 italic">Cannot Delete</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<?php else: ?>
    <p class="text-gray-500 italic">No events added yet.</p>
<?php endif; ?>

<!-- Upcoming Approved Events -->

<button id="toggleUpcoming" class="bg-yellow-500 text-white px-3 py-1 rounded mb-4 hover:bg-yellow-700">Hide/Show Upcoming Events</button>

<div id="upcomingEvents">
    <?php if($events && $events->num_rows > 0): ?>
        <?php while($event = $events->fetch_assoc()): ?>
        <?php $isExpired = $event['status']=='expired'; ?>
        <div class="mb-8 bg-white p-4 rounded shadow <?= $isExpired ? 'bg-red-100' : '' ?>">
            <h2 class="text-2xl font-bold mb-2"><?= htmlspecialchars($event['event_name']) ?> - <?= $event['event_date'] ?> (<?= ucfirst($event['status']) ?>)</h2>
            <p class="mb-2"><?= htmlspecialchars($event['description']) ?></p>

 
        <form method="POST" class="mb-4 flex space-x-2">
            <input type="hidden" name="event_id" value="<?= $event['event_id'] ?>">
            <button type="submit" name="response" value="Yes" class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-800" <?= $isExpired ? 'disabled class="opacity-50 cursor-not-allowed"' : '' ?>>Yes</button>
            <button type="submit" name="response" value="No" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-800" <?= $isExpired ? 'disabled class="opacity-50 cursor-not-allowed"' : '' ?>>No</button>
            <button type="submit" name="response" value="Remove" class="bg-gray-600 text-white px-3 py-1 rounded hover:bg-gray-800">Remove</button>
        </form>

        <table class="min-w-full bg-gray-50 border rounded overflow-hidden">
            <thead class="bg-gray-200">
                <tr>
                    <th class="px-4 py-2 text-left">Player Name</th>
                    <th class="px-4 py-2 text-left">Response</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmtPart = $conn->prepare("SELECT u.username, ep.status, ep.player_id 
                                            FROM event_participation ep
                                            JOIN users u ON ep.player_id = u.user_id
                                            WHERE ep.event_id=? ORDER BY u.username ASC");
                $stmtPart->bind_param("i",$event['event_id']);
                $stmtPart->execute();
                $participations = $stmtPart->get_result();
                while($p = $participations->fetch_assoc()):
                    $highlight = ($p['player_id'] == $captain['user_id']) ? 'bg-yellow-200 font-semibold' : (($p['status']=='Yes') ? 'bg-green-100' : 'bg-red-100');
                ?>
                <tr class="<?= $highlight ?>">
                    <td class="px-4 py-2"><?= htmlspecialchars($p['username']) ?></td>
                    <td class="px-4 py-2"><?= htmlspecialchars($p['status']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php endwhile; ?>
<?php else: ?>
    <p class="text-gray-500 italic">No upcoming approved events.</p>
<?php endif; ?>
 

</div>

<script>
const toggleBtn = document.getElementById('toggleUpcoming');
const upcomingDiv = document.getElementById('upcomingEvents');
toggleBtn.addEventListener('click', () => {
    upcomingDiv.classList.toggle('hidden');
});
</script>

</div>
</body>
</html>
