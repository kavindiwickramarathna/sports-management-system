<?php

$error = "";
$input = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input = trim($_POST["email_or_username"]);

    // ✅ Updated Email Pattern: cb0 + 5 digits + @coach.apiit.lk or @admin.apiit.lk
    $emailPattern = "/^cb0\d{5}@(coach|admin)\.apiit\.lk$/";

    // ✅ Username pattern (unchanged)
    $usernamePattern = "/^cb0\d{5}$/";

    // ✅ Cancel button works regardless of input or validation
    if (isset($_POST['cancel'])) {
        header("Location: account.php");
        exit();
    }

    // ✅ Next button validates input before redirect
    if (isset($_POST['next'])) {
        if (!preg_match($emailPattern, $input) && !preg_match($usernamePattern, $input)) {
            $error = "Please enter a valid APIIT email (cb012345@coach.apiit.lk or cb012345@admin.apiit.lk) or username (cb012345)";
        } else {
            // Valid input → redirect to next.php
            header("Location: next.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Work Account Recovery</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex items-center justify-center bg-gray-100">

  <div class="bg-white rounded-2xl p-8 w-80 sm:w-96 shadow-xl">

    <!-- Logo -->
    <div class="flex justify-center mb-6">
      <img src="https://upload.wikimedia.org/wikipedia/commons/4/44/Microsoft_logo.svg" alt="Microsoft Logo" class="w-20 h-auto">
    </div>

    <h1 class="text-2xl font-bold text-center mb-4">Get back into your account</h1>
    <h2 class="text-lg text-center text-gray-700 mb-2">Who are you?</h2>

    <p class="text-gray-600 text-center mb-4">
      To recover your account, begin by entering your email or username
    </p>

    <form method="POST" action="">
      <label for="email_or_username" class="block text-gray-700 mb-2">Email or Username</label>
      <input
        type="text"
        name="email_or_username"
        id="email_or_username"
        placeholder="cb012345@coach.apiit.lk / cb012345@admin.apiit.lk / cb012345"
        value="<?php echo htmlspecialchars($input); ?>"
        class="w-full border border-gray-300 rounded-lg px-3 py-2 mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >

      <?php if ($error): ?>
        <p class="text-red-600 text-sm mb-2"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>

      <div class="flex justify-between mt-4 gap-4">
        <button type="submit" name="cancel" class="flex-1 bg-gray-400 text-white py-2 rounded-lg hover:bg-gray-500 transition duration-300">
          Cancel
        </button>
        <button type="submit" name="next" class="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition duration-300">
          Next
        </button>
      </div>
    </form>

  </div>

</body>
</html>
