<?php
include 'db.php';
session_start();

// Only allow logged-in coaches
if(!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'coach'){
    header("Location: login.php");
    exit();
}

// Get logged-in coach info
$coachEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND role='coach' LIMIT 1");
$stmt->bind_param("s", $coachEmail);
$stmt->execute();
$coachResult = $stmt->get_result();
$coach = $coachResult->fetch_assoc();
$stmt->close();

$coachUserId = (int)$coach['user_id'];
$coachSportId = (int)$coach['sport_id'];
$profileImage = !empty($coach['profile_image']) ? $coach['profile_image'] : 'assets/images/default_user.png';

// Fetch the captain for this sport
$captainStmt = $conn->prepare("SELECT user_id FROM users WHERE role='captain' AND sport_id=? LIMIT 1");
$captainStmt->bind_param("i", $coachSportId);
$captainStmt->execute();
$captainResult = $captainStmt->get_result();
$captain = $captainResult->fetch_assoc();
$captainStmt->close();

$captainId = $captain ? (int)$captain['user_id'] : 0;

// Handle form submission for adding event
if(isset($_POST['add_event'])){
    $eventName = $_POST['event_name'];
    $eventDate = $_POST['event_date'];
    $eventDesc = $_POST['event_desc'];

    $insertEvent = $conn->prepare("
        INSERT INTO events (sport_id, coach_id, captain_id, event_name, event_date, status, description)
        VALUES (?, ?, ?, ?, ?, 'pending', ?)
    ");
    $insertEvent->bind_param("iiisss", $coachSportId, $coachUserId, $captainId, $eventName, $eventDate, $eventDesc);
    $insertEvent->execute();
}

// Handle event deletion
if(isset($_GET['delete_event'])){
    $deleteId = (int)$_GET['delete_event'];
    $deleteStmt = $conn->prepare("DELETE FROM events WHERE event_id=? AND coach_id=?");
    $deleteStmt->bind_param("ii", $deleteId, $coachUserId);
    $deleteStmt->execute();
    $deleteStmt->close();
    header("Location: coach_events.php");
    exit();
}

// Fetch existing events
$eventsStmt = $conn->prepare("SELECT * FROM events WHERE coach_id=? AND sport_id=? ORDER BY event_date DESC");
$eventsStmt->bind_param("ii", $coachUserId, $coachSportId);
$eventsStmt->execute();
$eventsResult = $eventsStmt->get_result();
$events = $eventsResult->fetch_all(MYSQLI_ASSOC);
$eventsStmt->close();

// Fetch existing sessions
$sessionsStmt = $conn->prepare("SELECT * FROM sessions WHERE coach_id=? AND sport_id=? ORDER BY session_date DESC, session_time DESC");
$sessionsStmt->bind_param("ii", $coachUserId, $coachSportId);
$sessionsStmt->execute();
$sessionsResult = $sessionsStmt->get_result();
$sessions = $sessionsResult->fetch_all(MYSQLI_ASSOC);
$sessionsStmt->close();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coach Events & Sessions</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<!-- Navigation Bar -->

<nav class="bg-white shadow-md fixed w-full top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex items-center space-x-6">
                <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10 sm:h-12 sm:w-12 md:h-14 md:w-14">
                <a href="coach.php" class="font-semibold text-black hover:text-yellow-400 transition">Home</a>
                <a href="coach_dashboard.php" class="font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>
                <div class="relative">
                    <button id="teamBtn" class="font-semibold text-black hover:text-yellow-400 flex items-center gap-1">
                        Team ▼
                    </button>
                    <div id="teamDropdown" class="absolute left-0 mt-2 w-44 bg-white rounded-md shadow-lg hidden">
                        <a href="coach_team.php" class="block px-4 py-2 text-black hover:bg-yellow-100">My Team</a>
                    </div>
                </div>
                <a href="coach_events.php" class="font-semibold text-black hover:text-yellow-400 transition">Events</a>
                <a href="coach_calendar.php" class="font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
            </div>
            <div class="relative">
                <button id="userBtn" class="flex items-center gap-2 focus:outline-none">
                    <img src="<?php echo htmlspecialchars($profileImage); ?>" alt="Profile" class="h-10 w-10 rounded-full border border-gray-400">
                    <span class="text-black select-none">▼</span>
                </button>
                <div id="userDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg hidden">
                    <a href="coach_profile.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Profile</a>
                    <a href="coach_calendar.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Calendar</a>
                    <a href="coach_messages.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Messages</a>
                    <a href="coach_reports.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Reports</a>
                    <a href="logout.php" class="block px-4 py-2 text-black hover:bg-yellow-100">Logout</a>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="pt-20 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-2xl font-bold mb-6">Events & Sessions</h1>

 
<!-- Add Event Form -->
<div class="bg-white shadow-md rounded p-6 mb-6">
    <h2 class="text-xl font-semibold mb-4">Add New Event</h2>
    <form method="POST">
        <input type="text" name="event_name" placeholder="Event Name" class="w-full p-2 mb-2 border rounded" required>
        <input type="date" name="event_date" class="w-full p-2 mb-2 border rounded" required>
        <textarea name="event_desc" placeholder="Description" class="w-full p-2 mb-2 border rounded"></textarea>
        <button type="submit" name="add_event" class="bg-teal-600 text-white px-4 py-2 rounded hover:bg-teal-800">Add Event</button>
    </form>
</div>

<!-- Existing Events Table -->
<div class="bg-white shadow-md rounded p-6 mb-6">
    <h2 class="text-xl font-semibold mb-4">My Events</h2>
    <table class="w-full table-auto border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border p-2">Event Name</th>
                <th class="border p-2">Date</th>
                <th class="border p-2">Status</th>
                <th class="border p-2">Description</th>
                <th class="border p-2">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($events as $event): ?>
            <tr>
                <td class="border p-2"><?php echo htmlspecialchars($event['event_name']); ?></td>
                <td class="border p-2"><?php echo htmlspecialchars($event['event_date']); ?></td>
                <td class="border p-2"><?php echo htmlspecialchars($event['status']); ?></td>
                <td class="border p-2"><?php echo htmlspecialchars($event['description']); ?></td>
                <td class="border p-2">
                    <a href="coach_events.php?delete_event=<?php echo $event['event_id']; ?>" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-800" onclick="return confirm('Are you sure you want to delete this event?');">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
 

</div>

<script>
// Dropdown toggles
const teamBtn = document.getElementById('teamBtn');
const teamDropdown = document.getElementById('teamDropdown');
teamBtn.addEventListener('click', e => { e.stopPropagation(); teamDropdown.classList.toggle('hidden'); });

const userBtn = document.getElementById('userBtn');
const userDropdown = document.getElementById('userDropdown');
userBtn.addEventListener('click', e => { e.stopPropagation(); userDropdown.classList.toggle('hidden'); });

window.addEventListener('click', () => { teamDropdown.classList.add('hidden'); userDropdown.classList.add('hidden'); });
teamDropdown.addEventListener('click', e => e.stopPropagation());
userDropdown.addEventListener('click', e => e.stopPropagation());
</script>

</body>
</html>
