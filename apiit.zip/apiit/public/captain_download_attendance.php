<?php
include "db.php";
session_start();

// Only allow logged-in captains
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'captain') {
    header("Location: login.php");
    exit();
}

// Get logged-in captain info
$captainEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT user_id, username FROM users WHERE email=? AND role='captain' LIMIT 1");
$stmt->bind_param("s", $captainEmail);
$stmt->execute();
$result = $stmt->get_result();
$captain = $result->fetch_assoc();

if (!$captain) {
    die("Captain not found!");
}

$captain_id = $captain['user_id'];

// Get month/year from query
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : date('m');
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Fetch attendance records
$attendance_stmt = $conn->prepare("
    SELECT a.date, s.sport_name, a.status, a.remarks
    FROM attendance a
    LEFT JOIN sports s ON a.sport_id = s.sport_id
    WHERE a.user_id=? AND MONTH(a.date)=? AND YEAR(a.date)=?
    ORDER BY a.date DESC
");
$attendance_stmt->bind_param("iii", $captain_id, $selected_month, $selected_year);
$attendance_stmt->execute();
$attendance_result = $attendance_stmt->get_result();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=captain_attendance_'.$selected_month.'_'.$selected_year.'.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['Date', 'Sport', 'Status', 'Remarks']);

while ($row = $attendance_result->fetch_assoc()) {
    fputcsv($output, [$row['date'], $row['sport_name'], $row['status'], $row['remarks']]);
}

fclose($output);
exit();
