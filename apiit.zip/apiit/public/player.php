<?php
include 'db.php';
session_start();

// Only allow logged-in players
if (!isset($_SESSION['entered_email']) || $_SESSION['user_role'] !== 'player') {
    header("Location: login.php");
    exit();
}

// Get logged-in player info
$playerEmail = $_SESSION['entered_email'];
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $playerEmail);
$stmt->execute();
$player = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Map sport_id to theme image
$sportThemes = [
    1 => 'assets/images/hero.png',       // Cricket
    2 => 'assets/images/football.jpg',   // Football
    3 => 'assets/images/rugby.jpg',      // Rugby
    4 => 'assets/images/futsal.jpg',     // Futsal
    5 => 'assets/images/swimming.jpg',   // Swimming
    6 => 'assets/images/netball.JPG',    // Netball
    7 => 'assets/images/athletic.JPG',   // Athletics
    8 => 'assets/images/basketball.jpg'  // Basketball
];

$sportId = intval($player['sport_id'] ?? 0);
$themeImage = $sportThemes[$sportId] ?? null;
$profileImage = $player['profile_image'] ?? 'assets/images/default_user.png';
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<title>Player Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gray-100 pt-20">

<!-- Navbar -->

<nav class="bg-white shadow-md fixed w-full z-20 top-0">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between h-16 items-center">

 
  <!-- Left links -->
  <div class="flex items-center space-x-6">
    <img src="assets/images/logo.png" alt="Logo" class="h-10 w-10">
    <a href="player.php" class="font-semibold text-black hover:text-yellow-400 transition">Home</a>
    <a href="player_dashboard.php" class="font-semibold text-black hover:text-yellow-400 transition">Dashboard</a>
    <a href="player_myteam.php" class="font-semibold text-black hover:text-yellow-400 transition">My Team</a>
    <a href="player_events.php" class="font-semibold text-black hover:text-yellow-400 transition">Events</a>
    <a href="player_calendar.php" class="font-semibold text-black hover:text-yellow-400 transition">Calendar</a>
  </div>
  
  <!-- Right side: User menu -->
  <div class="user-menu relative flex items-center space-x-2 cursor-pointer">
    <img src="<?php echo htmlspecialchars($profileImage); ?>" 
         alt="User Profile" 
         class="h-10 w-10 rounded-full border border-gray-400">
    <span class="text-black select-none">▼</span>

    <div id="userDropdown" class="absolute right-0 top-full hidden bg-white shadow-md rounded-md mt-2 w-48 py-2 z-50">
      <a href="player_view.php" class="block px-4 py-2 hover:bg-yellow-100">Profile</a>
      <a href="player_calendar.php" class="block px-4 py-2 hover:bg-yellow-100">Calendar</a>
      <a href="attendance.php" class="block px-4 py-2 hover:bg-yellow-100">Attendance</a>
      <a href="logout.php" class="block px-4 py-2 hover:bg-yellow-100">Logout</a>
    </div>
  </div>

</div>
 

  </div>
</nav>

<!-- Hero section -->

<div class="w-full min-h-screen bg-cover bg-center" 
     <?php if($themeImage) echo "style=\"background-image: url('$themeImage');\""; ?>>
</div>

<!-- User Menu JS -->

<script>
const userMenu = document.querySelector('.user-menu');
const userDropdown = document.getElementById('userDropdown');

userMenu.addEventListener('click', e => {
    e.stopPropagation();
    userDropdown.classList.toggle('hidden');
});

window.addEventListener('click', () => {
    userDropdown.classList.add('hidden');
});
</script>

</body>
</html>
