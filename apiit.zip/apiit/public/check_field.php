<?php
include 'db.php';

$field = $_GET['field'] ?? '';
$value = $_GET['value'] ?? '';

$allowedFields = ['username', 'email', 'phone', 'cb_number'];
if (!in_array($field, $allowedFields)) {
    echo json_encode(['exists' => false]);
    exit;
}

$stmt = $conn->prepare("SELECT 1 FROM users WHERE $field = ? LIMIT 1");
$stmt->bind_param("s", $value);
$stmt->execute();
$result = $stmt->get_result();
$exists = $result->num_rows > 0;
$stmt->close();

echo json_encode(['exists' => $exists]);
?>
